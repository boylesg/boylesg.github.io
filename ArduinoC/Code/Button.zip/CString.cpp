#line 2 "CString.cpp"
#include <Arduino.h>
#include <MyBase64.h>
#include "common.h"
#include "CString.h"
#include "debug.h"

#if defined ARDUINO_AVR_UNO || defined ARDUINO_AVR_PRO
  CBuff<20> buffTemp;
#else
  CBuff<160> buffTemp;
#endif
#define fstr_BUFF_OVERRUN_ERROR F("'buffTemp' has insufficient capacity!")




//****************************************************************
//* Construction and destuction
//****************************************************************

// So you can declare a global CString variable, but make sure you call init(...) before using it.
CString::CString()
{ 
  m_pBuff = NULL;
}

CString::CString(CString& strOther)
{
  init(*strOther.m_pBuff);
}

void CString::init(CBuffBase &buff, const bool bClear)
{
  if (bClear)
    buff.empty();
  m_pBuff = &buff;
}
//****************************************************************
//* Concatenation operator functions
//****************************************************************
void CString::operator +=(const char cCh)
{
  char strCh[] = {cCh, 0};
  *this += strCh;
}
  
void CString::operator +=(CString& str)
{
  if ((strlen(m_pBuff->m_strBuffer) + str.length() + 1) <= m_pBuff->capacity())
    strcat(m_pBuff->m_strBuffer, str.c_str());
}
  
void CString::operator +=(const char* str)
{
  if ((strlen(m_pBuff->m_strBuffer) + strlen(str) + 1) <= m_pBuff->capacity())
    strcat(m_pBuff->m_strBuffer, str);
}
  
#if !defined ARDUINO_ESP32_DEV
  void CString::operator +=(const __FlashStringHelper* fstr)
  {
    if ((strlen(m_pBuff->m_strBuffer) + strlen_P((PGM_P)fstr) + 1) <= m_pBuff->capacity())
      strcat_P(m_pBuff->m_strBuffer, (PGM_P)fstr);
  }
#endif
  
//****************************************************************
//* Assignment operator functions
//****************************************************************
CString& CString::operator =(const char cCh)
{
  if (m_pBuff->capacity() >= 2)
  {
    m_pBuff->m_strBuffer[0] = cCh;
    m_pBuff->m_strBuffer[1] = 0;
  }
  return *this;
}
  
CString& CString::operator =(const char* str)
{
  if (strlen(str) > 0)
  {
    m_pBuff->empty();
    strncpy(m_pBuff->m_strBuffer, str, capacity() - 1);
  }
  else
  {
    m_pBuff->empty();
  }
  return *this;
}
  
CString& CString::operator =(CString& str)
{
  *this = str.c_str();
  return *this;
}
  
void CString::fromIPAddr(IPAddress ip)
{
  CBuff<4> buffNum;
  CString strNum(buffNum);

  utoa(ip[0], strNum, 10);
  *this = strNum;
  *this += F(".");
  
  utoa(ip[1], strNum, 10);
  *this = strNum;
  *this += F(".");
  
  utoa(ip[2], strNum, 10);
  *this = strNum;
  *this += F(".");
  
  utoa(ip[3], strNum, 10);
  *this = strNum;
}

#if !defined ARDUINO_ESP32_DEV
  CString& CString::operator =(const __FlashStringHelper* fstr)
  {
    if (strlen_P((PGM_P)fstr) > 0)
    {
      if ((strlen_P((PGM_P)fstr) + 1) <= m_pBuff->capacity())
      {
        m_pBuff->empty();
        strcpy_P(m_pBuff->m_strBuffer, (PGM_P)fstr);
      }
      else
      {
        OPEN_RT_ERROR;
        debug.dump(F("fstr"), fstr);
        debug.dump(F("m_pBuff->capacity()"), m_pBuff->capacity());
        CLOSE_RT_ERROR;
      }
    }
    else
    {
      m_pBuff->empty();
    }
    return *this;
  }
#endif
  
//****************************************************************
//* Comparaison operator functions
//****************************************************************
bool CString::operator ==(const char *str) 
{ 
  return (m_pBuff->capacity() > 0) && (strcmp(m_pBuff->m_strBuffer, str) == 0); 
}

#if !defined ARDUINO_ESP32_DEV
  bool CString::operator ==(const __FlashStringHelper *fstr) 
  { 
    return (m_pBuff->capacity() > 0) && (strcmp_P(m_pBuff->m_strBuffer, (PGM_P)fstr) == 0); 
  }
#endif

bool CString::operator >=(const char *str)
{
  return (m_pBuff->capacity() > 0) && (strcmp(m_pBuff->m_strBuffer, str) >= 0);   
}

#if !defined ARDUINO_ESP32_DEV
  bool CString::operator >=(const __FlashStringHelper *fstr)
  {
    return (m_pBuff->capacity() > 0) && (strcmp_P(m_pBuff->m_strBuffer, (PGM_P)fstr) >= 0); 
  }
#endif

bool CString::operator >(const char *str)
{
  return (m_pBuff->capacity() > 0) && (strcmp(m_pBuff->m_strBuffer, str) > 0);   
}

#if !defined ARDUINO_ESP32_DEV
  bool CString::operator >(const __FlashStringHelper *fstr)
  {
    return (m_pBuff->capacity() > 0) && (strcmp_P(m_pBuff->m_strBuffer, (PGM_P)fstr) > 0); 
  }
#endif

bool CString::operator <=(const char *str)
{
  return (m_pBuff->capacity() > 0) && (strcmp(m_pBuff->m_strBuffer, str) <= 0);   
}

#if !defined ARDUINO_ESP32_DEV 
  bool CString::operator <=(const __FlashStringHelper *fstr)
  {
    return (m_pBuff->capacity() > 0) && (strcmp_P(m_pBuff->m_strBuffer, (PGM_P)fstr) <= 0); 
  }
#endif

bool CString::operator <(const char *str)
{
  return (m_pBuff->capacity() > 0) && (strcmp(m_pBuff->m_strBuffer, str) < 0);   
}

#if !defined ARDUINO_ESP32_DEV 
  bool CString::operator <(const __FlashStringHelper *fstr)
  {
    return (m_pBuff->capacity() > 0) && (strcmp_P(m_pBuff->m_strBuffer, (PGM_P)fstr) < 0); 
  }
#endif

bool CString::operator !=(const char *str)
{
  return (m_pBuff->capacity() > 0) && (strcmp(m_pBuff->m_strBuffer, str) != 0);   
}

#if !defined ARDUINO_ESP32_DEV 
  bool CString::operator !=(const __FlashStringHelper *fstr)
  {
    return (m_pBuff->capacity() > 0) && (strcmp_P(m_pBuff->m_strBuffer, (PGM_P)fstr) != 0); 
  }
#endif

//****************************************************************
//* Miscellaneous functions
//****************************************************************

const char* CString::substring(int nStartPos, int nEndPos)
{
  buffTemp.empty();

  if ((nStartPos > -1) && (nStartPos < length()) && ((nStartPos <= nEndPos) || (nEndPos == -1)))
  {
    if ((nEndPos == -1) || (nEndPos >= length()))
    {
      nEndPos = length() - 1;
    }
    if ((nEndPos - nStartPos) >= buffTemp.capacity())
    {
      OPEN_RT_ERROR;
      debug.dump(F("nStartPos"), nStartPos);
      debug.dump(F("nEndPos"), nEndPos);
      debug.dump(F("m_pBuff->capacity()"), m_pBuff->capacity());
      debug.dump(F("this"), *this);
      CLOSE_RT_ERROR;
    }
    else
    {
      char *strStart = m_pBuff->m_strBuffer + nStartPos;
      strncpy(buffTemp, strStart, nEndPos - nStartPos + 1);
    }
  }
  else
  {
    /*
    OPEN_RT_ERROR;
    debug.dump(F("nStartPos"), nStartPos);
    debug.dump(F("nEndPos"), nEndPos);
    debug.dump(F("length()"), length());
    CLOSE_RT_ERROR;
    */
  }
  return buffTemp;
}

//****************************************************************
//* Search functions functions
//****************************************************************

int CString::findOneOf(const char* strCharList, const unsigned int nPos)
{
  int nFindPos = -1;
  String strCharListTemp = strCharList;
  
  if ((nPos >= 0) && (nPos < length()))
  {
    for (unsigned int nI = nPos; nI < length(); nI++)
    {
      if (strCharListTemp.indexOf((*this)[nI]) >= 0)
      {
        nFindPos = nI;
        break;
      }
    }
  }
  return nFindPos;
}

int CString::reverseFindOneOf(const char* strCharList, const unsigned int nPos)
{
  int nFindPos = -1;
  String strCharListTemp = strCharList;
  
  if ((nPos >= 0) && (nPos < length()))
  {
    for (unsigned int nI = length() - 1; (nI >= 0) && (nI >= nPos); nI--)
    {
      if (strCharListTemp.indexOf((*this)[nI]) >= 0)
      {
        nFindPos = nI;
        break;
      }
    }
  }
  return nFindPos;
}

#if !defined ARDUINO_ESP32_DEV 
    int CString::reverseFindOneOf(const __FlashStringHelper* fstrCharList, const unsigned int nPos)
    {
      String strCharList = fstrCharList;
      return reverseFindOneOf(strCharList.c_str(), nPos);
    }

    int CString::findOneOf(const __FlashStringHelper* fstrCharList, const unsigned int nPos)
    {
      String strCharList = fstrCharList;
      return findOneOf(strCharList.c_str(), nPos);
    }

    bool CString::endsWith(const __FlashStringHelper *fstrFind)
    {
      CString strTemp(buffTemp);
      strTemp = fstrFind;
      return endsWith(strTemp);
      return false; 
    }
    bool CString::beginsWith(const __FlashStringHelper *fstrFind)
    {
      CString strTemp(buffTemp);
      strTemp = fstrFind;
      return beginsWith(strTemp);   
    }
#endif

bool CString::endsWith(const char *cstrFind)
{
  uint16_t  nPosStartExpected = length(),
            nLength = strlen(cstrFind),
            nPosStartActual = reverseIndexOf(cstrFind);

  nPosStartExpected -= nLength;

  return nPosStartActual == nPosStartExpected;
}

bool CString::beginsWith(const char *cstrFind)
{
  return indexOf(cstrFind) == 0;
}

int CString::indexOf(const char cCh, const int nPos)
{
  char strCh[] = {cCh, 0};
  return indexOf(strCh, nPos);
}
 
int CString::indexOf(const char* str, const int nPos)
{
  char *strStartPtr = NULL;
  int nI = -1;
    
  if (nPos < length())
  {
    strStartPtr = m_pBuff->m_strBuffer + nPos;
    strStartPtr = strstr(strStartPtr, str);
    if (strStartPtr)
    {
	    nI = strStartPtr - m_pBuff->m_strBuffer; 
    }
    else
    {
      nI = -1;    
    }
  }
  return nI;
}

#if !defined ARDUINO_ESP32_DEV 
  int CString::indexOf(const __FlashStringHelper* fstr, const int nPos)
  {
    String str = fstr;
    return indexOf(str.c_str(), nPos);
  }
#endif

int CString::reverseIndexOf(const char cCh, const int nPos)
{
  int nI = -1;

  if (nPos == -1)
    nI = strlen(m_pBuff->m_strBuffer) - 1;
  else
    nI = nPos;
    
  while ((m_pBuff->m_strBuffer[nI] != cCh) && (nI >= 0))
	  nI--;
  
  return nI;
}

int CString::reverseIndexOf(const char* str, const int nPos)
{
  char *strStartPtr = NULL;
  int nI = -1;

  if ((nPos >= 0) && (nPos < length()))
    strStartPtr = m_pBuff->m_strBuffer + nPos;
  else
    strStartPtr = m_pBuff->m_strBuffer + strlen(m_pBuff->m_strBuffer) - 1;
	  
  while (strStartPtr >= m_pBuff->m_strBuffer)
  {
	  if (strstr(strStartPtr, str) != NULL)
	  {
		  nI = strStartPtr - m_pBuff->m_strBuffer;
		  break;
	  }
	  strStartPtr--;
  }
  return nI;
}

#if !defined ARDUINO_ESP32_DEV 
  int CString::reverseIndexOf(const __FlashStringHelper* fstr, const int nPos)
  {
    int nI = -1;
    char *strStartPtr = NULL;
    
    if ((nPos >= 0) && (nPos < length()))
      strStartPtr = m_pBuff->m_strBuffer + nPos;
    else
      strStartPtr = m_pBuff->m_strBuffer + strlen(m_pBuff->m_strBuffer) - 1;
  	  
    while (strStartPtr >= m_pBuff->m_strBuffer)
    {
  	  if (strstr_P(strStartPtr, (PGM_P)fstr) != NULL)
  	  {
  		  nI = strStartPtr - m_pBuff->m_strBuffer;
  		  break;
  	  }
  	  strStartPtr--;
    }
    return nI;
  }
#endif
  
//****************************************************************
//* Formatting and conversion functions
//****************************************************************
#if !defined ARDUINO_ESP32_DEV 
  void CString::format(const __FlashStringHelper *fstr, ...)
  {
    String str = fstr;
    
    va_list argptr;  
    va_start(argptr, fstr); 
    int nRet = vsnprintf(m_pBuff->m_strBuffer, m_pBuff->capacity() - 1, str.c_str(), argptr);
    if (nRet == 0)
    {
      OPEN_RT_ERROR;
      debug.dump(F("fstr"), fstr);
      CLOSE_RT_ERROR;
    }
  }
#endif

void CString::format(const char *str, ...) 
{ 
  va_list argptr;  
  va_start(argptr, str); 
  int nRet = vsnprintf(m_pBuff->m_strBuffer, m_pBuff->capacity() - 1, str, argptr);
  if (nRet < 0)
  {
	  OPEN_RT_ERROR;
    debug.dump(F("str"), str);
    CLOSE_RT_ERROR;
  }
}

void CString::fromBool(const bool bVal)
{
  if (bVal)
    *this = F("true");
  else
    *this = F("false");
}

void CString::convertHex2Bin(char *strHex, const byte nCapacity)
{
  CString strBin(buffTemp);

  for (unsigned int nI = 0; nI < strlen(strHex); nI++)
  {
  	switch (strHex[nI])
  	{
      #if !defined ARDUINO_ARDUINO_ESP32_DEV_DEV
  	    case '0': strBin += F("0000"); break;
  	    case '1': strBin += F("0001"); break;
  	    case '2': strBin += F("0010"); break;
  	    case '3': strBin += F("0011"); break;
  	    case '4': strBin += F("0100"); break;
  	    case '5': strBin += F("0101"); break;
  	    case '6': strBin += F("0110"); break;
  	    case '7': strBin += F("0111"); break;
  	    case '8': strBin += F("1000"); break;
  	    case '9': strBin += F("1001"); break;
  	    case 'A':  
  	    case 'a': strBin += F("1010"); break;
  	    case 'B':  
  	    case 'b': strBin += F("1011"); break;
  	    case 'C':  
  	    case 'c': strBin += F("1100"); break;
  	    case 'D':  
  	    case 'd': strBin += F("1101"); break;
  	    case 'E':  
  	    case 'e': strBin += F("1110"); break;
        case 'F':  
  		  case 'f': strBin += F("1111"); break;
      #else
        case '0': strBin += "0000"; break;
        case '1': strBin += "0001"; break;
        case '2': strBin += "0010"; break;
        case '3': strBin += "0011"; break;
        case '4': strBin += "0100"; break;
        case '5': strBin += "0101"; break;
        case '6': strBin += "0110"; break;
        case '7': strBin += "0111"; break;
        case '8': strBin += "1000"; break;
        case '9': strBin += "1001"; break;
        case 'A':  
        case 'a': strBin += "1010"; break;
        case 'B':  
        case 'b': strBin += "1011"; break;
        case 'C':  
        case 'c': strBin += "1100"; break;
        case 'D':  
        case 'd': strBin += "1101"; break;
        case 'E':  
        case 'e': strBin += "1110"; break;
        case 'F':  
        case 'f': strBin += "1111"; break;
      #endif
  	}
	}
  *this = strBin;
}

void CString::fromUint(const int nNum, const byte nBase)
{
  if (((unsigned int)log10(nNum) + 1) <= m_pBuff->capacity())
  {
    memset(m_pBuff->m_strBuffer, 0, m_pBuff->capacity());
    utoa(nNum, m_pBuff->m_strBuffer, nBase);
  }
}

void CString::fromInt(const int32_t nNum, const byte nBase)
{
  if (((unsigned int)log10(nNum) + 2) <= m_pBuff->capacity())
  {
    memset(m_pBuff->m_strBuffer, 0, m_pBuff->capacity());
    itoa(nNum, m_pBuff->m_strBuffer, nBase);
  }
}

void CString::fromReal(const double dNum, const byte nDecimalPlaces)
{
  if (((unsigned int)log10(floor(dNum)) + nDecimalPlaces + 2) <= m_pBuff->capacity())
  {
    memset(m_pBuff->m_strBuffer, 0, m_pBuff->capacity());
  
    #ifdef ARDUINO_SAM_DUE
      dtostrf(dNum, (nDecimalPlaces + 2), nDecimalPlaces, m_pBuff->m_strBuffer);
    #else
      dtostrf(dNum, (nDecimalPlaces + 2), nDecimalPlaces, m_pBuff->m_strBuffer);
    #endif
  }
}

int CString::toUint(const byte nBase)
{
	return ::toUint(m_pBuff->m_strBuffer, nBase);
}

int32_t CString::toInt(const byte nBase)
{
	return ::toInt(m_pBuff->m_strBuffer, nBase);
}

double CString::toReal()
{
	return ::toReal(m_pBuff->m_strBuffer);
}

//****************************************************************
//* Modification functions
//****************************************************************

void CString::encodeBase64()
{
  CString str(buffTemp);

  base64_decode(str, m_pBuff->m_strBuffer, m_pBuff->capacity() - 1);
  *this = str;
}

void CString::decodeBase64()
{
  CString str(buffTemp);
  
  base64_decode(str, m_pBuff->m_strBuffer, m_pBuff->capacity() - 1);
  *this = str;
}

void CString::insert(const char cCh, const unsigned int nBeforePos)
{
  char str[2] = {cCh, 0};
  insert(str, nBeforePos);
}

#if !defined ARDUINO_ESP32_DEV 
  void CString::insert(const __FlashStringHelper* fstr, const unsigned int nBeforePos)
  {
    String str = fstr;
    insert(str.c_str(), nBeforePos);
  }
#endif

void CString::insert(const char* str, const unsigned int nBeforePos)
{
  if ((length() + strlen(str)) < capacity())
  {
    char *strAfter = m_pBuff->m_strBuffer + nBeforePos;
    
    buffTemp.empty();
    strncpy(buffTemp, m_pBuff->m_strBuffer, nBeforePos);
    strcat(buffTemp, str);
    strcat(buffTemp, strAfter);
    m_pBuff->empty();
    if (buffTemp.length() > m_pBuff->capacity())
    {
      OPEN_RT_ERROR;
      debug.dump(F("buffTemp.length()"), buffTemp.length());
      debug.dump(F("capacity()"), capacity());
      debug.dump(F("str"), str);
      debug.dump(F("nBeforePos"), nBeforePos);
      debug.dump(F("m_pBuff->m_strBuffer"), m_pBuff->m_strBuffer);
      CLOSE_RT_ERROR;
    }
    else
      strcpy(m_pBuff->m_strBuffer, buffTemp);
  }
}

void CString::replace(const char cFind, const char cReplace, const unsigned int nStartFrom)
{
  char strFindCh[] = {cFind, 0}, strReplaceCh[] = {cReplace, 0};
  replace(strFindCh, strReplaceCh, nStartFrom);
}

void CString::removeCh(const char cFind, const int nStartFrom)
{
  char strFind[] = {cFind, 0};
  remove(strFind, nStartFrom);
}

#if !defined ARDUINO_ESP32_DEV 
  void CString::remove(const __FlashStringHelper* fstrFind, const unsigned int nStartFrom)
  {
    String strFind = fstrFind;
    
    strFind = fstrFind;
    remove(strFind.c_str(), nStartFrom);
  }
#endif

void CString::remove(const char* strFind, const unsigned int nStartFrom)
{
  char* strFound = NULL, *strStart = m_pBuff->m_strBuffer + nStartFrom, *strEndFound = NULL;
  
  buffTemp.empty();
  strFound = strstr(strStart, strFind);

  if (strFound)
  {
    strEndFound = strFound + strlen(strFind);
    strFound[0] = 0; 
    strcpy(buffTemp, m_pBuff->m_strBuffer);
    strcat(buffTemp, strEndFound);
    m_pBuff->empty();
    strcpy(m_pBuff->m_strBuffer, buffTemp);
  }
}

#if !defined ARDUINO_SAM_DUE && !defined ARDUINO_ESP32_DEV
  void CString::replace(const __FlashStringHelper* fstrFind, const __FlashStringHelper* fstrReplace, const unsigned int nStartFrom)
  {
    int nPos = indexOf(fstrFind, nStartFrom);
    if (nPos >= 0)
    {
      remove(fstrFind, nStartFrom);
      insert(fstrReplace, nPos);
    }
  }
  
  void CString::replace(const char* strFind, const __FlashStringHelper* fstrReplace, const unsigned int nStartFrom)
  {
    int nPos = indexOf(strFind, nStartFrom);
    if (nPos >= 0)
    {
      remove(strFind, nStartFrom);
      insert(fstrReplace, nPos);
    }
  }

  void CString::replace(const __FlashStringHelper* fstrFind, const char* strReplace, const unsigned int nStartFrom)
  {
    int nPos = indexOf(fstrFind, nStartFrom);
    if (nPos >= 0)
    {
      remove(fstrFind, nStartFrom);
      insert(strReplace, nPos);
    }
  }
#endif

void CString::replace(const char* strFind, const char* strReplace, const unsigned int nStartFrom)
{
    int nPos = indexOf(strFind, nStartFrom);
    if (nPos >= 0)
    {
      remove(strFind, nStartFrom);
      insert(strReplace, nPos);
    }
}

void CString::remove(const int nPos, unsigned int nCount)
{
  if (nPos == -1)
  {
    RT_ERROR;
  }
  else if (nPos >= length())
  {
    RT_ERROR;
    debug.dump(F("nPos"), nPos);
    debug.dump(F("nCount"), nCount);
    debug.dump(F("this"), *this);
  }
  else
  {
    if ((nPos + nCount) >= length())
    {
      m_pBuff->m_strBuffer[nPos] = 0;
    }
    else
    {
      char *strStartDelete = m_pBuff->m_strBuffer + nPos,
            *strEndDelete = strStartDelete + nCount;
      memmove(strStartDelete, strEndDelete, length() - nCount);
      m_pBuff->m_strBuffer[length() - (nPos + nCount)] = 0;    
    }
  }
}

void CString::toLower()
{
  for (unsigned int nI = 0; nI < strlen(m_pBuff->m_strBuffer); nI++)
  {
    if ((m_pBuff->m_strBuffer[nI] >= 'A') && (m_pBuff->m_strBuffer[nI] <= 'Z'))
      m_pBuff->m_strBuffer[nI] += 32;
  }
}

void CString::toUpper()
{
  for (unsigned int nI = 0; nI < strlen(m_pBuff->m_strBuffer); nI++)
  {
    if ((m_pBuff->m_strBuffer[nI] >= 'a') && (m_pBuff->m_strBuffer[nI] <= 'z'))
      m_pBuff->m_strBuffer[nI] -= 32;
  }
}

void CString::concat(const char *strStart, const char* strEnd, char* strDest, const unsigned int nSize)
{
	unsigned int nI = strlen(strDest);

	while ((strStart <= strEnd) && (nI < nSize))
	{
		strDest[nI] = strStart[0];
		strDest[nI + 1] = 0;
		strStart++;
		nI++;
	}
}

void CString::copy(const char *strStart, const char* strEnd, char* strDest, const unsigned int nSize)
{
  unsigned int nI = 0;

  memset(strDest, 0, nSize);
  while ((strStart <= strEnd) && (nI < nSize))
  {
    strDest[nI] = *strStart;
    strStart++;
    nI++;
  }
}

void CString::trimLeft()
{
  char *strStartPtr = NULL, *strEndPtr = NULL;
  
  strStartPtr = m_pBuff->m_strBuffer;
  strEndPtr = m_pBuff->m_strBuffer + strlen(m_pBuff->m_strBuffer) - 1;
  while ((isWhitespace(*strStartPtr) || (*strStartPtr == 13) || (*strStartPtr == 10)) && (strStartPtr <= strEndPtr))
	  strStartPtr++;

  unsigned int nMoveLength = strEndPtr - strStartPtr + 1;
  memmove(m_pBuff->m_strBuffer, strStartPtr, nMoveLength);
  m_pBuff->m_strBuffer[nMoveLength] = 0;
}

void CString::trimRight()
{
  char *strStartPtr = NULL, *strEndPtr = NULL;
  
  strStartPtr = m_pBuff->m_strBuffer;
  strEndPtr = m_pBuff->m_strBuffer + strlen(m_pBuff->m_strBuffer) - 1;
  while ((isWhitespace(*strEndPtr) || (*strEndPtr == 13) || (*strEndPtr == 10)) && (strEndPtr >= strStartPtr))
	  strEndPtr--;
  strEndPtr++;
  *strEndPtr = 0;
}

void CString::trim()
{
  trimLeft();
  trimRight();
}

void CString::padLeft(const char cCh, const byte nLength)
{
  while ((strlen(m_pBuff->m_strBuffer) < nLength) && (strlen(m_pBuff->m_strBuffer) < m_pBuff->capacity()))
  {
    insert(cCh, 0); 
  }
}

void CString::padRight(const char cCh, const byte nLength)
{
  while ((strlen(m_pBuff->m_strBuffer) < nLength) && (strlen(m_pBuff->m_strBuffer) < m_pBuff->capacity()))
  {
    m_pBuff->m_strBuffer[strlen(m_pBuff->m_strBuffer)] = cCh;
    m_pBuff->m_strBuffer[strlen(m_pBuff->m_strBuffer) + 1] = 0;
  }
  
}






//#define DTOSTR_ALWAYS_SIGN 0x01
//#define DTOSTR_PLUS_SIGN   0x02
//#define DTOSTR_UPPERCASE   0x04
