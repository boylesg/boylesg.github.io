#line 2 "debug.cpp"
#include <Arduino.h>
#include "Common.h"
#include "Debug.h"
#include "Constants.h"
#include "Common.h"

#if defined ARDUINO_AVR_UNO || defined ARDUINO_AVR_PRO
  #define FSTR_BUFF_SIZE 64
#else
  #define FSTR_BUFF_SIZE 128
#endif
#define FSTR_FILENAME_BUFF_SIZE 32




CDebug::CDebug()
{
  m_pSerial = m_pBroadcastSerial = NULL;
}

CDebug::CDebug(Stream *pSerial)
{
  m_pSerial = pSerial;
  m_pBroadcastSerial = NULL;
}

CDebug::~CDebug()
{
}

#ifdef LOGFILE
  bool CDebug::openLogFile(CTextFile*& pLogFile)
  {
    bool bResult = false;
  
    pLogFile = NULL;
    logEventOpen('=', F("Opening log file for reading"));
     
    if (m_fileLog)
    { 
      m_fileLog.close();
      CBuff<FSTR_FILENAME_BUFF_SIZE> buffFilename;
      CString strFilename(buffFilename);

      strFilename = str_TXT_LOG_FILE;
      
      if (m_fileLog.open(strFilename, READ))
      {
        pLogFile = &m_fileLog;
        logEventClose('=', F("successful"));
        bResult = true;
      }
      else
        logEventClose('=', F("failed (can't open)"));
    }
    else
      logEventClose('=', F("failed (can't close)"));
  
    return bResult;
  }

  bool CDebug::doneLogFile()
  {
    bool bResult = false;
      
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.close();
        CBuff<FSTR_FILENAME_BUFF_SIZE> buffFilename;
        CString strFilename(buffFilename);
        
        strFilename = str_TXT_LOG_FILE;
        
        logEventOpen('=', F("Re-opening log file for writing"));
        if (m_fileLog.open(strFilename, APPEND))
        {
          logEventClose('=', F("successful"));
          bResult = true;
        }
        else
          logEventClose('=', F("failed"));
      }
    #endif
    return bResult;
  }
    
#endif 
  
bool CDebug::startLogFile()
{
  bool bResult = false;
  #ifdef LOGFILE

    CBuff<FSTR_FILENAME_BUFF_SIZE> buffFilename;
    CString strFilename(buffFilename);

    strFilename = str_TXT_LOG_FILE;    
    logEventOpen('=', F("Opening log file for writing"));
    if (m_fileLog.open(strFilename, REWRITE))
    {
      logEventClose('=', F("successful"));
      bResult = true;
    }
    else
      logEventClose('=', F("failed"));

  #endif

  return bResult;
}

void CDebug::setSerial(Stream *pSerial)
{
  m_pSerial = pSerial;
}

void CDebug::setBroadcastSerial(Stream *pSerial)
{
  m_pBroadcastSerial = pSerial;
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE

  void CDebug::dumpPtr(const __FlashStringHelper* fstrVarName, const void *pPtr, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
          m_fileLog.write(fstrVarName);
          m_fileLog.write(F(" = "));
          
          CBuff<FSTR_FILENAME_BUFF_SIZE> buff;
          CString str(buff);
          str.format("%04H", (uint32_t)pPtr);
          m_fileLog.write(str);
  
          if (bNewLine)
            m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->print(fstrVarName);
    m_pSerial->print(F(" = "));
    m_pSerial->print((uint32_t)pPtr, HEX);
    if (bNewLine)
      m_pSerial->println();

    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      m_pBroadcastSerial->print((uint32_t)pPtr, HEX);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }
  
  void CDebug::dump(const __FlashStringHelper* fstrVarName, const unsigned long int nVal, const bool bNewLine)
  {
    CBuff<FSTR_BUFF_SIZE> buffVarName;
    CString strVarName(buffVarName);

    strVarName = fstrVarName;
    dump(strVarName.c_str(), nVal, bNewLine);
  }
  
  void CDebug::dump(const __FlashStringHelper* fstrVarName, const long int nVal, const bool bNewLine)
  {
    CBuff<FSTR_BUFF_SIZE> buffVarName;
    CString strVarName(buffVarName);

    strVarName = fstrVarName;
    dump(strVarName.c_str(), nVal, bNewLine);
  }
  
  void CDebug::dump(const __FlashStringHelper* fstrVarName, CString &str, const bool bNewLine)
  {
    CBuff<FSTR_BUFF_SIZE> buffVarName;
    CString strVarName(buffVarName);

    strVarName = fstrVarName;
    dump(strVarName.c_str(), str.c_str(), bNewLine);
  }
    
#endif

void CDebug::dumpPtr(const char* cstrVarName, const void *pPtr, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        
        CBuff<FSTR_FILENAME_BUFF_SIZE> buff;
        CString str(buff);
        str.format("%04H", (uint32_t)pPtr);
        m_fileLog.write(str);

        if (bNewLine)
          m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstrVarName);
  m_pSerial->print(F(" = "));
  m_pSerial->print((uint32_t)pPtr, HEX);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstrVarName);
    m_pBroadcastSerial->print(F(" = "));
    m_pBroadcastSerial->print((uint32_t)pPtr, HEX);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::dump(const char* cstrVarName, const unsigned long int nVal, const bool bNewLine)
{  
  #ifdef LOGFILE
    if (m_fileLog)
    {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(nVal);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstrVarName);
  m_pSerial->print(F(" = "));
  m_pSerial->print(nVal);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstrVarName);
    m_pBroadcastSerial->print(F(" = "));
    m_pBroadcastSerial->print(nVal);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::dump(const char* cstrVarName, const long int nVal, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(nVal);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstrVarName);
  m_pSerial->print(F(" = "));
  m_pSerial->print(nVal);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstrVarName);
    m_pBroadcastSerial->print(F(" = "));
    m_pBroadcastSerial->print(nVal);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
  void CDebug::dump(const __FlashStringHelper* fstrVarName, const float fVal, const bool bNewLine)
  {
    dump(fstrVarName, (double)fVal, bNewLine);
  }

  void CDebug::dump(const __FlashStringHelper* fstrVarName, const double dVal, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(fstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(dVal);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->print(fstrVarName);
    m_pSerial->print(F(" = "));
    m_pSerial->print(dVal);
    if (bNewLine)
      m_pSerial->println();

    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      m_pBroadcastSerial->print(dVal);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }
#endif

void CDebug::dump(const char* cstrVarName, const char* cstr, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(cstr);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstrVarName);
  m_pSerial->print(F(" = "));
  m_pSerial->print(cstr);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstrVarName);
    m_pBroadcastSerial->print(F(" = "));
    m_pBroadcastSerial->print(cstr);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::dump(const char* cstrVarName, const char cChar, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(cChar);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstrVarName);
  m_pSerial->print(F(" = "));
  m_pSerial->print(cChar);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstrVarName);
    m_pBroadcastSerial->print(F(" = "));
    m_pBroadcastSerial->print(cChar);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::dump(const char* cstrVarName, CString &str, const bool bNewLine)
{
  dump(cstrVarName, str.c_str(), bNewLine);
}

void CDebug::dump(const char* cstrVarName, const float fVal, const bool bNewLine)
{
  dump(cstrVarName, double(fVal), bNewLine);
}

void CDebug::dump(const char* cstrVarName, const double dVal, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(dVal);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstrVarName);
  m_pSerial->print(F(" = "));
  m_pSerial->print(dVal);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstrVarName);
    m_pBroadcastSerial->print(F(" = "));
    m_pBroadcastSerial->print(dVal);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::dump(const char* cstrVarName, IPAddress IPAddr, const bool bNewLine)
{
  CBuff<24> buffIP;
  CString strIP(buffIP);

  strIP.fromIPAddr(IPAddr);
  dump(cstrVarName, strIP, bNewLine);
}

void CDebug::dump(const char* cstrVarName, const bool bVal, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        if (bVal)
          m_fileLog.write(F("true"));
        else
          m_fileLog.write(F("false"));
        if (bNewLine)
          m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstrVarName);
  m_pSerial->print(F(" = "));
  if (bVal)
    m_pSerial->print(F("true"));
  else
    m_pSerial->print(F("false"));
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstrVarName);
    m_pBroadcastSerial->print(F(" = "));
    if (bVal)
      m_pBroadcastSerial->print(F("true"));
    else
      m_pBroadcastSerial->print(F("false"));
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
  void CDebug::dump(const char* cstrVarName, const __FlashStringHelper* fstr, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(cstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(fstr);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->print(cstrVarName);
    m_pSerial->print(F(" = "));
    m_pSerial->print(fstr);
    if (bNewLine)
      m_pSerial->println();

    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(cstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      m_pBroadcastSerial->print(fstr);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }

  void CDebug::dump(const __FlashStringHelper* fstrVarName, const char* cstr, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(fstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(cstr);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
     #endif
    m_pSerial->print(fstrVarName);
    m_pSerial->print(F(" = "));
    m_pSerial->print(cstr);
    if (bNewLine)
      m_pSerial->println();
  
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      m_pBroadcastSerial->print(cstr);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }

  void CDebug::dump(const __FlashStringHelper* fstrVarName, const __FlashStringHelper* fstr, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(fstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(fstr);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->print(fstrVarName);
    m_pSerial->print(F(" = "));
    m_pSerial->print(fstr);
    if (bNewLine)
      m_pSerial->println();
 
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      m_pBroadcastSerial->print(fstr);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
 }

  void CDebug::dump(const __FlashStringHelper* fstrVarName, const char cChar, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(fstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(cChar);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->print(fstrVarName);
    m_pSerial->print(F(" = "));
    m_pSerial->print(cChar);
    if (bNewLine)
      m_pSerial->println();

    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      m_pBroadcastSerial->print(cChar);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }
  
  void CDebug::dump(const __FlashStringHelper* fstrVarName, const bool bVal, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(fstrVarName);
        m_fileLog.write(F(" = "));
        if (bVal)
          m_fileLog.write(F("true"));
        else
          m_fileLog.write(F("false"));
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
    #endif
    
    m_pSerial->print(fstrVarName);
    m_pSerial->print(F(" = "));
    if (bVal)
      m_pSerial->print(F("true"));
    else
      m_pSerial->print(F("false"));
    if (bNewLine)
      m_pSerial->println();
      
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      if (bVal)
        m_pBroadcastSerial->print(F("true"));
      else
        m_pBroadcastSerial->print(F("false"));
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }
  
  void CDebug::dump(const __FlashStringHelper* fstrVarName, IPAddress IPAddr, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(fstrVarName);
        m_fileLog.write(F(" = "));
        m_fileLog.write(IPAddr);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->print(fstrVarName);
    m_pSerial->print(F(" = "));
    m_pSerial->print(IPAddr);
    if (bNewLine)
      m_pSerial->println();
      
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstrVarName);
      m_pBroadcastSerial->print(F(" = "));
      m_pBroadcastSerial->print(IPAddr);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }
#endif

void CDebug::logEventClose(const char cCh, const char* cstrEventResult)
{
  if (strlen(cstrEventResult) > 0)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(cstrEventResult);
        m_fileLog.writeLine(F("!"));
      }
    #endif
    m_pSerial->print(cstrEventResult);
    m_pSerial->println(F("!"));
  
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(cstrEventResult);
      m_pBroadcastSerial->println(F("!"));
    }
  }
  if (cCh > 0)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.writeLine((""));
        for (uint8_t nI = 0; nI < m_nNumChars; nI++)
          m_fileLog.write(cCh);
        m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->println();
    for (uint8_t nI = 0; nI < m_nNumChars; nI++)
      m_pSerial->print(cCh);
    m_pSerial->println();

    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->println();
      for (uint8_t nI = 0; nI < m_nNumChars; nI++)
        m_pBroadcastSerial->print(cCh);
      m_pBroadcastSerial->println();
    }
  }
}

void CDebug::logEventOpen(const char cCh, const char* cstrEventDesc, const bool bNewLine)
{
  if (cCh > 0)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.writeLine(F(""));
        for (uint8_t nI = 0; nI < m_nNumChars; nI++)
          m_fileLog.write(cCh);
        m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->println();
    for (uint8_t nI = 0; nI < m_nNumChars; nI++)
      m_pSerial->print(cCh);
    m_pSerial->println();
    
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->println();
      for (uint8_t nI = 0; nI < m_nNumChars; nI++)
        m_pBroadcastSerial->print(cCh);
      m_pBroadcastSerial->println();
    }
  }
  if (strlen(cstrEventDesc) > 0)
  {
    if (!bNewLine)
    {
      #ifdef LOGFILE
        if (m_fileLog)
        {
          m_fileLog.write(cstrEventDesc);
          m_fileLog.writeLine(F("..."));
        }
      #endif
      m_pSerial->print(cstrEventDesc);
      m_pSerial->print(F("..."));
      
      if (m_pBroadcastSerial)
      {
        m_pBroadcastSerial->print(cstrEventDesc);
        m_pBroadcastSerial->print(F("..."));
      }
    }
    else
    {
      #ifdef LOGFILE
        if (m_fileLog)
        {
          m_fileLog.writeLine(cstrEventDesc);
          for (uint8_t nI = 0; nI < strlen(cstrEventDesc) + 1; nI++)
            m_fileLog.write('-');
          m_fileLog.writeLine(F("\n"));
        }
      #endif
      m_pSerial->println(cstrEventDesc);
      for (uint8_t nI = 0; nI < strlen(cstrEventDesc) + 1; nI++)
        m_pSerial->print('-');
      m_pSerial->println(F("\n"));
      
      if (m_pBroadcastSerial)
      {
        m_pBroadcastSerial->println(cstrEventDesc);
        for (uint8_t nI = 0; nI < strlen(cstrEventDesc) + 1; nI++)
          m_pBroadcastSerial->print('-');
        m_pBroadcastSerial->println(F("\n"));
      }
    }
  }
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE

  void CDebug::logEventClose(const char cCh, const __FlashStringHelper* fstrEventResult)
  {
    CBuff<FSTR_BUFF_SIZE> buffEventResult;
    CString strEventResult(buffEventResult);
    
    strEventResult = fstrEventResult;
    logEventClose(cCh, strEventResult);
  }
  
  void CDebug::logEventOpen(const char cCh, const __FlashStringHelper* fstrEventDesc, const bool bNewLine)
  {
    CBuff<FSTR_BUFF_SIZE> buffEventDesc;
    CString strEventDesc(buffEventDesc);

    strEventDesc = fstrEventDesc;
    logEventOpen(cCh, strEventDesc, bNewLine);
  }
  
#endif

void CDebug::logPtr(const void *pPtr, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      CBuff<FSTR_FILENAME_BUFF_SIZE> buff;
      CString str(buff);
      str.format("%04H", (unsigned int)pPtr);
      m_fileLog.write(str);
      if (bNewLine)
        m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print((unsigned int)pPtr, HEX);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print((unsigned int)pPtr, HEX);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::log(const unsigned long int nVal, const bool bNewLine)
{  
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(nVal);
      if (bNewLine)
        m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(nVal);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(nVal);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::log(const long int nVal, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(nVal);
      if (bNewLine)
        m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(nVal);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(nVal);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::log(const float fVal, const bool bNewLine)
{
  log((double)fVal, bNewLine);
}

void CDebug::log(const double dVal, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(dVal);
      if (bNewLine)
        m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(dVal);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(dVal);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::log(const char* cstr, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(cstr);
      if (bNewLine)
        m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cstr);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cstr);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
  void CDebug::log(const __FlashStringHelper* fstr, const bool bNewLine)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(fstr);
        if (bNewLine)
          m_fileLog.writeLine(F(""));
      }
    #endif
    m_pSerial->print(fstr);
    if (bNewLine)
      m_pSerial->println();
 
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(fstr);
      if (bNewLine)
        m_pBroadcastSerial->println();
    }
  }
#endif

void CDebug::log(const char cChar, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(cChar);
      if (bNewLine)
        m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(cChar);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(cChar);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::log(IPAddress IPAddr, const bool bNewLine)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(IPAddr);
      if (bNewLine)
        m_fileLog.writeLine(F(""));
    }
  #endif
  m_pSerial->print(IPAddr);
  if (bNewLine)
    m_pSerial->println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(IPAddr);
    if (bNewLine)
      m_pBroadcastSerial->println();
  }
}

void CDebug::openRuntimeError(const char* cstrFileName, const uint16_t nLineNum)
{
  Serial.println(F("_______________________________________________________"));
  logRuntimeError(cstrFileName, nLineNum);
  Serial.println();

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->println(F("_______________________________________________________"));
    logRuntimeError(cstrFileName, nLineNum);
    m_pBroadcastSerial->println();
  }
}

void CDebug::closeRuntimeError()
{
  Serial.println(F("_______________________________________________________"));

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->println(F("_______________________________________________________"));
  }
}

void CDebug::logRuntimeError(const char* cstrFileName, const uint16_t nLineNum)
{
  CBuff<FSTR_BUFF_SIZE> buff;
  CString str(buff);
  int16_t nPos = 0;

  str = cstrFileName;
  nPos = str.reverseIndexOf(F("\\"));
  if (nPos >= 0)
    str.remove(0, nPos + 1);

  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(F("RUNTIME ERROR: "));
      m_fileLog.write(str);
      m_fileLog.write(F(" line number "));
      m_fileLog.writeLine((int32_t)nLineNum);  
    }
  #endif
  m_pSerial->print(F("RUNTIME ERROR: "));
  m_pSerial->print(str);
  m_pSerial->print(F(" line number "));
  m_pSerial->println(nLineNum);  

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(F("RUNTIME ERROR: "));
    m_pBroadcastSerial->print(str);
    m_pBroadcastSerial->print(F(" line number "));
    m_pBroadcastSerial->println(nLineNum);  
  }
}

void CDebug::logFileFoundError(const char* cstrFileName)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(F("File '"));
      m_fileLog.write(cstrFileName);
      m_fileLog.writeLine(F("' was not found!"));  
    }
  #endif
  m_pSerial->print(F("File '"));
  m_pSerial->print(cstrFileName);
  m_pSerial->println(F("' was not found!"));  

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(F("File '"));
    m_pBroadcastSerial->print(cstrFileName);
    m_pBroadcastSerial->println(F("' was not found!"));  
  }
}

void CDebug::logFileOpenError(const char* cstrFileName)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(F("File '"));
      m_fileLog.write(cstrFileName);
      m_fileLog.writeLine(F("' could not be opened!"));  
    }
  #endif
  m_pSerial->print(F("File '"));
  m_pSerial->print(cstrFileName);
  m_pSerial->println(F("' could not be opened!"));  

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(F("File '"));
    m_pBroadcastSerial->print(cstrFileName);
    m_pBroadcastSerial->println(F("' could not be opened!"));      
  }
}

void CDebug::logFileReadError(const char* cstrFileName)
{
  #ifdef LOGFILE
    if (m_fileLog)
    {
      m_fileLog.write(F("Error while reading file '"));
      m_fileLog.write(cstrFileName);
      m_fileLog.writeLine(F("'!"));  
    }
  #endif
  m_pSerial->print(F("Error while reading file '"));
  m_pSerial->print(cstrFileName);
  m_pSerial->println(F("'!"));  

  if (m_pBroadcastSerial)
  {
    m_pBroadcastSerial->print(F("Error while reading file '"));
    m_pBroadcastSerial->print(cstrFileName);
    m_pBroadcastSerial->println(F("'!"));  
  }
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
  void CDebug::logRuntimeError(const __FlashStringHelper* fstrFileName, const int16_t nLineNum)
  {
    CBuff<FSTR_BUFF_SIZE> buff;
    CString str(buff);
    int16_t nPos = 0;

    str = fstrFileName;
    nPos = str.reverseIndexOf(F("\\"));
    if (nPos >= 0)
      str.remove(0, nPos);

    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(F("RUNTIME ERROR: "));
        m_fileLog.write(str);
        m_fileLog.write(F(" line number "));
        m_fileLog.writeLine((uint32_t)nLineNum);  
      }
    #endif
    m_pSerial->print(F("RUNTIME ERROR: "));
    m_pSerial->print(str);
    m_pSerial->print(F(" line number "));
    m_pSerial->println(nLineNum);  
 
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(F("RUNTIME ERROR: "));
      m_pBroadcastSerial->print(str);
      m_pBroadcastSerial->print(F(" line number "));
      m_pBroadcastSerial->println(nLineNum);  
    }
  }
  void CDebug::openRuntimeError(const __FlashStringHelper* fstrFileName, const int16_t nLineNum)
  {
    Serial.println(F("_______________________________________________________"));
    logRuntimeError(fstrFileName, nLineNum);
    Serial.println();

    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->println(F("_______________________________________________________"));
      logRuntimeError(fstrFileName, nLineNum);
      m_pBroadcastSerial->println();
    }
  }
  void CDebug::logFileFoundError(const __FlashStringHelper* fstrFileName)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(F("File '"));
        m_fileLog.write(fstrFileName);
        m_fileLog.writeLine(F("' was not found!"));  
      }
    #endif
    m_pSerial->print(F("File '"));
    m_pSerial->print(fstrFileName);
    m_pSerial->println(F("' was not found!"));  
  
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(F("File '"));
      m_pBroadcastSerial->print(fstrFileName);
      m_pBroadcastSerial->println(F("' was not found!"));  
    }
  }
  void CDebug::logFileOpenError(const __FlashStringHelper* fstrFileName)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(F("File '"));
        m_fileLog.write(fstrFileName);
        m_fileLog.writeLine(F("' could not be opened!"));  
      }
    #endif
    m_pSerial->print(F("File '"));
    m_pSerial->print(fstrFileName);
    m_pSerial->println(F("' could not be opened!"));  
 
    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(F("File '"));
      m_pBroadcastSerial->print(fstrFileName);
      m_pBroadcastSerial->println(F("' could not be opened!"));  
    }
  }
  
  void CDebug::logFileReadError(const __FlashStringHelper* fstrFileName)
  {
    #ifdef LOGFILE
      if (m_fileLog)
      {
        m_fileLog.write(F("Error while reading file '"));
        m_fileLog.write(fstrFileName);
        m_fileLog.writeLine(F("'!"));  
      }
    #endif
    m_pSerial->print(F("Error while reading file '"));
    m_pSerial->print(fstrFileName);
    m_pSerial->println(F("'!"));  

    if (m_pBroadcastSerial)
    {
      m_pBroadcastSerial->print(F("Error while reading file '"));
      m_pBroadcastSerial->print(fstrFileName);
      m_pBroadcastSerial->println(F("'!"));  
    }
  }  
#endif

CDebug debug(&Serial);
