#line 2 "Buttons.cpp"
#include <Arduino.h>
#include "Buttons.h"
#include "Debug.h"




CButton::CButton(const bool bActiveHigh, const uint16_t nMillisTimeOut): m_strName(m_buff)
{
  m_nMillisLastClick = 0;
  m_bActiveHigh = bActiveHigh;
  m_nMillisTimeOut = nMillisTimeOut;
}

CButton::~CButton()
{
}

void CButton::setName(const char *cstrName)
{
  m_strName = cstrName;
}

void CButton::setName(const __FlashStringHelper *fstrName)
{
  m_strName = fstrName;
}

char *CButton::getName()
{
  return m_strName;
}

bool CButton::isClicked()
{
  bool bClicked = false;
  uint32_t nMillisElapsed = millis() - m_nMillisLastClick;

  //DUMP_VAR(m_nMillisLastClick);
  //DUMP_VAR(millis());
  //DUMP_VAR(nMillisElapsed);

  if (nMillisElapsed >= m_nMillisTimeOut)
  {
    m_nMillisLastClick = millis();
    bClicked = true;
  }
  return bClicked;
}




CPushButton::CPushButton(const uint8_t nPin, const bool bActiveHigh, const uint16_t nMillisTimeOut): CButton(bActiveHigh, nMillisTimeOut)
{
  m_nPin = nPin;
}

CPushButton::~CPushButton()
{
  m_nPin = 0;
  m_strName.empty();
}

void CPushButton::begin()
{
  if (m_bActiveHigh)
    pinMode(m_nPin, INPUT);
  else
    pinMode(m_nPin, INPUT_PULLUP);
}  

bool CPushButton::isClicked()
{
  bool bClicked = false;

  if ((m_bActiveHigh && (digitalRead(m_nPin) == HIGH)) || (!m_bActiveHigh && (digitalRead(m_nPin) == LOW)))
  {
    bClicked = CButton::isClicked();
    if (bClicked)
    {
      debug.log(m_strName, false);
      debug.log(F(" clicked!"));
    }
  }
  return bClicked;
}




CCapacitiveButton::CCapacitiveButton(const uint8_t nSendPin, const uint8_t nReceivePin): CButton(false), m_csButton(nSendPin, nReceivePin)
{
}

CCapacitiveButton::~CCapacitiveButton()
{
}

void CCapacitiveButton::begin()
{
}

bool CCapacitiveButton::isClicked()
{
  long nResult = m_csButton.capacitiveSensor(30);
  bool bClicked = false;

  if (nResult > 500)
    bClicked = CButton::isClicked();
  
  return bClicked;
}




CToggleButton::CToggleButton(const uint8_t nPin, const bool bActiveHigh, const uint16_t nMillisTimeOut): CButton(bActiveHigh, nMillisTimeOut)
{
  m_nPin = nPin;
}

CToggleButton::~CToggleButton()
{
  m_nPin = 0;
  m_strName.empty();
}

void CToggleButton::begin()
{
  if (m_bActiveHigh)
    pinMode(m_nPin, INPUT);
  else
    pinMode(m_nPin, INPUT_PULLUP);
}

bool CToggleButton::isOn()
{
  bool bIsOn = (m_bActiveHigh && digitalRead(m_nPin) == HIGH) || (!m_bActiveHigh && digitalRead(m_nPin) == LOW);

  return bIsOn;
}
