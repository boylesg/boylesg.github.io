#line 2 "DateTime.cpp"
#include <Arduino.h>
#include <RealTimeClockDS1307.h>
#include "DateTime.h"
#include "Common.h"
#include "Debug.h"
#include "CString.h"




const uint16_t g_nCentury = 2000;

CBuff<32> buffDateTime;

bool isLeapYear(const uint16_t nYear)
{
  return (((nYear % 4) == 0) && ((nYear % 100) != 0)) || ((nYear % 400) == 0);
}

uint8_t getMaxDOM(const uint8_t nMonth, const uint16_t nYear)
{
  int16_t nMaxDOM = 0;

  if ((nMonth == 1) || (nMonth == 3) || (nMonth == 5) || (nMonth == 7) || (nMonth == 8) || (nMonth == 10) || (nMonth == 12))
    nMaxDOM = 31;
  else if ((nMonth == 4) || (nMonth == 6) || (nMonth == 9) || (nMonth == 11))
    nMaxDOM = 30;
  else if (nMonth == 2)
  {
    if (isLeapYear(nYear))
      nMaxDOM = 29;
    else
      nMaxDOM = 28;
  }
  return nMaxDOM;
}

void getMonthName(const uint8_t nMonthNum, const bool bShort, CString &strMonthName)
{
  if (nMonthNum == 1)
	  strMonthName = F("January");
  else if (nMonthNum == 2)
	strMonthName = F("February");
  else if (nMonthNum == 3)
	strMonthName = F("March");
  else if (nMonthNum == 4)
	strMonthName = F("April");
  else if (nMonthNum == 5)
	strMonthName = F("May");
  else if (nMonthNum == 6)
	strMonthName = F("June");
  else if (nMonthNum == 7)
	strMonthName = F("July");
  else if (nMonthNum == 7)
	strMonthName = F("August");
  else if (nMonthNum == 7)
	strMonthName = F("September");
  else if (nMonthNum == 7)
	strMonthName = F("October");
  else if (nMonthNum == 7)
	strMonthName = F("November");
  else if (nMonthNum == 7)
	strMonthName = F("December");
  else
    strMonthName = F("Invalid day number");

  if ((strMonthName.length() > 3) && bShort)
    strMonthName[3] = 0;
}

void getDayName(const uint8_t nDayNum, const bool bShort, CString &strDayName)
{ 
  if (nDayNum == 1)
    strDayName = F("Sunday");
  else if (nDayNum == 2)
    strDayName = F("Monday");
  else if (nDayNum == 3)
    strDayName = F("Tuesday");
  else if (nDayNum == 4)
    strDayName = F("Wednesday");
  else if (nDayNum == 5)
    strDayName = F("Thursday");
  else if (nDayNum == 6)
    strDayName = F("Friday");
  else if (nDayNum == 7)
    strDayName = F("Saturday");
  else
    strDayName = F("Invalid day number");

  if ((strDayName.length() > 3) && bShort)
    strDayName[3] = 0;
}

uint8_t calcDOW(const uint8_t nDOM, const uint8_t nMonth, uint16_t nYear)
{
  uint8_t nDOW = 0;
  int arrayCenturyTable[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};

  if ((nMonth >= 1) && (nMonth <= 12) && (nDOM >= 1) && (nDOM <= getMaxDOM(nMonth, nYear)) && (nYear > 0))
  {
    nYear -= nMonth < 3;
    nDOW = ((nYear + (nYear / 4) - (nYear / 100) + (nYear / 400) + arrayCenturyTable[nMonth - 1] + nDOM) % 7) + 1;
  }
  return nDOW;
}

bool isNumeric(const char* str)
{
  bool bResult = true;

  for (uint8_t nI = 0; nI < strlen(str); nI++)
    bResult &= isDigit(str[nI]);

  return bResult;
}




CShortDate::CShortDate()
{
    m_nDOM = m_nMonth = 0;
}

CShortDate::CShortDate(CShortDate& date)
{
  set(date.m_nDOM, date.m_nMonth);
}

CShortDate::CShortDate(RealTimeClockDS1307& rtc)
{
  set(rtc);
}
 
CShortDate::CShortDate(const uint8_t nDOM, const uint8_t nMonth)
{
  set(nDOM, nMonth);
}
 
CShortDate::~CShortDate()
{
}

void CShortDate::dump()
{
  debug.dump(F("m_nDOM"), m_nDOM);
  debug.dump(F("m_nMonth"), m_nMonth);
}

void CShortDate::addDays(const int8_t nDays, const uint16_t nStartYear)
{
  uint16_t nCurrYear = nStartYear;
  
  if (nDays > 0)
  {
    for (uint8_t nI = 0; nI < nDays; nI++)
    {
      m_nDOM++;
      if (m_nDOM > ::getMaxDOM(m_nMonth, nCurrYear))
      {
        m_nDOM = 1;
        m_nMonth++;

        if (m_nMonth > 12)
        {
      nCurrYear++;
          m_nMonth = m_nMonth % 12;
        }
      }
    }
  }
  else if (nDays < 0)
  {
    for (uint8_t nI = 0; nI > nDays; nI--)
    {
      m_nDOM--;
      if (m_nDOM <= 0)
      {
        m_nMonth--;
        if (m_nMonth <= 0)
        {
      nCurrYear--;
          m_nMonth = 12;
          m_nDOM = ::getMaxDOM(m_nMonth, nCurrYear);
        }
        else
        {
          m_nDOM = ::getMaxDOM(m_nMonth, nCurrYear);
        }
      }
    }
  }
}

bool CShortDate::isValid()
{
  return (m_nMonth >= 1) && (m_nMonth <= 12) && (m_nDOM >= 1) && (m_nDOM <= ::getMaxDOM(m_nMonth, getYear()));
}

bool CShortDate::parse(const char* str)
{
  bool bResult = true;
  CBuff<32> buffDate;
  CString strDate(buffDate);

  strDate = str;
  if (strDate.length() > 0)
  {
    int8_t nPos1 = strDate.indexOf(F("/")), nPos2 = strDate.indexOf(F("/"), nPos1 + 1);
    CBuff<16> buffTemp;
    CString strTemp(buffTemp);

    // Day of month and month only
    if ((nPos1 > -1) && (nPos2 == -1))
    {
      strTemp = strDate.substring(0, nPos1 - 1);
      bResult &= isNumeric(strTemp.c_str());
      m_nDOM = strTemp.toInt();
      strTemp = strDate.substring(nPos1 + 1, strDate.length());
      bResult &= isNumeric(strTemp.c_str());
      m_nMonth = strTemp.toInt();
    }
    // Day of month, month and year
    else if ((nPos1 > -1) && (nPos2 > -1))
    {
      strTemp = strDate.substring(0, nPos1 - 1);
      bResult &= isNumeric(strTemp.c_str());
      m_nDOM = strTemp.toInt();
      strTemp = strDate.substring(nPos1 + 1, nPos2 - 1);
      bResult &= isNumeric(strTemp.c_str());
      m_nMonth = strTemp.toInt();
    }
  }
  else
    empty();
      
  return bResult;
}

uint16_t CShortDate::getYear(const bool bTwoDigit)
{
  RealTimeClockDS1307 rtc;
  rtc.readClock();

  if (bTwoDigit)
    return rtc.getYear();
  else
    return rtc.getYear() + g_nCentury;
}

const char* CShortDate::toString(const bool bIncludeDOW)
{
  CBuff<6> buffDOM, buffMonth;
  CString strDOM(buffDOM), strMonth(buffMonth);
  CString str(buffDateTime);

  str.empty();
  if (isValid())
  {
    if (bIncludeDOW && isValid())
    {
      getDayName(calcDOW(m_nDOM, m_nMonth, getYear()), false, str);
      str += F(", ");
    }
    strDOM = fromUint(m_nDOM, 10);
    strMonth = fromUint(m_nMonth, 10);
    str += strDOM;
    str += F("/");
    str += strMonth;
  }
  return str;
}

bool CShortDate::isEmpty()
{
  return (m_nDOM == 0) && (m_nMonth == 0);
}

uint16_t CShortDate::getDOY()
{
  RealTimeClockDS1307 rtc;
  uint16_t nDOY = 0;

  rtc.readClock();
  for (uint8_t nI = 1; nI < m_nMonth; nI++)
     nDOY += ::getMaxDOM(m_nMonth, rtc.getYear());
  nDOY += m_nDOM;
  
  return nDOY;
}

void CShortDate::set(RealTimeClockDS1307& rtc)
{
  rtc.readClock();
  m_nDOM = rtc.getDate();
  m_nMonth = rtc.getMonth();
}

void CShortDate::set(const uint8_t nDOM, const uint8_t nMonth)
{
  m_nDOM = nDOM;
  m_nMonth = nMonth;
}

CShortDate &CShortDate::operator =(CShortDate &dateOther)
{
  m_nDOM = dateOther.m_nDOM;
  m_nMonth = dateOther.m_nMonth;
  return *this;
} 

bool CShortDate::operator ==(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(); 
  return nDOY == nDOYOther;
}

bool CShortDate::operator >=(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY();
  
  return (nDOY == nDOYOther) || (nDOY > nDOYOther);
}

bool CShortDate::operator >(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(); 
  return (nDOY > nDOYOther);
}

bool CShortDate::operator <=(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY();
  
  return (nDOY == nDOYOther) || (nDOY < nDOYOther);
}

bool CShortDate::operator <(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY();
  
  return (nDOY < nDOYOther);
}

bool CShortDate::operator !=(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY();
  
  return (nDOY != nDOYOther);
}

bool CShortDate::operator ==(CDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY == nDOYOther);
}

bool CShortDate::operator >=(CDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY == nDOYOther) || (nDOY > nDOYOther);
}

bool CShortDate::operator >(CDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY > nDOYOther);
}

bool CShortDate::operator <=(CDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY == nDOYOther) || (nDOY < nDOYOther);
}

bool CShortDate::operator <(CDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY < nDOYOther);
}

bool CShortDate::operator !=(CDate& dateOther)
{
  uint8_t nDOY = getDOY(), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY != nDOYOther);
}




CDate::CDate()
{
    m_nDOM = m_nMonth = 0;
    m_nYear = 0;
}

CDate::CDate(CDate& date)
{
  set(date.m_nDOM, date.m_nMonth, date.m_nYear);
}

CDate::CDate(RealTimeClockDS1307& rtc)
{
  set(rtc);
}
 
CDate::CDate(const uint8_t nDOM, const uint8_t nMonth, const uint16_t nYear)
{
  set(nDOM, nMonth, nYear);
}
 
CDate::~CDate()
{
}

void CDate::dump()
{
  debug.dump(F("m_nDOM"), m_nDOM);
  debug.dump(F("m_nMonth"), m_nMonth);
  debug.dump(F("m_nYear"), m_nYear);
}

int16_t CDate::getYear(const bool bTwoDigit)
{
  if (bTwoDigit)
    return m_nYear - g_nCentury;
  else
    return m_nYear;
}

void CDate::addDays(const int8_t nDays)
{
  if (nDays > 0)
  {
    for (uint8_t nI = 0; nI < nDays; nI++)
    {
      m_nDOM++;
      if (m_nDOM > ::getMaxDOM(m_nMonth, m_nYear))
      {
        m_nDOM = 1;
        m_nMonth++;

        if (m_nMonth > 12)
        {
          m_nMonth = 1;
          m_nYear++;
        }
      }
    }
  }
  else if (nDays < 0)
  {
    for (uint8_t nI = 0; nI > nDays; nI--)
    {
      m_nDOM--;
      if (m_nDOM <= 0)
      {
        m_nMonth--;
        if (m_nMonth <= 0)
        {
          m_nMonth = 12;
          m_nYear--;
          m_nDOM = ::getMaxDOM(m_nMonth, m_nYear);
        }
        else
        {
          m_nDOM = ::getMaxDOM(m_nMonth, m_nYear);
        }
      }
    }
  }
}

bool CDate::isValid()
{
  return (m_nMonth >= 1) && (m_nMonth <= 12) && (m_nDOM >= 1) && (m_nDOM <= ::getMaxDOM(m_nMonth, m_nYear));
}

void CDate::setYear(const uint16_t nYear)
{
  m_nYear = nYear;
  if (m_nYear < g_nCentury)
    m_nYear += g_nCentury;
}

bool CDate::parse(const char* str)
{
  bool bResult = true;
  CBuff<32> buffDateTime;
  CString strDate(buffDateTime);

  strDate = str;
  if (strDate.length() > 0)
  {
    int8_t nPos1 = strDate.indexOf(F("/")), nPos2 = strDate.indexOf(F("/"), nPos1 + 1);
    CBuff<16> buffDateTimeTemp;
    CString strTemp(buffDateTimeTemp);

    // Day of month and month only
    if ((nPos1 > -1) && (nPos2 == -1))
    {
      strTemp = strDate.substring(0, nPos1 - 1);
      bResult &= isNumeric(strTemp.c_str());
      m_nDOM = strTemp.toInt();
      strTemp = strDate.substring(nPos1 + 1, strDate.length());
      bResult &= isNumeric(strTemp.c_str());
      m_nMonth = strTemp.toInt();
      RealTimeClockDS1307 rtc;
      rtc.readClock();
      m_nYear = g_nCentury + rtc.getYear();
    }
    // Day of month, month and year
    else if ((nPos1 > -1) && (nPos2 > -1))
    {
      strTemp = strDate.substring(0, nPos1 - 1);
      bResult &= isNumeric(strTemp.c_str());
      m_nDOM = strTemp.toInt();
      strTemp = strDate.substring(nPos1 + 1, nPos2 - 1);
      bResult &= isNumeric(strTemp.c_str());
      m_nMonth = strTemp.toInt();
      strTemp = strDate.substring(nPos2 + 1, strDate.length());
      bResult &= isNumeric(strTemp.c_str());
      m_nYear = strTemp.toInt();

      if (m_nYear < 100)
        m_nYear += g_nCentury;
    }
    bResult = isValid();
  }
  else
    empty();
      
  return bResult;
}

const char* CDate::toString(const bool bIncludeDOW, const bool bIncludeYear)
{
  CBuff<3> buffDOM, buffMonth;
  CBuff<4> buffYear;
  CString strDOM(buffDOM), strMonth(buffMonth), strYear(buffYear), strDateTime(buffDateTime, true);

  if (isValid())
  {
    if (bIncludeDOW)
    {
      getDayName(calcDOW(m_nDOM, m_nMonth, m_nYear), false, strDateTime);
      strDateTime += F(", ");
    }
    strDOM = fromUint(m_nDOM, 10);
    strMonth = fromUint(m_nMonth, 10);
    strYear = fromUint(m_nYear, 10);
  
    strDateTime += strDOM;
    strDateTime += F("/");
    strDateTime += strMonth;
  
    if (bIncludeYear)
    {
      strDateTime += F("/");
      strDateTime += strYear;
    }
  }
  return strDateTime;
}

bool CDate::isEmpty()
{
  return (m_nDOM == 0) && (m_nMonth == 0);
}

uint16_t CDate::getDOY(const uint16_t nYearOther)
{
  uint16_t nDOY = 0;
  
  for (uint8_t nI = 1; nI < m_nMonth; nI++)
     nDOY += ::getMaxDOM(m_nMonth, m_nYear);
  nDOY += m_nDOM;

  if (m_nYear > nYearOther)
    nDOY += 365;
  
  return nDOY;
}

void CDate::set(RealTimeClockDS1307& rtc)
{
  rtc.readClock();
  m_nDOM = rtc.getDate();
  m_nMonth = rtc.getMonth();
  m_nYear = rtc.getYear() + g_nCentury;
}

void CDate::set(const uint8_t nDOM, const uint8_t nMonth, const uint16_t nYear)
{
  m_nDOM = nDOM;
  m_nMonth = nMonth;
  m_nYear = nYear;
}

CDate &CDate::operator =(CDate &dateOther)
{
  m_nDOM = dateOther.m_nDOM;
  m_nMonth = dateOther.m_nMonth;
  m_nYear = dateOther.m_nYear;
  return *this;
} 

bool CDate::operator ==(CDate& dateOther)
{
  uint8_t nDOY = getDOY(dateOther.m_nYear), nDOYOther = dateOther.getDOY(dateOther.m_nYear);

  return (nDOY == nDOYOther);
}

bool CDate::operator >=(CDate& dateOther)
{
  uint8_t nDOY = getDOY(dateOther.m_nYear), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY == nDOYOther) || (nDOY > nDOYOther);
}

bool CDate::operator >(CDate& dateOther)
{
  uint8_t nDOY = getDOY(dateOther.m_nYear), nDOYOther = dateOther.getDOY(dateOther.m_nYear);

  return (nDOY > nDOYOther);
}

bool CDate::operator <=(CDate& dateOther)
{
  uint8_t nDOY = getDOY(dateOther.m_nYear), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY == nDOYOther) || (nDOY < nDOYOther);
}

bool CDate::operator <(CDate& dateOther)
{
  uint8_t nDOY = getDOY(dateOther.m_nYear), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY < nDOYOther);
}

bool CDate::operator !=(CDate& dateOther)
{
  uint8_t nDOY = getDOY(dateOther.m_nYear), nDOYOther = dateOther.getDOY(dateOther.m_nYear);
  
  return (nDOY != nDOYOther);
}

bool CDate::operator ==(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(m_nYear), nDOYOther = dateOther.getDOY();
  
  return (nDOY == nDOYOther);
}

bool CDate::operator >=(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(m_nYear), nDOYOther = dateOther.getDOY();
  
  return (nDOY == nDOYOther) || (nDOY > nDOYOther);
}

bool CDate::operator >(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(m_nYear), nDOYOther = dateOther.getDOY();
  
  return (nDOY > nDOYOther);
}

bool CDate::operator <=(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(m_nYear), nDOYOther = dateOther.getDOY();
  
  return (nDOY == nDOYOther) || (nDOY < nDOYOther);
}

bool CDate::operator <(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(m_nYear), nDOYOther = dateOther.getDOY();
  
  return (nDOY < nDOYOther);
}

bool CDate::operator !=(CShortDate& dateOther)
{
  uint8_t nDOY = getDOY(m_nYear), nDOYOther = dateOther.getDOY();
  
  return (nDOY != nDOYOther);
}




CShortTime::CShortTime()
{
  m_nHours = m_nMinutes = 0;
}

CShortTime::CShortTime(RealTimeClockDS1307& rtc)
{
  set(rtc);
}

CShortTime::~CShortTime()
{
}

void CShortTime::dump()
{
  debug.dump(F("m_nHours"), m_nHours);
  debug.dump(F("m_nMinutes"), m_nMinutes);
}

bool CShortTime::parse(const char* str)
{
  bool bResult = false;
  CBuff<16> buffDateTimeTime;
  CString strTime(buffDateTimeTime, true);
  strTime = str;
  
  if (strTime.length() > 0)
  {
    int8_t nPos = strTime.indexOf(':');
    CBuff<16> buffTemp;
    CString strTemp(buffTemp);
    
    // Hours and minutes
    if (nPos > -1)
    {
      strTemp = strTime.substring(0, nPos - 1);
      bResult = isNumeric(strTemp.c_str());
      m_nHours = atoi(strTemp.c_str());
      strTemp = strTime.substring(nPos + 1, strTime.length());
      bResult &= isNumeric(strTemp.c_str());
      m_nMinutes = atoi(strTemp.c_str());
    }
   }
  else
    empty();

  return bResult;
}

const char* CShortTime::toString()
{
  CString str(buffDateTime);
  str.empty();
  str.format(F("%02d:%02d"), m_nHours, m_nMinutes);
  
  return str;
}


bool CShortTime::isValid()
{
  return (m_nHours >= 0) && (m_nHours <= 23) && (m_nMinutes >= 0) && (m_nMinutes <= 59);
}

void CShortTime::set(RealTimeClockDS1307& rtc)
{
  rtc.readClock();
  if (rtc.is12hour())
  {
    if (rtc.isPM() && (rtc.getHours() < 12))
    {
      m_nHours = rtc.getHours() + 12;
    }
    else if (!rtc.isPM() && (rtc.getHours() == 12))
    {
      m_nHours = 0;
    }
    else
    {
      m_nHours = rtc.getHours();
    }
  }
  else
  {
    m_nHours = rtc.getHours();
  }
  m_nMinutes = rtc.getMinutes();
}

void CShortTime::set(const uint8_t nHour, const uint8_t nMinute)
{
  m_nHours = nHour;
  m_nMinutes = nMinute;


  if (!isValid())
    m_nHours = m_nMinutes = 0;
}

CShortTime &CShortTime::operator =(CShortTime &timeOther)
{
  m_nHours = timeOther.m_nHours;
  m_nMinutes = timeOther.m_nMinutes;
  return *this;
} 

bool CShortTime::operator ==(CShortTime& timeOther)
{
  return convertSeconds() == timeOther.convertSeconds();
}

bool CShortTime::operator >=(CShortTime& timeOther)
{
  return convertSeconds() >= timeOther.convertSeconds();
}

bool CShortTime::operator >(CShortTime& timeOther)
{
  return convertSeconds() > timeOther.convertSeconds();
}

bool CShortTime::operator <=(CShortTime& timeOther)
{
  return convertSeconds() <= timeOther.convertSeconds();
}

bool CShortTime::operator <(CShortTime& timeOther)
{
  return convertSeconds() < timeOther.convertSeconds();
}

bool CShortTime::operator !=(CShortTime& timeOther)
{
  return convertSeconds() != timeOther.convertSeconds();
}

bool CShortTime::operator ==(CTime& timeOther)
{
  return convertSeconds() == timeOther.convertSeconds();
}

bool CShortTime::operator >=(CTime& timeOther)
{
  return convertSeconds() >= timeOther.convertSeconds();
}

bool CShortTime::operator >(CTime& timeOther)
{
  return convertSeconds() > timeOther.convertSeconds();
}

bool CShortTime::operator <=(CTime& timeOther)
{
  return convertSeconds() <= timeOther.convertSeconds();
}

bool CShortTime::operator <(CTime& timeOther)
{
  return convertSeconds() < timeOther.convertSeconds();
}

bool CShortTime::operator !=(CTime& timeOther)
{
  return convertSeconds() != timeOther.convertSeconds();
}

uint32_t CShortTime::convertSeconds()
{
  return ((uint32_t)m_nHours * 60 * 60) + ((uint32_t)m_nMinutes * 60);
}

int32_t CShortTime::operator -(CShortTime& timeOther)
{
  // Assumption: timeOther is prior to this time.
  int32_t nSecsThis = ((int32_t)m_nHours * 60 * 60) + (m_nMinutes * 60),
            nSecsOther = ((int32_t)timeOther.m_nHours * 60 * 60) + (timeOther.m_nMinutes * 60);
  
  return nSecsThis - nSecsOther;
}

int32_t CShortTime::operator -(CTime& timeOther)
{
  // Assumption: timeOther is prior to this time.
  int32_t nSecsThis = ((int32_t)m_nHours * 60 * 60) + (m_nMinutes * 60),
            nSecsOther = ((int32_t)timeOther.m_nHours * 60 * 60) + (timeOther.m_nMinutes * 60);
  return nSecsThis - nSecsOther;
}

bool CShortTime::equalApprox(CShortTime& timeNow, const uint8_t nMinutes)
{
  return abs(m_nMinutes - timeNow.m_nMinutes) <= nMinutes;
}

void CShortTime::addSeconds(const int8_t nSeconds)
{
  addMins(nSeconds / 60);
}

void CShortTime::addMins(const int8_t nMinutes)
{
  int16_t nMinTemp = m_nMinutes;
  
  addHours(nMinutes / 60);
  if ((nMinutes % 60) != 0)
  {
    nMinTemp += nMinutes % 60;
    if ((nMinTemp > 60) || (nMinTemp < -60))
    {
    m_nMinutes = nMinTemp % 60;
    addHours(1);
    }
    else
      m_nMinutes = nMinTemp;
  }
}

void CShortTime::addHours(const int8_t nHours)
{
  int16_t nHourTemp = m_nHours;
  
  if ((nHours % 24) != 0)
  {
    nHourTemp += nHours % 24;
    if ((nHourTemp >= 24) || (nHourTemp < -24))
    {
      m_nHours = nHourTemp % 24;
    }
    else
    {
      m_nHours = nHourTemp;   
    }
  }
}




CTime::CTime()
{
  m_nDOY = m_nHours = m_nMinutes = m_nSeconds = 0;
}

CTime::CTime(RealTimeClockDS1307& rtc)
{
  set(rtc);
}

CTime::~CTime()
{
}

void CTime::dump()
{
  debug.dump(F("m_nDOY"), m_nDOY);
  debug.dump(F("m_nHours"), m_nHours);
  debug.dump(F("m_nMinutes"), m_nMinutes);
  debug.dump(F("m_nSeconds"), m_nSeconds);
}

bool CTime::parse(const char* str)
{
  bool bResult = false;
  CBuff<16> buffDateTimeTime;
  CString strTime(buffDateTimeTime, true);
  strTime = str;
  
  if (strTime.length() > 0)
  {
    int8_t nPos1 = strTime.indexOf(':'), nPos2 = strTime.indexOf(':', nPos1 + 1);
    CBuff<16> buffDateTimeTemp;
    CString strTemp(buffDateTimeTemp);

    // Hours and minutes
    if ((nPos1 > -1) && (nPos2 == -1))
    {
      strTemp = strTime.substring(0, nPos1 - 1);
      bResult = isNumeric(strTemp.c_str());
      m_nHours = atoi(strTemp.c_str());
      strTemp = strTime.substring(nPos1 + 1, strTime.length());
      bResult &= isNumeric(strTemp.c_str());
      m_nMinutes = atoi(strTemp.c_str());
    }
    // Hours,  minutes and sconds
    else if ((nPos1 > -1) && (nPos2 > -1))
    {
      strTemp = strTime.substring(0, nPos1);
      bResult = isNumeric(strTemp.c_str());
      m_nHours = atoi(strTemp.c_str());
      strTemp = strTime.substring(nPos1 + 1, nPos2);
      bResult &= isNumeric(strTemp.c_str());
      m_nMinutes = atoi(strTemp.c_str());
      strTemp = strTime.substring(nPos2 + 1, strTime.length());
      bResult &= isNumeric(strTemp.c_str());
      m_nSeconds = atoi(strTemp.c_str());
    }
  }
  else
    empty();
    
  RealTimeClockDS1307 rtc;
  rtc.readClock();
  CDate date(rtc);
  m_nDOY = date.getDOY(date.getYear());

  return bResult;
}

const char* CTime::toString(const bool bIncludeSeconds)
{
  CString str(buffDateTime);
  
  str.empty();
  if (bIncludeSeconds)
    str.format(F("%02d:%02d:%02d"), m_nHours, m_nMinutes, m_nSeconds);
  else
    str.format(F("%02d:%02d"), m_nHours, m_nMinutes);
  
  return str;
}

bool CTime::isValid()
{
  return (m_nHours >= 0) && (m_nHours <= 23) && (m_nMinutes >= 0) && (m_nMinutes <= 59) && (m_nSeconds >= 0) && (m_nSeconds <= 59);
}

void CTime::set(RealTimeClockDS1307& rtc)
{
  rtc.readClock();
  if (rtc.is12hour())
  {
    if (rtc.isPM() && (rtc.getHours() < 12))
    {
      m_nHours = rtc.getHours() + 12;
    }
    else if (!rtc.isPM() && (rtc.getHours() == 12))
    {
      m_nHours = 0;
    }
    else
    {
      m_nHours = rtc.getHours();
    }
  }
  else
  {
    m_nHours = rtc.getHours();
  }
  m_nMinutes = rtc.getMinutes();
  m_nSeconds = rtc.getSeconds();
  CDate date(rtc);
  m_nDOY = date.getDOY(date.getYear());
}

void CTime::set(const uint16_t nDOY, const uint8_t nHour, const uint8_t nMinute, const uint8_t nSecond)
{
  m_nHours = nHour;
  m_nMinutes = nMinute;
  m_nSeconds = nSecond;
  m_nDOY = nDOY;

  if (!isValid())
    m_nHours = m_nMinutes = m_nSeconds = 0;
}

void CTime::set(const uint8_t nHour, const uint8_t nMinute, const uint8_t nSecond)
{
  m_nDOY = 0;
  m_nHours = nHour;
  m_nMinutes = nMinute;
  m_nSeconds = nSecond;
}

void CTime::set(const uint8_t nHour, const uint8_t nMinute)
{
  m_nDOY = 0;
  m_nHours = nHour;
  m_nMinutes = nMinute;
  m_nSeconds = 0;
}

CTime &CTime::operator =(CTime &timeOther)
{
  m_nDOY = timeOther.m_nDOY;
  m_nHours = timeOther.m_nHours;
  m_nMinutes = timeOther.m_nMinutes;
  m_nSeconds = timeOther.m_nSeconds;
  return *this;
} 

CTime &CTime::operator =(CShortTime &timeOther)
{
  m_nHours = timeOther.m_nHours;
  m_nMinutes = timeOther.m_nMinutes;
  return *this;
}

bool CTime::operator ==(CTime& timeOther)
{
  return convertSeconds() == timeOther.convertSeconds();
}

bool CTime::operator >=(CTime& timeOther)
{
  return convertSeconds() >= timeOther.convertSeconds();
}

bool CTime::operator >(CTime& timeOther)
{
  return convertSeconds() > timeOther.convertSeconds();
}

bool CTime::operator <=(CTime& timeOther)
{
  return convertSeconds() <= timeOther.convertSeconds();
}

bool CTime::operator <(CTime& timeOther)
{
  return convertSeconds() < timeOther.convertSeconds();
}

bool CTime::operator !=(CTime& timeOther)
{
  return convertSeconds() != timeOther.convertSeconds();
}

bool CTime::operator ==(CShortTime& timeOther)
{
  return convertSeconds() == timeOther.convertSeconds();
}

bool CTime::operator >=(CShortTime& timeOther)
{
  return convertSeconds() >= timeOther.convertSeconds();
}

bool CTime::operator >(CShortTime& timeOther)
{
  return convertSeconds() > timeOther.convertSeconds();
}

bool CTime::operator <=(CShortTime& timeOther)
{
  return convertSeconds() <= timeOther.convertSeconds();
}

bool CTime::operator <(CShortTime& timeOther)
{
  return convertSeconds() < timeOther.convertSeconds();
}

bool CTime::operator !=(CShortTime& timeOther)
{
  return convertSeconds() != timeOther.convertSeconds();
}

uint32_t CTime::convertSeconds()
{
  return ((uint32_t)m_nHours * 60 * 60) + ((uint32_t)m_nMinutes * 60) + m_nSeconds;
}

bool is24HourRollOver(const uint8_t nHour1, const uint8_t nHour2)
{
  return ((nHour1 > 12) && (nHour2 < 12)) || ((nHour2 > 12) && (nHour1 < 12));
}

int32_t CTime::operator -(CTime& timeOther)
{
  // Assumption: timeOther is prior to this time.
  int32_t nSecsThis = ((int32_t)m_nDOY * 24 * 60 * 60) + (m_nHours * 60 * 60) + (m_nMinutes * 60) + m_nSeconds,
            nSecsOther = ((int32_t)timeOther.m_nDOY * 24 * 60 * 60) + (timeOther.m_nHours * 60 * 60) + (timeOther.m_nMinutes * 60) + timeOther.m_nSeconds;

  return nSecsThis - nSecsOther;
}

int32_t CTime::operator -(CShortTime& timeOther)
{
  // Assumption: timeOther is prior to this time.
  int32_t nSecsThis = ((int32_t)m_nHours * 60 * 60) + (m_nMinutes * 60),
            nSecsOther = ((int32_t)timeOther.m_nHours * 60 * 60) + (timeOther.m_nMinutes * 60);
  
  return nSecsThis - nSecsOther;
}

bool CTime::equalApprox(CTime& timeNow, const uint8_t nMinutes, const uint8_t nSeconds)
{
  return abs(m_nMinutes - timeNow.m_nMinutes) <= nMinutes;
}

void CTime::addSeconds(const int8_t nSeconds)
{
  int16_t nSecondsTemp = m_nSeconds;
  
  addMins(nSeconds / 60);
  if ((nSeconds % 60) != 0)
  {
    nSecondsTemp += nSeconds % 60;
    if ((nSecondsTemp >= 60) || (nSecondsTemp <= -60))
    {
      m_nSeconds = nSecondsTemp % 60;
      addMins(1);
    }
    else
      m_nSeconds = nSecondsTemp;
  }
}

void CTime::addMins(const int8_t nMinutes)
{
  int16_t nMinutesTemp = nMinutes;
  
  addHours(nMinutes / 60);
  if ((nMinutes % 60) != 0)
  {
    nMinutesTemp += nMinutes % 60;
    if ((nMinutesTemp >= 60) || (nMinutesTemp <= -60))
    {
      m_nMinutes = nMinutesTemp % 60;
      addMins(1);
    }
    else
      m_nMinutes = nMinutesTemp;
  }
}

void CTime::addHours(const int8_t nHours)
{
  int16_t nHoursTemp = m_nHours;
  
  m_nDOY += nHours / 24;

  if ((nHours % 24) != 0)
  {
    nHoursTemp += nHours % 24;
    if ((nHoursTemp >= 24) || (nHoursTemp <= -24))
    {
      m_nHours = nHoursTemp % 24;
      m_nDOY++;
    }
    else
    {
      m_nHours = nHoursTemp;
    }
  }
}




CDateTime::CDateTime()
{
}

CDateTime::CDateTime(RealTimeClockDS1307& rtc)
{
  m_date.set(rtc);
  m_time.set(rtc);
}

CDateTime::CDateTime(CDateTime& datetime)
{
  set(datetime.m_date.m_nDOM, datetime.m_date.m_nMonth, datetime.m_date.m_nYear, datetime.m_time.m_nHours, datetime.m_time.m_nMinutes, datetime.m_time.m_nSeconds);
}

CDateTime::CDateTime(const uint8_t nDOM, const uint8_t nMonth, const uint16_t nYear, const uint8_t nHours, const uint8_t nMinutes, const uint8_t nSeconds)
{
  set(nDOM, nMonth, nYear, nHours, nMinutes, nSeconds);
}
 
CDateTime::~CDateTime()
{
}

void CDateTime::dump()
{
  m_date.dump();
  m_time.dump();
}

CDateTime &CDateTime::operator =(CDateTime &datetime)
{
  m_time = datetime.m_time;
  m_date = datetime.m_date;
  return *this;
}

void CDateTime::set(RealTimeClockDS1307& rtc)
{
  m_date.set(rtc);
  m_time.set(rtc);
}

void CDateTime::set(const uint8_t nDOM, const uint8_t nMonth, const uint16_t nYear, const uint8_t nHours, const uint8_t nMinutes, const uint8_t nSeconds)
{
	m_date.set(nDOM, nMonth, nYear);
	m_time.set(m_date.getDOY(nYear), nHours, nMinutes, nSeconds);
}

const char* CDateTime::toString(const bool bIncludeSeconds, const bool bIncludeDOW, const bool bIncludeYear)
{
  CBuff<32> buffDate, buffTime;
  CString strDate(buffDate), strTime(buffTime);
  CString str(buffDateTime);

  strDate = m_date.toString(bIncludeDOW, bIncludeYear);
  strTime = m_time.toString(bIncludeSeconds);
  str = strDate;
  str += F(" ");
  str += strTime;

  return str;
}

bool CDateTime::isValid()
{
  return m_date.isValid() && m_time.isValid();
}
 
bool CDateTime::isEmpty()
{
  return m_date.isEmpty();
}

void CDateTime::addSeconds(const int8_t nSeconds)
{
  m_time.addSeconds(nSeconds);
}

void CDateTime::addMins(const int8_t nMinutes)
{
  m_time.addMins(nMinutes);
}

void CDateTime::addHours(const int8_t nHours)
{
	uint16_t nHoursTemp = m_time.getHours() + nHours;

  m_date.addDays(nHoursTemp / 24);
	m_time.set(m_date.getDOY(getYear(m_date.m_nYear)), nHoursTemp % 24, m_time.getMinutes(), m_time.getSeconds());
}

void CDateTime::adjustDaylightSavings()
{
  if (((m_date.getMonth() >= 10) && (m_date.getMonth() <= 12)) || ((m_date.getMonth() >= 1) && (m_date.getMonth() < 4)))
  {
    int8_t nHours = m_time.m_nHours + 1, nDays = 0;
    if (nHours == 24)
    {
      nHours = 0;
      nDays = 1;
    }
    m_time.m_nHours = nHours;
    m_date.addDays(nDays);
  }
}
