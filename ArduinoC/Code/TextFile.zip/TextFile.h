#line 2 "TextFile.h"
#pragma once




#ifdef ARDUINO_ESP32_DEV
  #include <SD.h>
#else
  #include "MySD.h"
#endif
#include "Common.h"
#include "CString.h"




#ifdef ARDUINO_ESP32_DEV
  #define READ          FILE_READ
  #define APPEND        FILE_APPEND
  #define REWRITE       FILE_WRITE
#else
  #define READ          O_READ
  #define READ_APPEND   (O_READ | O_WRITE | O_CREAT)
  #define APPEND        (O_WRITE | O_CREAT)
  #define REWRITE       (O_WRITE | O_CREAT | O_TRUNC)
#endif




class CTextFile
{
  public:
    // Construction, destruction and initialisation
    CTextFile();
    virtual ~CTextFile();

    bool readWord(CString& strWord);
    
    bool readWord(CString& strWord, const char cDelim);
        
    #if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
      bool open(const __FlashStringHelper* fstrFilename, const uint8_t nMode);
      bool open(const char* strFilename, const uint8_t nMode);
    #elif defined ARDUINO_ESP32_DEV
      bool open(const char* strFilename, const char* strMode);
    #elif defined __SAM3X8E__
      bool open(const char* strFilename, const uint8_t nMode);
    #endif
    uint32_t position()
    {
      return m_file.position();
    }
    void seek(uint32_t nFilePos)
    {
      m_file.seek(nFilePos);
    }
    char peek()
    {
      return m_file.peek();
    }
    char readChar()
    {
      return m_file.read();
    };
    bool readLine(CString& strLine, const bool bIncludeEOL = false, const bool bDebug = false);
    bool read(CString &strData);
    bool read(char* arrayBuff, const uint16_t nMaxLen)
    {
      #ifdef ARDUINO_ESP32_DEV
        return m_file.read((uint8_t*)arrayBuff, nMaxLen);
      #else
        return m_file.read(arrayBuff, nMaxLen);
      #endif
    }
    size_t write(const uint8_t *arrayBuff, size_t nBuffSize)
    {
      return m_file.write(arrayBuff, nBuffSize);
    };
    void write(const char* strText);
    #if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
      void write(const __FlashStringHelper* fstrText);
    #endif
    void write(const unsigned int nNum)
    {
      write((long unsigned int)nNum);
    };
    void write(const int nNum)
    {
      write((long int)nNum);
    };
    void write(const unsigned long int nNum);
    void write(const long int nNum);
    void write(const float fNum, const uint8_t nDecPlaces = 2)
    {
      write(fromReal((double)fNum, nDecPlaces));
    }
    void write(const double dNum, const uint8_t nDecPlaces = 2)
    {
      write(fromReal(dNum, nDecPlaces));
    }
    void write(const char cCh);
    
    #if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
      void writeLine(const __FlashStringHelper* fstrText);
    #endif
    void writeLine(const unsigned int nNum)
    {
      writeLine((unsigned long int)nNum);
    };
    void writeLine(const int nNum)
    {
      writeLine((long int)nNum);
    }
    void writeLine(const unsigned long int nNum);
    void writeLine(const long int nNum);
    void writeLine(const float fNum, const uint8_t nDecPlaces = 2)
    {
      writeLine(fromReal((double)fNum, nDecPlaces));
    }
    void writeLine(const double dNum, const uint8_t nDecPlaces = 2)
    {
      writeLine(fromReal(dNum, nDecPlaces));
    }
    void writeLine(const char cCh);
    void writeLine(const char* cstr);
    
    bool eof();
    uint16_t available()
    {
      return m_file.available();
    };
    
    void close()
    {
      m_file.close();
    };

    operator Stream&()
    {
      return m_file;
    };
    
    operator bool()
    {
      return m_file;
    };

    bool seekRel(int32_t nPos);
    uint32_t size()
    {
      return m_file.size();
    }

    void dump(const char* strFilename);

    const char* filename()
    {
      return m_file.name();
    };
    
  protected:
    File m_file;
};
