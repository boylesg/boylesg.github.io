#line 2 "TextFile.cpp"
#include <Arduino.h>
#include "Debug.h"
#include "TextFile.h"




CTextFile::CTextFile()
{
}

CTextFile::~CTextFile()
{
  m_file.close();
}

bool CTextFile::eof()
{
  return (m_file.available() == 0);
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
  bool CTextFile::open(const __FlashStringHelper* fstrFilename, const uint8_t nMode)
  {
    CBuff<24> buff;
    CString strFileName(buff);
    
    strFileName = fstrFilename;
    m_file = SD.open(strFileName, nMode);
    return m_file;
  }

  bool CTextFile::open(const char* strFilename, const uint8_t nMode)
  {
    m_file = SD.open(strFilename, nMode);
    return m_file;
  }
#elif defined ARDUINO_ESP32_DEV
  bool CTextFile::open(const char* strFilename, const char* strMode)
  {
    m_file = SD.open(strFilename, strMode);
    return m_file;
  }
#elif defined __SAM3X8E__
  bool CTextFile::open(const char* strFilename, const uint8_t nMode)
  {
    m_file = SD.open(strFilename, nMode);
    return m_file;
  }
#endif

bool CTextFile::read(CString &strData)
{
  char cChar = 0;

  strData.empty();
  if (m_file)
  {
    while (m_file.available() && (strData.length() < strData.maxLength()))
    {
      cChar = m_file.read();
      strData += cChar;
    }
  }
  return strData.length() > 0;
}

bool CTextFile::readLine(CString& strLine, const bool bIncludeEOL, const bool bDebug)
{
  char cChar = 0;
  bool bResult = false;

  strLine.empty();

  if (m_file)
  {
    while (m_file.available())
    {
      cChar = m_file.read();

      if ((cChar == '\n') || (cChar == '\r'))
      {
        if (bIncludeEOL)
          strLine += cChar;
        cChar = m_file.peek();

        if ((cChar == '\n') || (cChar == '\r'))
        {
          if (bIncludeEOL)
            strLine += cChar;
          m_file.read();
        }
        bResult = true;
        break;
      }
      else
      {
        if (bDebug)
        {
          debug.log(F("\""), false);
          debug.log(strLine, false);
          debug.log(F("\" + '"), false);
          debug.log(cChar, false);
          debug.log(F("' = \""), false);
        }
        strLine += cChar;
        if (bDebug)
        {
          debug.log(strLine, false);
          debug.log(F("\""), false);
        }
      }
    }
  }
  return bResult;
}

bool CTextFile::readWord(CString& strWord)
{
  strWord = F("");
  char cChar = 0;
  
  if (m_file)
  {
    while (m_file.available() && ((cChar > ' ') && (cChar <= '~')))
    {
      cChar = m_file.read();
	  if ((cChar > ' ') && (cChar <= '~'))
		strWord += cChar;
    }
  }
  return strWord.length() > 0;
}

bool CTextFile::readWord(CString& strWord, const char cDelim)
{
  strWord = F("");
  char cChar = 0;
  
  if (m_file)
  {
    while (m_file.available() && (cChar != cDelim))
    {
      cChar = m_file.read();
      strWord += cChar;
    }
  }
  return strWord.length() > 0;
}

#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
  void CTextFile::writeLine(const __FlashStringHelper* fstrText)
  {
    if (m_file)
    {
      m_file.println(fstrText);
    }
  }
#endif

void CTextFile::write(const long int nNum)
{
  if (m_file)
  {
    m_file.print(nNum);
  }
}

void CTextFile::write(const long unsigned int nNum)
{
  if (m_file)
  {
    m_file.print(nNum);
  }
}

void CTextFile::write(const char cCh)
{
  if (m_file)
  {
    m_file.print(cCh);
  }
}

void CTextFile::write(const char* strText)
{
  if (m_file)
  {
    m_file.print(strText);
  }
}

void CTextFile::writeLine(const char cCh)
{
  if (m_file)
  {
    m_file.println(cCh);
  }
}

void CTextFile::writeLine(const char* strText)
{
  if (m_file)
  {
    m_file.println(strText);
  }
}

void CTextFile::writeLine(const long int nVal)
{
  if (m_file)
  {
    m_file.println(nVal);
  }
}

void CTextFile::writeLine(const unsigned long int nVal)
{
  if (m_file)
  {
    m_file.println(nVal);
  }
}
#if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
  void CTextFile::write(const __FlashStringHelper* fstrText)
  {
    if (m_file)
    {
      m_file.print(fstrText);
    }
  }
#endif

bool CTextFile::seekRel(int32_t nPos)
{
  bool bResult = false;
  uint32_t nNewPos = m_file.position() + nPos;

  if ((nNewPos >= 0) && (nNewPos < m_file.size()))
  {
    bResult = true;
    m_file.seek(m_file.position() + nPos);
  }
  return bResult;
}

void CTextFile::dump(const char* strFilename)
{
  if (m_file)
  {
    close();

    open(strFilename, FILE_READ);
    if (m_file)
    {
      CBuff<128> buff;
      CString str(buff);
      
      debug.log(F("=========================================================================")); 
      debug.log(m_file.name());
      debug.log(F("=========================================================================")); 
      while (!eof())
      {
        readLine(str);
        debug.log(str);
      }
      debug.log(F("=========================================================================")); 
    }
    close();
  }
}
