#line 2 "MySD.h"
#pragma once

#include "Arduino.h"
#include <SPI.h>
#include <utility/SdFat.h>
#include <utility/SdFatUtil.h>

#define FILE_READ O_READ
#define FILE_WRITE (O_READ | O_WRITE | O_CREAT)


class File : public Stream {
 private:
  char _name[13]; // our name
  SdFile *_file;  // underlying file pointer

public:
  File(SdFile f, const char *name);     // wraps an underlying SdFile
  File(void);      // 'empty' constructor
  ~File(void);     // destructor
#if ARDUINO >= 100
  virtual size_t write(const uint8_t);
  virtual size_t write(const uint8_t *buf, size_t size);
#else
  virtual void write(const uint8_t);
  virtual void write(const uint8_t *buf, size_t size);
#endif
  String readLine();
  virtual int read();
  virtual int peek();
  virtual int available();
  virtual void flush();
  int read(void *buf, const uint16_t nbyte);
  boolean seek(const uint32_t pos);
  uint32_t position();
  uint32_t size();
  void close();
  operator bool();
  char * name();

  boolean isDirectory(void);
  File openNextFile(const uint8_t mode = O_RDONLY);
  void rewindDirectory(void);
  
  using Print::write;
};

class SDClass 
{
	private:
	  // These are required for initialisation and use of sdfatlib
	  Sd2Card card;
	  SdVolume volume;
	  SdFile root;
	  
	  // my quick&dirty iterator, should be replaced
	  SdFile getParentDir(const char *filepath, int *indx);
	public:
		SDClass()
		{
		};
		virtual ~SDClass()
		{
		};
		
	  // This needs to be called to set up the connection to the SD card
	  // before other methods are used.
	  //boolean begin(const uint8_t csPin = SD_CHIP_SELECT_PIN, const int8_t mosi = -1, const int8_t miso = -1, const int8_t sck = -1);
	  boolean begin(const uint8_t csPin, const int8_t mosi, const int8_t miso, const int8_t sck);
	  boolean begin(const uint8_t csPin)
	  {
		  return begin(csPin, card.getMOSI(), card.getMISO(), card.getSCLK());
	  };
	  boolean begin()
	  {
		  return begin(card.getCS(), card.getMOSI(), card.getMISO(), card.getSCLK());
	  };
	  
	  //call this when a card is removed. It will allow you to inster and initialise a new card.
	  void end(); 
	  
	  // Open the specified file/directory with the supplied mode (e.g. read or
	  // write, etc). Returns a File object for interacting with the file.
	  // Note that currently only one file can be open at a time.
	  File open(const char *filename, const uint8_t mode = FILE_READ);

	  // Methods to determine if the requested file path exists.
	  boolean exists(const char *filepath);

	  // Create the requested directory heirarchy--if intermediate directories
	  // do not exist they will be created.
	  boolean mkdir(const char *filepath);
	  
	  // Delete the file.
	  boolean remove(const char *filepath);
	  
	  boolean rmdir(const char *filepath);
	  
	  void enableCRC(const boolean mode);

	  uint8_t getCS()
	  {
		  return card.getCS();
	  };
	  uint8_t getMOSI()
	  {
		  return card.getMOSI();
	  };
	  uint8_t getMISO()
	  {
		  return card.getMISO();
	  };
	  uint8_t getSCLK()
	  {
		  return card.getSCLK();
	  };
	  
	private:

	  // This is used to determine the mode used to open a file
	  // it's here because it's the easiest place to pass the 
	  // information through the directory walking function. But
	  // it's probably not the best place for it.
	  // It shouldn't be set directly--it is set via the parameters to `open`.
	  int fileOpenMode;
	  
	  friend class File;
	  friend boolean callback_openPath(SdFile&, const char *, const boolean, const void *); 
};

extern SDClass SD;

#endif
