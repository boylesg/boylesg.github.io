#pragma once

#include <CapacitiveSensor.h>
#include "CBuff.h"
#include "CString.h"




class CButton
{
  public:
    CButton(const bool bActiveHigh, const uint16_t nMillisTimeOut = 200);
	  virtual ~CButton();
	
    virtual void begin() = 0;
    virtual bool isClicked();
    char *getName();
    void setName(const char *cstrName);
    void setName(const __FlashStringHelper *fstrName);
	
  protected:
    CBuff<16> m_buff;
    CString m_strName;
    uint32_t m_nMillisLastClick, m_nMillisTimeOut;
    bool m_bActiveHigh;

};




class CPushButton: public CButton
{
  public:
    CPushButton(const uint8_t nPin, const bool bActiveHigh, const uint16_t nMillisTimeOut);
    virtual ~CPushButton();

    virtual void begin();
    virtual bool isClicked();
    
  protected:  
    uint8_t m_nPin;
};




class CCapacitiveButton: public CButton
{
  public:
    CCapacitiveButton(const uint8_t nSendPin, const uint8_t nReceivePin);
    virtual ~CCapacitiveButton();

    virtual void begin();
    virtual bool isClicked();

  protected:  
    CapacitiveSensor m_csButton;
};




class CToggleButton: public CButton
{
  public:
    CToggleButton(const uint8_t nPin, const bool bActiveHigh, const uint16_t nMillisTimeOut);
    virtual ~CToggleButton();

    void begin();
    bool isOn();
    
  protected:  
    uint8_t m_nPin;
};
