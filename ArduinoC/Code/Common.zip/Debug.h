#line 2 "Debug.h"
#pragma once

#include <Arduino.h>
#include <assert.h>
#include <IPAddress.h>
#include <stdio.h>
#include "CString.h"
//#define LOGFILE 1
#ifdef LOGFILE
  #include "textfile.h"
#endif

#define RT_ERROR debug.logRuntimeError(F(__FILE__), __LINE__)
#define OPEN_RT_ERROR debug.openRuntimeError(F(__FILE__), __LINE__)
#define CLOSE_RT_ERROR debug.closeRuntimeError()
#define DUMP_VAR(VAR) debug.dump(#VAR, VAR);




class CDebug
{
  private:
    CDebug();
    
  public:
    // Construction, destruction and initialisation
    CDebug(Stream *pSerial = &Serial);
    virtual ~CDebug();


    // Interface
    void setSerial(Stream *pSerial);
    void setBroadcastSerial(Stream *pSerial);
    bool startLogFile();
    #ifdef LOGFILE
      bool openLogFile(CTextFile*& pLogFile);
      bool doneLogFile();
    #endif

    #if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
      void dumpPtr(const __FlashStringHelper* fstrVarName, const void *pPtr, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const unsigned long int nVal, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const long int nVal, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const unsigned int nVal, const bool bNewLine = true)
      {
        dump(fstrVarName, (unsigned long int)nVal, bNewLine);
      }
      void dump(const __FlashStringHelper* fstrVarName, const int nVal, const bool bNewLine = true)
      {
        dump(fstrVarName, (long int)nVal, bNewLine);
      }
      void dump(const __FlashStringHelper* fstrVarName, const float fVal, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const double dVal, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const char* cstr, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const char cChar, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const bool bVal, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, IPAddress IPAddr, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, const __FlashStringHelper* fstr, const bool bNewLine = true);
      void dump(const char* cstrVarName, const __FlashStringHelper* fstr, const bool bNewLine = true);
      void dump(const __FlashStringHelper* fstrVarName, CString &str, const bool bNewLine = true);
    #endif
    void dumpPtr(const char* cstrVarName, const void *pPtr, const bool bNewLine = true);
    void dump(const char* cstrVarName, CString &str, const bool bNewLine = true);
    void dump(const char* cstrVarName, const char* cstr, const bool bNewLine = true);
    void dump(const char* cstrVarName, const unsigned long int nVal, const bool bNewLine = true);
    void dump(const char* cstrVarName, const long int nVal, const bool bNewLine = true);
    void dump(const char* cstrVarName, const int nVal, const bool bNewLine = true)
    {
      dump(cstrVarName, (long int)nVal, bNewLine);
    }
    void dump(const char* cstrVarName, const unsigned int nVal, const bool bNewLine = true)
    {
      dump(cstrVarName, (long unsigned int)nVal, bNewLine);
    }
    void dump(const char* cstrVarName, const float fVal, const bool bNewLine = true);
    void dump(const char* cstrVarName, const double dVal, const bool bNewLine = true);
    void dump(const char* cstrVarName, const char cChar, const bool bNewLine = true);
    void dump(const char* cstrVarName, const bool bVal, const bool bNewLine = true);
    void dump(const char* cstrVarName, IPAddress IPAddr, const bool bNewLine = true);

    void logPtr(const void *pPtr, const bool bNewLine = true);
    void log(const unsigned long int nVal, const bool bNewLine = true);
    void log(const long int nVal, const bool bNewLine = true);
    void log(const unsigned int nVal, const bool bNewLine = true)
    {
      log((long unsigned int)nVal, bNewLine);
    };
    void log(const int nVal, const bool bNewLine = true)
    {
      log((long int)nVal, bNewLine);
    };
    void log(const float fVal, const bool bNewLine = true);
    void log(const double dVal, const bool bNewLine = true);
    void log(const char* cstr, const bool bNewLine = true);
    #if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
      void log(const __FlashStringHelper* fstr, const bool bNewLine = true);
    #endif
    
    void log(const char cChar, const bool bNewLine = true);
    void log(IPAddress IPAddr, const bool bNewLine = true);
    void logEvent(const char cCh, const char* cstrEventDesc)
    {
      logEventOpen(cCh, cstrEventDesc);
      logEventClose(cCh, F(""));
    }
    void logEventClose(const char cCh, const char* cstrEventResult);
    void logEventOpen(const char cCh, const char* cstrEventDesc, const bool bNewLine = false);
    void logRuntimeError(const char* cstrFileName, const uint16_t nLineNum);
    void openRuntimeError(const char* cstrFileName, const uint16_t nLineNum);
    void closeRuntimeError();
    void logFileFoundError(const char* cstrFileName);
    void logFileOpenError(const char* cstrFileName);
    void logFileReadError(const char* cstrFileName);
    
    #if !defined ARDUINO_ESP32_DEV && !defined ARDUINO_SAM_DUE
      void logEventClose(const char cCh, const __FlashStringHelper* fstrEventResult);
      void logEventOpen(const char cCh, const __FlashStringHelper* fstrEventDesc, const bool bNewLine = false);
      void logEvent(const char cCh, const __FlashStringHelper* fstrEventDesc)
      {
        logEventOpen(cCh, fstrEventDesc);
        logEventClose(cCh, F(""));
      };
      void logFileFoundError(__FlashStringHelper* strFileName);
      void logFileOpenError(__FlashStringHelper* strFileName);
      void logFileReadError(__FlashStringHelper* strFileName);
      void logRuntimeError(const __FlashStringHelper* fstrFileName, const int16_t nLineNum);
      void openRuntimeError(const __FlashStringHelper* fstrFileName, const int16_t nLineNum);
      void logFileFoundError(const __FlashStringHelper* fstrFileName);
      void logFileOpenError(const __FlashStringHelper* fstrFileName);
      void logFileReadError(const __FlashStringHelper* fstrFileName);
    #endif

  protected:
    Stream *m_pSerial, *m_pBroadcastSerial;
    #ifdef LOGFILE
      CTextFile m_fileLog;
    #endif
    const uint8_t m_nNumChars = 60;
};

extern CDebug debug;
