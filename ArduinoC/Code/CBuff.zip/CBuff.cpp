#include "CBuff.h"




CBuffBase::CBuffBase()
{
  m_strBuffer = NULL;
  m_nCapacity = 0;
}

CBuffBase::~CBuffBase()
{
  m_strBuffer = NULL;
  m_nCapacity = 0;
}

unsigned int CBuffBase::capacity()
{
  return m_nCapacity;
}

unsigned int CBuffBase::length()
{
  return strlen(m_strBuffer);
}

void CBuffBase::setAt(const uint16_t nI, const char cCh)
{
  if (nI < length())
    m_strBuffer[nI] = cCh;
}

char CBuffBase::getAt(const uint16_t nI)
{
  char cCh = 0;

  if (nI < length())
  {
    cCh = m_strBuffer[nI];
  }  
  return cCh;
}

CBuffBase::operator char*()
{
  return m_strBuffer;
}
    
bool CBuffBase::enqueue(const char cCh)
{
  bool bResult = false;

  if (m_strBuffer && ((length() + 1) < capacity()))
  {
    bResult = true;
    m_strBuffer[length()] = cCh;
  }
  return bResult;
}

char CBuffBase::dequeue()
{
  return pop();
}

bool CBuffBase::push(const char cCh)
{
  bool bResult = false;

  if (m_strBuffer && ((length() + 1) < capacity()))
  {
    m_strBuffer[strlen(m_strBuffer) + 1] = 0;
    for (int16_t nI = strlen(m_strBuffer) - 1; nI >= 0 ; nI--)
      m_strBuffer[nI + 1] = m_strBuffer[nI];
    m_strBuffer[0] = cCh;
    bResult = true;
  }
  return bResult;
}

char CBuffBase::pop()
{
  char cCh = 0;

  if (m_strBuffer && (length() > 0))
  {
    cCh = m_strBuffer[0];
    if (strlen(m_strBuffer) == 1)
    {
      m_strBuffer[0] = 0;
    }
    else
    {
      for (uint16_t nI = 1; nI < strlen(m_strBuffer); nI++)
        m_strBuffer[nI - 1] = m_strBuffer[nI];
      m_strBuffer[strlen(m_strBuffer) - 1] = 0;
    }
  }
  return cCh;
}




CFixedBuff::CFixedBuff()
{
}

CFixedBuff::CFixedBuff(const char *strBuff, const uint16_t nBuffSize, const bool bClear)
{
  m_strBuffer = strBuff;
  m_nCapacity = nBuffSize;
  if (bClear)
    empty();
}

CFixedBuff::~CFixedBuff()
{
  m_strBuffer = NULL;
}
    
void CFixedBuff::empty()
{
  memset(m_strBuffer, 0, capacity());
}





CDynamicBuff::CDynamicBuff()
{
}

CDynamicBuff::CDynamicBuff(const uint16_t nBuffSize)
{
  m_nCapacity = nBuffSize + 1;
  m_strBuffer = new char[m_nCapacity];
  memset(m_strBuffer, 0, m_nCapacity);
};

CDynamicBuff::~CDynamicBuff()
{
  if (m_strBuffer)
    delete m_strBuffer;
}

void CDynamicBuff::empty()
{
  memset(m_strBuffer, 0, capacity());
}
