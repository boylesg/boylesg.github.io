#ifndef __CBUFF_H
#define __CBUFF_H

#include <Arduino.h>




class CBuffBase
{
  public:
    char *m_strBuffer;
    uint16_t m_nCapacity;
    
    CBuffBase();
    virtual ~CBuffBase();
    virtual void empty() = 0;
    unsigned int capacity();
    unsigned int length();
    void setAt(const uint16_t nI, const char cCh);
    char getAt(const uint16_t nI);
    operator char*();
    bool enqueue(const char cCh);
    char dequeue();
    bool push(const char cCh);
    char pop();
};

class CFixedBuff: public CBuffBase
{
  public:
    CFixedBuff();
    CFixedBuff(const char *strBuff, const uint16_t nBuffSize, const bool bClear = false);
    virtual ~CFixedBuff();
    
    virtual void empty();
};

class CDynamicBuff: public CBuffBase
{
  public:
    CDynamicBuff();
    CDynamicBuff(const uint16_t nBuffSize);
    virtual ~CDynamicBuff();
    virtual void empty();
};

template<int nBuffSize>
class CBuff: public CBuffBase
{
  public:
    char m_strArray[nBuffSize + 1];
    CBuff(): CBuffBase()
    {
      m_nCapacity = nBuffSize + 1;
      memset(m_strArray, 0, capacity());
      m_strBuffer = m_strArray;
    };
    inline virtual void empty()
    {
      memset(m_strArray, 0, capacity());
    };
};

#endif
