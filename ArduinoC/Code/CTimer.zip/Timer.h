#line 2 "Timer.h"
#ifndef __TIMER_H_
#define __TIMER_H_

#include "Common.h"




const uint32_t WEEKLY = 604800;
const uint16_t DAILY = 1440;
const uint16_t TEN_MINUTES = 600;
const uint16_t FIVE_MINUTES = 300;
const uint8_t TWO_MINUTES = 120;
const uint8_t MINUTE = 60;




class CTimer
{
  public:
    // Construction, destruction & initialisation
    CTimer()
    {
      set(0, 0, NULL);
    }
    CTimer(const uint8_t nOwnerID, const uint32_t nIntervalSec, const GlobalFunctionPtrType pCallbackFunc)
    {
      set(nOwnerID, nIntervalSec, pCallbackFunc);
    }
    ~CTimer()
    {
    };

    // Interface
    void poll();
    void set(const uint8_t nOwnerID, const uint32_t nIntervalSec, const GlobalFunctionPtrType pCallbackFunc);
    void clear();
    uint8_t getOwnerID()
    {
      return m_nOwnerID;
    };
    bool isRunning()
    {
      return m_nIntervalSec > 0;
    };
    void dump();
    CTimer& operator =(CTimer& timerOther);

  protected:

    // Impelementation
    uint32_t m_nTrigger, m_nIntervalSec;
    uint8_t m_nOwnerID;
    GlobalFunctionPtrType m_pCallbackFunc;
};


#if defined ARDUINO_MEGA
  #define MAX_TIMERS 5
#elif defined ARDUINO_SAMX_DUE || defined ARDUINO_ESP32
  #define MAX_TIMERS 20
#else
  #define MAX_TIMERS 3
#endif

class CTimerList
{
  public:
    // Construction, destruction & initialisation
    CTimerList()
    {
      m_nSize = 0;
    }
    ~CTimerList()
    {
      m_nSize = 0;
    }

    // Interface
    void poll();
    void clear(const uint8_t nI);
    void remove(const uint8_t nID);
    CTimer* add(const uint8_t nOwnerID, const uint32_t nIntervalSec, const GlobalFunctionPtrType pCallbackFunc);
    uint8_t getSize()
    {
      return m_nSize;
    };
    int8_t getLast()
    {
      return (int8_t)m_nSize - 1;
    };

    void dump();

  protected:

    // Impelementation
    CTimer m_arrayTimers[MAX_TIMERS];
    uint8_t m_nSize;
};

extern CTimerList timers;

#endif
