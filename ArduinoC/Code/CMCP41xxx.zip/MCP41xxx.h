#pragma once
#include <Arduino.h>




#define MAX_DAC_VALUE uint8_t(0b11111111)
typedef enum{CHANNEL_NONE, CHANNEL_A, CHANNEL_B, CHANNEL_AB} eChannelType;
typedef enum{COMM_SHUTDOWN, COMM_SET} eCommandType;
typedef enum{RES_5k = 5000, RES_10k = 10000, RES_50k = 50000, RES_100k = 100000} eResistanceType;




class CMCP41xxx
{
  protected:
      // Data
      uint8_t m_nShutDownPin, m_nResetPin, m_nSPIChipSelectPin, m_nDACValue, m_nResistanceWiper; 
      uint32_t m_nTotalResistance;

      // Helpers
      void doSendCommand(const eCommandType eCommand, const eChannelType eChannel, const uint8_t nValue);
      
  public:

      // Construction, destruction & initialisation
      CMCP41xxx(const eResistanceType eTotalResistance, const uint8_t nSPIChipSelectPin, const uint8_t nResetPin = 255, const uint8_t nShutDownPin = 255);
      void begin();
      
      void doSetResistance(const eChannelType eChannel, const uint8_t nValue);
      void doShutdown(const bool bShutDown);
      void doReset();
      void doShutdownCommand(const eChannelType eChannel);
      void doZero();
      float doGetR1();
      float doGetR2();
};
