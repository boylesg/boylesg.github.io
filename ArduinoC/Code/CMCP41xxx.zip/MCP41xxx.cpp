#include <SPI.h>
#include "MCP41xxx.h"
#include "debug.h"




CMCP41xxx::CMCP41xxx(const eResistanceType eTotalResistance, const uint8_t nSPIChipSelectPin, const uint8_t nResetPin, const uint8_t nShutDownPin)
{
  m_nTotalResistance = (uint32_t)eTotalResistance;

  switch (eTotalResistance)
  {
    case RES_5k: m_nResistanceWiper = 52; break;
    case RES_10k: m_nResistanceWiper = 52; break;
    case RES_50k: m_nResistanceWiper = 125; break;
    case RES_100k: m_nResistanceWiper = 125; break;
  }
  m_nSPIChipSelectPin = nSPIChipSelectPin;
  m_nShutDownPin = nShutDownPin;
  m_nResetPin = nResetPin;
  m_nDACValue = 0;
}

void CMCP41xxx::begin()
{
  // Prepare SPI hardware.
  SPI.begin();
  
  // Prepare SPI SS line
  pinMode(m_nSPIChipSelectPin, OUTPUT);
  digitalWrite(m_nSPIChipSelectPin, 1);
  
  pinMode(m_nShutDownPin, OUTPUT);
  digitalWrite(m_nShutDownPin, HIGH);

  pinMode(m_nResetPin, OUTPUT);
  digitalWrite(m_nShutDownPin, HIGH);

  doZero();
}

void CMCP41xxx::doZero()
{
  doSetResistance(CHANNEL_A, 0);
  doSetResistance(CHANNEL_B, 0);
}

void CMCP41xxx::doShutdown(const bool bShutDown)
{
  digitalWrite(m_nShutDownPin, !bShutDown);
}

void CMCP41xxx::doReset()
{
  digitalWrite(m_nResetPin, LOW);
  delayMicroseconds(1);
  digitalWrite(m_nResetPin, HIGH);
}

void CMCP41xxx::doSendCommand(const eCommandType eCommand, const eChannelType eChannel, const uint8_t nValue)
{
  uint8_t nCommandByte = 0;

  // COMMAND BYTE
  // +-----+-----+-----+-----+-----+-----+-----+-----+
  // |  X  |  X  | C1  | C0  |  X  |  X  | P1* | P0  |
  // +-----+-----+-----+-----+-----+-----+-----+-----+
  //
  // COMMAND BITS
  // +----+----+------------+-------------------------------------------------------------------------------------------------------------------+
  // | C1 | C0 | Command    | Command description                                                                                               |
  // +----+----+------------+-------------------------------------------------------------------------------------------------------------------+
  // | 0  | 0  | None       | No Command will be executed.                                                                                      |
  // +----+----+------------+-------------------------------------------------------------------------------------------------------------------+
  // | 0  | 1  | Write Data | Write the data contained in the data byte to the potentiometer(s) determined by the potentiometer selection bits. |
  // +----+----+------------+-------------------------------------------------------------------------------------------------------------------+
  // | 1  | 0  | Shutdown   | Potentiometer(s) determined by potentiometer selection bits will enter shutdown mode. Data bits are ignored.      |                                                                                     |
  // +----+----+------------+-------------------------------------------------------------------------------------------------------------------+
  // | 1  | 1  | None       | No Command will be executed.                                                                                      |
  // +----+----+------------+-------------------------------------------------------------------------------------------------------------------+
  // 
  // POTENTIOMETER SELECTION BITS
  // +----+----+------------------------------------------+
  // | P1 | P0 | Potentiometer selections                 |
  // +----+----+------------------------------------------+
  // | 0  | 0  | Neither Potentiometer affected.          |
  // +----+----+------------------------------------------+
  // | 0  | 1  | Command executed on potentiometer 0.     |
  // +----+----+------------------------------------------+
  // | 1  | 0  | Command executed on potentiometer 1.     |
  // +----+----+------------------------------------------+
  // | 1  | 1  | Command executed on both potentiometers. |
  // +----+----+------------------------------------------+

  switch (eCommand)
  {
    case COMM_SHUTDOWN: nCommandByte = 0b00100000; break;
    case COMM_SET:nCommandByte = 0b00010000; break;
  }
  switch (eChannel)
  {
    case CHANNEL_NONE: nCommandByte |= 0b00000000; break;
    case CHANNEL_A: nCommandByte |= 0b00000001; break;
    case CHANNEL_B: nCommandByte |= 0b00000010; break;
    case CHANNEL_AB: nCommandByte |= 0b00000011; break;
  }
  SPI.beginTransaction(SPISettings());

  // Assert SPI bus
  digitalWrite(m_nSPIChipSelectPin, 0);

  SPI.transfer(nCommandByte);
  SPI.transfer(nValue);

  // Deassert SPI bus
  digitalWrite(m_nSPIChipSelectPin, 1);

  SPI.endTransaction();
}

void CMCP41xxx::doShutdownCommand(const eChannelType eChannel)
{
  doSendCommand(COMM_SHUTDOWN, eChannel, 0);
}

float CMCP41xxx::doGetR1()
{
  float fResistance = float(m_nTotalResistance) * (256 - m_nDACValue);

  fResistance = (fResistance / 256) + m_nResistanceWiper;

  return fResistance;
}

float CMCP41xxx::doGetR2()
{
  float fResistance = float(m_nTotalResistance) * m_nDACValue;

  fResistance = (fResistance / 256) + m_nResistanceWiper;

  return fResistance;
}

void CMCP41xxx::doSetResistance(const eChannelType eChannel, const uint8_t nValue)
{
  m_nDACValue = nValue;
  doSendCommand(COMM_SET, eChannel, nValue);
}
