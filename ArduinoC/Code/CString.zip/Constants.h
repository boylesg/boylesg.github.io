#line 2 "Constants.h"
#pragma once

#include <Arduino.h>

#define DEBUG_SERIAL_MONITOR 	1
#define DEBUG_WIFI_MANAGER 		1
#define WIFI      				10
#define LCD       				20


