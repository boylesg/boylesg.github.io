#line 2 "CString.h"
#ifndef __CSTRING_H__
#define __CSTRING_H__

#include <IPAddress.h>
#include "Common.h"
#include "CBuff.h"




class CString
{
  protected:

    //****************************************************************
    //* Data
    //****************************************************************
    CBuffBase *m_pBuff;
  
    //****************************************************************
    //* Assorted helper functions
    //****************************************************************
	  void convertHex2Bin(char *strHex, const byte nCapacity);
	  void copy(const char *strStart, const char* strEnd, char* strDest, const unsigned int nSize);
	  void concat(const char *strStart, const char* strEnd, char* strDest, const unsigned int nSize);

  public:

    //****************************************************************
    //* Construction and destuction
    //****************************************************************
    // So you can declare a global CString variable, but make sure you call init(...) before using it.
	CString();
  
    CString(CBuffBase &buff, const bool bClear = false)
    {
      init(buff, bClear);
    };
    void init(CBuffBase &buff, const bool bClear = false);

    CString(CString& strOther);
    ~CString()
    {
    }
  
    //****************************************************************
    //* Miscellaneous
    //****************************************************************

    // Returns the length of the current string, not counting the 0 terminator
    const unsigned int length() 
    { 
		  return strlen(m_pBuff->m_strBuffer);
    }

    // Returns the capacity of the buffer
    const unsigned int capacity() 
    { 
		  return m_pBuff->capacity(); 
    }

    const unsigned int maxLength() 
    { 
      return m_pBuff->capacity() - 1; 
    }

    // Returns true if the buffer contain the maximu length string.
    const bool full() 
    { 
      return m_pBuff->length() == m_pBuff->capacity() - 1; 
    }

    const char* substring(int nStartPos, int nEndPos = -1);

    //****************************************************************
    //* Other operator functions
    //****************************************************************
    const char* c_str() 
    { 
      return m_pBuff->m_strBuffer; 
    }
  
    operator const char*() 
    { 
      return m_pBuff->m_strBuffer; 
    }
  
    operator char*() 
    { 
      return m_pBuff->m_strBuffer; 
    }
  
    operator byte*()
    {
      return (byte*)m_pBuff->m_strBuffer;
    }
    
    operator const byte*()
    {
      return (const byte*)m_pBuff->m_strBuffer;
    }

    operator void*()
    {
      return (void*)m_pBuff->m_strBuffer;
    }

    char& operator[](const unsigned int nI)
    {
      return m_pBuff->m_strBuffer[nI];
    };
    char& operator[](const int nI)
    {
      return m_pBuff->m_strBuffer[nI];
    };
      
    // Empty the string.
    void empty()
    {
      memset(m_pBuff->m_strBuffer, 0, m_pBuff->capacity());
    }
  
    // Is it an empty string ""
    bool isEmpty()
    {
      return m_pBuff->length() == 0;
    }
   
    //****************************************************************
    //* Concatenation operator functions
    //****************************************************************
    void operator +=(CString& str);    
    void operator +=(const char* str);    
    void operator +=(const char cCh);
#if !defined ARDUINO_ESP32_DEV
    void operator +=(const __FlashStringHelper* fstr);
#endif
    
    //****************************************************************
    //* Assignment operator functions
    //****************************************************************
    CString& operator =(const char cCh);
    CString& operator =(const char* str);
#if !defined ARDUINO_ESP32_DEV
    CString& operator =(const __FlashStringHelper* fstr);
#endif
    CString& operator =(CString& str);
  
  
    //****************************************************************
    //* Comparaison operator functions
    //****************************************************************
    bool operator ==(const char *str);
#if !defined ARDUINO_ESP32_DEV
    bool operator ==(const __FlashStringHelper *str);
#endif
    bool operator >=(const char *str);
#if !defined ARDUINO_ESP32_DEV
    bool operator >=(const __FlashStringHelper *str);
    bool operator >(const __FlashStringHelper *str);
    bool operator <=(const __FlashStringHelper *str);
    bool operator <(const __FlashStringHelper *str);
    bool operator !=(const __FlashStringHelper *str);
#endif
    bool operator >(const char *str);
    bool operator <=(const char *str);
    bool operator <(const char *str);
    bool operator !=(const char *str);

    //****************************************************************
    //* Search functions
    //****************************************************************
    bool find(const char cCh, const int nPos = 0)
    {
      return indexOf(cCh, nPos) >= 0;
    };
    bool find(const char* str, const int nPos = 0)
    {
      return indexOf(str, nPos) >= 0;
    };
    int findOneOf(const char* strCharList, const unsigned int nPos = 0);
    int reverseFindOneOf(const char* strCharList, const unsigned int nPos = 0);
#if !defined ARDUINO_ESP32_DEV
    int reverseFindOneOf(const __FlashStringHelper* fstrCharList, const unsigned int nPos = 0);
    int findOneOf(const __FlashStringHelper* fstrCharList, const unsigned int nPos = 0);
    bool find(const __FlashStringHelper* fstr, const int nPos = 0)
    {
      return indexOf(fstr, nPos) >= 0;
    };
#endif
    int indexOf(const char cCh, const int nPos = 0);
    int indexOf(const char* str, const int nPos = 0);
#if !defined ARDUINO_ESP32_DEV
    int indexOf(const __FlashStringHelper* fstr, const int nPos = 0);
#endif

    bool reverseFind(const char cCh, const int nPos = -1)
    {
      return reverseIndexOf(cCh, nPos) >= 0;
    };
    bool reverseFind(const char* str, const int nPos = -1)
    {
      return reverseIndexOf(str, nPos) >= 0;
    };
#if !defined ARDUINO_ESP32_DEV
    bool reverseFind(const __FlashStringHelper* fstr, const int nPos = -1)
    {
      return reverseIndexOf(fstr, nPos) >= 0;
    };
#endif

    int reverseIndexOf(const char cCh, const int nPos = -1);
    int reverseIndexOf(const char* str, const int nPos = -1);
#if !defined ARDUINO_ESP32_DEV
    int reverseIndexOf(const __FlashStringHelper* fstr, const int nPos = -1);
    bool endsWith(const __FlashStringHelper *fstrFind);
    bool beginsWith(const __FlashStringHelper *fstrFind);
#endif

    bool endsWith(const char *cstrFind);
    bool beginsWith(const char *cstrFind);
	  //****************************************************************
    //* Formatting and conversion functions
    //****************************************************************
    void format(const char *str, ...);
#if !defined ARDUINO_ESP32_DEV
      void format(const __FlashStringHelper *fstr, ...);
#endif
  
    void fromIPAddr(IPAddress ip);
    void fromBool(const bool bVal);
    void fromUint(const int nNum, const byte nBase = 10);
    void fromInt(const int32_t nNum, const byte nBase = 10);
    void fromReal(const double dNum, const byte nDecimalPlaces);
  	int toUint(const byte nBase = 10);
  	int32_t toInt(const byte nBase = 10);
  	double toReal();

	//****************************************************************
	//* Modification functions
	//****************************************************************
    void encodeBase64();
    void decodeBase64();
    void insert(const char cCh, const unsigned int nBeforePos);
    void insert(const char* str, const unsigned int nBeforePos);
#if !defined ARDUINO_ESP32_DEV
    void insert(const __FlashStringHelper* fstr, const unsigned int nBeforePos);
#endif
    void replace(const char cFind, const char cReplace, const unsigned int nStartFrom = 0);
    void replace(const char* strFind, const char* strReplace, const unsigned int nStartFrom = 0);
#if !defined ARDUINO_ESP32_DEV
    void replace(const char* strFind, const __FlashStringHelper* fstrReplace, const unsigned int nStartFrom = 0);
    void replace(const __FlashStringHelper* fstrFind, const char* strReplace, const unsigned int nStartFrom = 0);
    void replace(const __FlashStringHelper* fstrFind, const __FlashStringHelper* fstrReplace, const unsigned int nStartFrom = 0);
#endif
    void removeCh(const char cFind, const int nStartFrom = 0);
    void remove(const int nPos, unsigned int nCount);
    void remove(const char* strFind, const unsigned int nStartFrom = 0);
    
#if !defined ARDUINO_ESP32_DEV
    void remove(const __FlashStringHelper* fstrFind, const unsigned int nStartFrom = 0);
#endif
    void toLower();
    void toUpper();
    void trim();
    void trimLeft();
    void trimRight();
    void padLeft(const char cCh, const byte nLength);
    void padRight(const char cCh, const byte nLength);
};

#endif
