#include "Encode.h"
#include "CBuff.h"
#include "CString.h"


const char arrayCharacters[] PROGMEM = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
                                        'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
                                        '0','1','2','3','4','5','6','7','8','9','!','\"','#','$','%','&','\'','(',')','*','+',',','-','.','/',':',
                                        ';','<','=','>','?','@','[','\\',']','^','_','`','{','|','}'};
                                                      
const uint8_t arrayHex[] PROGMEM = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,
                                    0x1A,0x1B,0x1C,0x1D,0x1E,0x1F,0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,0x2A,0x2B,0x2C,0x2D,0x2E,0x2F,0x30,0x31,0x32,0x33,
                                    0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F,0x40,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4A,0x4B,0x4C,0x4D,
                                    0x4E,0x4F,0x50,0x51,0x52,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5A,0x5B,0x5C};

CMapPROGMEM<char, uint8_t, MAX_SIZE> g_mapEncode(arrayCharacters, arrayHex);
CMapPROGMEM<uint8_t, char, MAX_SIZE> g_mapDecode(arrayHex, arrayCharacters);

void encodeBase64(CString &strDataIn)
{
  CDynamicBuff buffEncoded(strDataIn.length() * 3);
  CBuff<6> buffHex;
  CString strEncoded(buffEncoded), strHex(buffHex);
  uint8_t nHex = 0;

  for (uint8_t nI = 0; nI < strDataIn.length(); nI++)
  {
    if (g_mapEncode.getAt(strDataIn[nI], nHex))
    {
      strHex.format("%02X", nHex);
      strEncoded += strHex;
    }
    else
    {
      strEncoded += strDataIn[nI];
    }
  }
  strDataIn = strEncoded;
}

void decodeBase64(CString &strDataIn)
{
  CDynamicBuff buffDecoded(strDataIn.length() + 1);
  CBuff<4> buffHex;
  CString strHex(buffHex), strDecoded(buffDecoded);
  uint8_t nHex= 0;
  char cCh = 0;
  
  while (strDataIn.length() > 0)
  {
    if (isAlphaNumeric(strDataIn[0]))
    {
      strHex = strDataIn.substring(0, 1);
      strDataIn.remove(0, 2);     
      nHex = toUint(strHex, 16);

      if (g_mapDecode.getAt(nHex, cCh))
      {
        strDecoded += cCh;
      }
      else
      {
        strDecoded += strDataIn[0];
        strDataIn.remove(0, 1);
      }
    }
    else
    {
      strDecoded += strDataIn[0];
      strDataIn.remove(0, 1);
    }
  }
  if (strDecoded == F("blank"))
    strDecoded.empty();

  strDataIn.empty();
  strDataIn = strDecoded;
}
