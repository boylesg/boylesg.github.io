#pragma once

#include "map.h"




#define MAX_SIZE 93
extern CMapPROGMEM<char, uint8_t, MAX_SIZE> g_mapEncode;
extern CMapPROGMEM<uint8_t, char, MAX_SIZE> g_mapDecode;

void encodeBase64(CString &strDataIn);
void decodeBase64(CString &strDataIn);
