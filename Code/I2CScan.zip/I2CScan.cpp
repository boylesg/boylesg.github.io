#include <Arduino.h>
#include <inttypes.h>
#include "I2CScan.h"




CI2CScan::CI2CScan()
{
  m_nTimeoutDelay = 0;
}

CI2CScan::~CI2CScan()
{
  end();
}


/////// Public Methods ////////////////////

void CI2CScan::begin()
{
  #if defined(__AVR_ATmega168__) || defined(__AVR_ATmega8__) || defined(__AVR_ATmega328P__)
    // nActivate internal pull-ups for twi
    // as per note from atmega8 manual pg167
    sbi(PORTC, 4);
    sbi(PORTC, 5);
  #else
    // nActivate internal pull-ups for twi
    // as per note from atmega128 manual pg204
    sbi(PORTD, 0);
    sbi(PORTD, 1);
  #endif
  // Initialize twi prescaler and bit rate
  cbi(TWSR, TWPS0);
  cbi(TWSR, TWPS1);
  TWBR = ((F_CPU / 100000) - 16) / 2;
  // Enable twi module and acks
  TWCR = _BV(TWEN) | _BV(TWEA); 
}

void CI2CScan::end()
{
  TWCR = 0;
}

void CI2CScan::setTimeOut(uint16_t nTimeOut)
{
  m_nTimeoutDelay = nTimeOut;
}

bool CI2CScan::find(const uint8_t nAddress)
{
  uint8_t nReturnStatus = 0;

  nReturnStatus = start();
  if (nReturnStatus == 0)
  {
    nReturnStatus = sendAddress(SLA_W(nAddress));
    if (nReturnStatus > 0)
      {
        Serial.print(F("I2C Device found at address "));
        Serial.print(nAddress, HEX);
        Serial.println(F("!"));
      }
  }
  return nReturnStatus > 0;
}

bool CI2CScan::scan(uint8_t *arrayAddresses, const uint8_t nArraySize)
{
  uint16_t nTempTime = m_nTimeoutDelay;
  uint8_t nAddress = 0, nI = 0, nReturnStatus = 0;

  setTimeOut(80);

  for (nAddress = 1; nAddress < 0x7F; nAddress++)
  {
    nReturnStatus = start();
   
    if (!nReturnStatus)
    { 
      nReturnStatus = sendAddress(SLA_W(nAddress));
    }
    if (nReturnStatus)
    {
      if (nReturnStatus == 1)
      {
        Serial.println(F("There is a problem with the bus, could not complete scan!"));
        m_nTimeoutDelay = nTempTime;
      }
    }
    else
    {
      if (nI < nArraySize)
      {
        arrayAddresses[nI] = nAddress;
        Serial.print(F("I2C Device found at "));
        Serial.print(nAddress, HEX);
        
        Serial.print(F("..."));

        if (nAddress == 0x0C)
          Serial.println(F("AK8975"));	
        else if (nAddress == 0x0D)
          Serial.println(F("AK8975"));
        else if (nAddress == 0x0E)
          Serial.println(F("AG3110 AK8975 IST-8310"));
        else if (nAddress == 0x0F)
          Serial.println(F("AK8975"));
        else if (nAddress == 0x10)
          Serial.println(F("VEML6075 VML6075 VEML7700 LM25066"));
        else if (nAddress == 0x11)
          Serial.println(F("SAA5243P/K SAA5243P/E SAA5243P/H SAA5243P/L SAA5246 LM25066 Si4713"));
        else if (nAddress == 0x12)
          Serial.println(F("SEN-17374 PMSA003I LM25066"));
        else if (nAddress == 0x13)
          Serial.println(F("VCNL4else if (nAddress == 0x0 SEN-17374 LM25066"));
        else if (nAddress == 0x14)
          Serial.println(F("LM25066"));
        else if (nAddress == 0x15)
          Serial.println(F("LM25066"));
        else if (nAddress == 0x16)
          Serial.println(F("LM25066"));
        else if (nAddress == 0x17)
          Serial.println(F("LM25066"));
        else if (nAddress == 0x18)
          Serial.println(F("47L04/47C04/47L16/47C16 LSM303 COM-15093 LIS3DH MCP9808"));
        else if (nAddress == 0x19)
          Serial.println(F("COM-15093 LIS3DH LSM303 MCP9808"));
        else if (nAddress == 0x1A)
          Serial.println(F("MCP9808 47L04/47C04/47L16/47C16"));
        else if (nAddress == 0x1B)
          Serial.println(F("MCP9808"));
        else if (nAddress == 0x1C)
          Serial.println(F("MCP9808 MMA845x FXOS8700 47L04/47C04/47L16/47C16"));
        else if (nAddress == 0x1D)
          Serial.println(F("MMA845x FXOS8700 MCP9808 ADXL345"));
        else if (nAddress == 0x1E)
          Serial.println(F("47L04/47C04/47L16/47C16 LSM303 HMC5883 LSM303 FXOS8700 MCP9808"));
        else if (nAddress == 0x1F)
          Serial.println(F("MCP9808 FXOS8700"));
        else if (nAddress == 0x20)
          Serial.println(F("Chirp! MCP23008 HW-061 TCA9554 FXAS21002 MCP23017 MA12070P"));
        else if (nAddress == 0x21)
          Serial.println(F("SAA4700 MCP23008 HW-061 TCA9554 FXAS21002 MCP23017 MA12070P"));
        else if (nAddress == 0x22)
          Serial.println(F("PCA1070 MCP23008 HW-061 TCA9554 MCP23017 MA12070P"));
        else if (nAddress == 0x23)
          Serial.println(F("BH1750FVI SAA4700 MCP23008 HW-061 TCA9554 MCP23017 MA12070P"));
        else if (nAddress == 0x24)
          Serial.println(F("PCD3312C PCD3311C MCP23008 HW-061 TCA9554 MCP23017"));
        else if (nAddress == 0x25)
          Serial.println(F("PCD3312C PCD3311C MCP23008 HW-061 TCA9554 MCP23017"));
        else if (nAddress == 0x26)
          Serial.println(F("MCP23008 MCP23017 TCA9554 HW-061"));
        else if (nAddress == 0x27)
          Serial.println(F("HIH6130 MCP23008 HW-061 TCA9554 MCP23017 LCD"));
        else if (nAddress == 0x28)
          Serial.println(F("BNO055 CAP1188 DS1841 DS3502 DS1881 FS3000"));
        else if (nAddress == 0x29)
          Serial.println(F("TCS34725 DS3502 DS1841 DS1881 VL618else if (nAddress == 0x BNO055 VL53Lelse if (nAddress == 0x CAP1188 TSL2591"));
        else if (nAddress == 0x2A)
          Serial.println(F("CAP1188 DS1841 DS3502 DS1881"));
        else if (nAddress == 0x2B)
          Serial.println(F("CAP1188 DS1841 DS3502 DS1881"));
        else if (nAddress == 0x2C)
          Serial.println(F("DS1881 CAT5171 AD5248 AD5252 AD5251 CAP1188"));
        else if (nAddress == 0x2D)
          Serial.println(F("DS1881 CAT5171 AD5248 AD5252 AD5251 CAP1188"));
        else if (nAddress == 0x2E) 
          Serial.println(F("DS1881 AD5248 AD5252 AD5251 LPS22HB"));
        else if (nAddress == 0x2F)
          Serial.println(F("DS1881 AD5248 AD5252 AD5243 AD5251"));
        else if (nAddress == 0x30)
          Serial.println(F("SAA2502"));
        else if (nAddress == 0x31)
          Serial.println(F("SAA2502"));
        else if (nAddress == 0x33)
          Serial.println(F("MLX90640"));
        else if (nAddress == 0x36)
          Serial.println(F("MAX17048"));
        else if (nAddress == 0x38)
          Serial.println(F("SEN-15892 PCF8574AP BMA150 VEML6070 AHT10 SAA1064 FT6x06 "));
        else if (nAddress == 0x39)
          Serial.println(F("TSL2561 PCF8574AP VEML6070 SAA1064 APDS-9960"));
        else if (nAddress == 0x3A)
          Serial.println(F("PCF8577C PCF8574AP SAA1064"));
        else if (nAddress == 0x3B)
          Serial.println(F("SAA1064 PCF8569 PCF8574AP"));
        else if (nAddress == 0x3C)
          Serial.println(F("SSD1306 SH1106 PCF8569 PCF8578 PCF8574AP SSD1305"));
        else if (nAddress == 0x3D)
          Serial.println(F("SSD1306 SH1106 PCF8578 PCF8574AP SSD1305"));
        else if (nAddress == 0x3E)
          Serial.println(F("PCF8574AP"));
        else if (nAddress == 0x3F)
          Serial.println(F("PCF8574AP LCD"));
        else if (nAddress == 0x40)
          Serial.println(F("Si7021 HTU21D-F TMP007 TMP006 PCA9685 INA219 TEA6330 TEA6300 TDA9860 TEA6320 TDA8421 NE5751 INA260 PCF8574 HDC1080 LM25066"));
        else if (nAddress == 0x41)
          Serial.println(F("TMP007 TMP006 PCA9685 INA219 STMPE610 STMPE811 TDA8426 TDA9860 TDA8424 TDA8421 TDA8425 NE5751 INA260 PCF8574 LM25066"));
        else if (nAddress == 0x42)
          Serial.println(F("INA219 INA260 TMP007 HDC1008 TDA8417 PCF8574 TDA8415 LM25066 PCA9685 TMP006"));
        else if (nAddress == 0x43)
          Serial.println(F("INA219 INA260 TMP007 HDC1008 PCF8574 LM25066 PCA9685 TMP006"));
        else if (nAddress == 0x44)
          Serial.println(F("TMP007 TMP006 PCA9685 INA219 STMPE610 SHT31 ISL29125 STMPE811 TDA4688 TDA4672 TDA4780 TDA4670 TDA8442 TDA4687 TDA4671 TDA4680 INA260 PCF8574 LM25066"));
        else if (nAddress == 0x45)
          Serial.println(F("TDA8376 INA219 TDA7433 INA260 TMP007 PCF8574 LM25066 PCA9685 SHT31 TMP006"));
        else if (nAddress == 0x46)
          Serial.println(F("INA219 INA260 TMP007 PCF8574 TDA8370 LM25066 PCA9685 TDA9150 TMP006"));
        else if (nAddress == 0x47)
          Serial.println(F("INA219 INA260 TMP007 PCF8574 LM25066 PCA9685 TMP006"));
        else if (nAddress == 0x48)
          Serial.println(F("INA219 INA260 ADS7828 LM75b PCF8574 ADS1115 TMP102 PCA9685 PN532"));
        else if (nAddress == 0x49)
          Serial.println(F("TSL2561 INA219 INA260 AS7262 ADS7828 LM75b PCF8574 ADS1115 TMP102 PCA9685"));
        else if (nAddress == 0x4A)
          Serial.println(F("NA219 INA260 ADS7828 LM75b PCF8574 ADS1115 TMP102 PCA9685 MAX44009"));
        else if (nAddress == 0x4B)
          Serial.println(F("PCA9685 INA219 TMP102 ADS1115 MAX44009 INA260 PCF8574 ADS7828 LM75b"));
        else if (nAddress == 0x4C)
          Serial.println(F("PCA9685 INA219 INA260 PCF8574 LM75b"));
        else if (nAddress == 0x4D)
          Serial.println(F("PCA9685 INA219 INA260 PCF8574 LM75b"));
        else if (nAddress == 0x4E)
          Serial.println(F("PCA9685 INA219 INA260 PCF8574 LM75b"));
        else if (nAddress == 0x4F)
          Serial.println(F("PCA9685 INA219 INA260 PCF8574 LM75b"));
        else if (nAddress == 0x50)
          Serial.println(F("PCA9685 MB85RC CAT24C512 LM25066 47L04/47C04/47L16/47C16 FS1015"));
        else if (nAddress == 0x51
          )Serial.println(F("PCA9685 MB85RC CAT24C512 VCNL4200 LM25066"));
        else if (nAddress == 0x52)
          Serial.println(F("PCA9685 MB85RC Nunchuck controller APDS-9250 CAT24C512 SI1133 LM25066 47L04/47C04/47L16/47C16"));
        else if (nAddress == 0x53)
          Serial.println(F("ADXL345 PCA9685 MB85RC CAT24C512 LM25066"));
        else if (nAddress == 0x54)
          Serial.println(F("PCA9685 MB85RC CAT24C512 LM25066 47L04/47C04/47L16/47C16"));
        else if (nAddress == 0x55)
          Serial.println(F("PCA9685 MB85RC MAX30101 CAT24C512 SI1133 LM2506"));
        else if (nAddress == 0x56
          )Serial.println(F("PCA9685 MB85RC CAT24C512 LM25066 47L04/47C04/47L16/47C16"));
        else if (nAddress == 0x57)
          Serial.println(F("PCA9685 MB85RC MAX301else if (nAddress == 0x CAT24C512 LM25066"));
        else if (nAddress == 0x58)
          Serial.println(F("PCA9685 TPA2016 SGP30 LM25066"));
        else if (nAddress == 0x59)
          Serial.println(F("PCA9685 LM25066"));
        else if (nAddress == 0x5A)
          Serial.println(F("PCA9685 CCS811 MLX90614 DRV2605 MPR121 CCS811 LM25066"));
        else if (nAddress == 0x5B)
          Serial.println(F("PCA9685 CCS811 MPR121 CCS811"));
        else if (nAddress == 0x5C)
          Serial.println(F("PCA9685 AM2315 MPR121 BH1750FVI"));
        else if (nAddress == 0x5D)
          Serial.println(F("PCA9685 MPR121 SFA30"));
        else if (nAddress == 0x5E)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x5F)
          Serial.println(F("PCA9685 HTS221"));
        else if (nAddress == 0x60)
          Serial.println(F("PCA9685 MPL115A2 MPL3115A2 Si5351A Si1145 MCP4725A0 TEA5767 TSA5511 SAB3037 SAB3035 MCP4725A1 ATECC508A ATECC608A SI1132 MCP4728"));
        else if (nAddress == 0x61)
          Serial.println(F("PCA9685 Si5351A MCP4725A0 TEA6100 TSA5511 SAB3037 SAB3035 MCP4725A1 SCD30 MCP4728"));
        else if (nAddress == 0x62)
          Serial.println(F("PCA9685 MCP4725A1 TSA5511 SAB3037 SAB3035 UMA1014T SCD40-D-R2 SCD41 SCD40 MCP4728"));
        else if (nAddress == 0x63)
          Serial.println(F("Si4713 PCA9685 MCP4725A1 TSA5511 SAB3037 SAB3035 UMA1014T MCP4728"));
        else if (nAddress == 0x64)
          Serial.println(F("PCA9685 MCP4725A2 MCP4725A1 MCP4728"));
        else if (nAddress == 0x65)
          Serial.println(F("PCA9685 MCP4725A2 MCP4725A1 MCP4728"));
        else if (nAddress == 0x66)
          Serial.println(F("PCA9685 MCP4725A3 IS31FL3731 MCP4725A1 MCP4728"));
        else if (nAddress == 0x67)
          Serial.println(F("PCA9685 MCP4725A3 MCP4725A1 MCP4728"));
        else if (nAddress == 0x68)
          Serial.println(F("PCA9685 AMG8833 DS1307 PCF8523 DS3231 MPU-9250 ITG3200 PCF8573 MPU6050 ICM-20948 WITTY PI 3 MCP3422 DS1371"));
        else if (nAddress == 0x69)
          Serial.println(F("PCA9685 AMG8833 MPU-9250 ITG3200 PCF8573 SPS30 MPU6050 ICM-20948 WITTY PI 3 MAX31341"));
        else if (nAddress == 0x6A)
          Serial.println(F("PCA9685 L3GD20H PCF8573"));
        else if (nAddress == 0x6B)
          Serial.println(F("PCA9685 L3GD20H PCF8573"));
        else if (nAddress == 0x6C)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x6D)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x6E)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x6F)
          Serial.println(F("PCA9685 MCP7940N"));
        else if (nAddress == 0x70)
          Serial.println(F("PCA9685 TCA9548 HT16K33 SHTC3 PCA9541 TCA9548"));
        else if (nAddress == 0x71)
          Serial.println(F("PCA9685 TCA9548 HT16K33 PCA9541 TCA9548A"));
        else if (nAddress == 0x72)
          Serial.println(F("PCA9685 TCA9548 HT16K33 PCA9541 TCA9548A"));
        else if (nAddress == 0x73)
          Serial.println(F("PCA9685 TCA9548 HT16K33 PCA9541 TCA9548A"));
        else if (nAddress == 0x74)
          Serial.println(F("PCA9685 TCA9548 HT16K33 PCA9541 TCA9548A"));
        else if (nAddress == 0x75)
          Serial.println(F("PCA9685 TCA9548 HT16K33 PCA9541 TCA9548A"));
        else if (nAddress == 0x76) 
          Serial.println(F("PCA9685 TCA9548 HT16K33 BME280 BMP280 MS5607 MS5611 BME680 BME688 PCA9541 SPL06-007 TCA9548A"));
        else if (nAddress == 0x77)
          Serial.println(F("PCA9685 TCA9548 HT16K33 IS31FL3731 BME280 BMP280 MS5607 BMP180 BMP085 BMA180 MS5611 BME680 BME688 PCA9541 SPL06-007 TCA9548A"));
        else if (nAddress == 0x78)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x79)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x7A)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x7B)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x7C)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x7D)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x7E)
          Serial.println(F("PCA9685"));
        else if (nAddress == 0x7F)
          Serial.println(F("PCA9685"));
        else
          Serial.println(F("unknown device"));
        nI++;
      }
      if (nI >= nArraySize)
        break;
    }
    stop();
  }
  m_nTimeoutDelay = nTempTime;

  return nI > 0;
}

//////// Private Methods ////////////////////


uint8_t CI2CScan::start()
{
  unsigned long startingTime = millis();
  TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
  while (!(TWCR & (1 << TWINT)))
  {
    if (!m_nTimeoutDelay){continue;}
    if ((millis() - startingTime) >= m_nTimeoutDelay)
    {
      lockUp();
      return (1);
    }
       
  }
  if ((TWI_STATUS == START) || (TWI_STATUS == REPEATED_START))
  {
    return (0);
  }
  if (TWI_STATUS == LOST_ARBTRTN)
  {
    uint8_t bufferedStatus = TWI_STATUS;
    lockUp();
    return (bufferedStatus);
  }
  return (TWI_STATUS);
}

uint8_t CI2CScan::sendAddress(uint8_t i2cAddress)
{
  TWDR = i2cAddress;
  unsigned long startingTime = millis();
  TWCR = (1 << TWINT) | (1 << TWEN);
  while (!(TWCR & (1 << TWINT)))
  {
    if (!m_nTimeoutDelay){continue;}
    if ((millis() - startingTime) >= m_nTimeoutDelay)
    {
      lockUp();
      return (1);
    }
       
  }
  if ((TWI_STATUS == MT_SLA_ACK) || (TWI_STATUS == MR_SLA_ACK))
  {
    return (0);
  }
  uint8_t bufferedStatus = TWI_STATUS;
  if ((TWI_STATUS == MT_SLA_NACK) || (TWI_STATUS == MR_SLA_NACK))
  {
    stop();
    return (bufferedStatus);
  }
  else
  {
    lockUp();
    return (bufferedStatus);
  } 
}

uint8_t CI2CScan::stop()
{
  unsigned long startingTime = millis();
  TWCR = (1 << TWINT) | (1 << TWEN)| (1 << TWSTO);
  while ((TWCR & (1 << TWSTO)))
  {
    if (!m_nTimeoutDelay){continue;}
    if ((millis() - startingTime) >= m_nTimeoutDelay)
    {
      lockUp();
      return (1);
    }
       
  }
  return (0);
}

void CI2CScan::lockUp()
{
  TWCR = 0; // Releases SDA and SCL lines to high impedance
  TWCR = _BV(TWEN) | _BV(TWEA); // Re-initialize TWI 
}
