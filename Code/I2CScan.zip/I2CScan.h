#pragma once

#include <Arduino.h>
#include <inttypes.h>
#include "Map.h"

#define START           0x08
#define REPEATED_START  0x10
#define MT_SLA_ACK	0x18
#define MT_SLA_NACK	0x20
#define MR_SLA_ACK	0x40
#define MR_SLA_NACK	0x48
#define LOST_ARBTRTN    0x38

#define TWI_STATUS      (TWSR & 0xF8)
#define SLA_W(address)  (address << 1)
#define SLA_R(address)  ((address << 1) + 0x01)
#define cbi(sfr, bit)   (_SFR_BYTE(sfr) &= ~_BV(bit))
#define sbi(sfr, bit)   (_SFR_BYTE(sfr) |= _BV(bit))




class CI2CScan
{
  public:
    CI2CScan();
	virtual ~CI2CScan();
    void begin();
    void end();
    void setTimeOut(uint16_t nTimeOut);
    bool scan(uint8_t *arrayAddresses, const uint8_t nArraySize);
    bool find(const uint8_t nAddress);

  private:
    uint8_t start();
    uint8_t sendAddress(uint8_t);
    uint8_t stop();
    void lockUp();
    const char *lookUpDeviceName(const uint8_t nAddress);

    uint16_t m_nTimeoutDelay;

};
