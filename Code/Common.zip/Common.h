#line 2 "Common.h"
#pragma once

#include <assert.h>
#include <IPAddress.h>
#include <Wire.h> 
#include "Constants.h"
#ifdef LCD
  #include <LiquidCrystal_I2C.h>
#else
  #define LiquidCrystal_I2C void
#endif
#include "CBuff.h"




#if defined ARDUINO_AVR_UNO || defined ARDUINO_AVR_PRO
  extern CBuff<16> buffCommon;
#else
  extern CBuff<32> buffCommon;
#endif

#define LINE __LINE__
#define MILLIS(SEC) ((uint32_t)SEC * 1000)
#define MILLIS_MONTH (uint32_t)30 * 24 * 60 * 60 * 1000
#define MILLIS_WEEK (uint32_t)7 * 24 * 60 * 60 * 1000
#define MILLIS_DAY (uint32_t)24 * 60 * 60 * 1000
#define MILLIS_HOUR (uint32_t)60 * 60 * 1000
#define MILLIS_MINUTE (uint32_t)60 * 1000

typedef void (*VoidFunctionPtr)(void);
typedef bool (*BoolFunctionPtr)(void);
#ifdef ARDUINO_AVR_PRO
  typedef unsigned char byte;
#endif

#if defined ARDUINO_ESP32_DEV
  #undef F
  #define F(CSTR) CSTR
  #define BUILTIN_LED 2
  #define MIN(Arg1, Arg2) (Arg1 < Arg2) ? Arg1 : Arg2
  #define MAX(Arg1, Arg2) (Arg1 > Arg2) ? Arg1 : Arg2

  #define A0    36
  #define A1    39
  #define A2    34
  #define A3    35
  #define A4    32
  #define A5    33
  #define A6    25
  #define A7    26
  #define A8    27
  #define A9    14
  #define A10   12
  #define A11   13
  #define A12   4
  #define A13   2
  #define A14   5
  #define A15   0

#elif defined ARDUINO_SAM_DUE
  #undef F
  #define F(CSTR) CSTR
  char *dtostre(const double dVal, const uint8_t nWidth, const uint8_t nPrec, char *strOut);
  char *dtostrf(double dVal, const uint8_t nWidth, const uint8_t nPrec, char *strOut);
#endif

typedef void (*GlobalFunctionPtrType)();
typedef enum {SUN, MON, TUE, WED, THU, FRI, SAT} day_of_week;

class CString;

/*
__AVR_ATmega168__   ATmega 168    Arduino Decimilia and older
__AVR_ATmega328P__  ATmega 328P   Arduino Duemilanove and Uno
__AVR_ATmega1280__  ATmega 1280   Arduino Mega
__AVR_ATmega2560__  ATmega 2560   Arduino Mega 2560
__AVR_ATmega32U4__  ATmega 32U4   Arduino Leonardo
ARDUINO_SAM_DUE         AT91SAM3X8E   Arduino Due
*/




//*************************************************************************************************
// Delay with millis()
//*************************************************************************************************
void delayMillis(const uint32_t nMillisDelay);

//*************************************************************************************************
// Convert HTML hex code to ASCII character
//*************************************************************************************************

char getASCII(CString &strHexCode);

//*************************************************************************************************
// Corrects for millis() roll-over
//*************************************************************************************************
      
uint32_t getElapsedMillis(const uint32_t nStartMillis);
uint32_t getElapsedMicros(const uint32_t nStartMicros);

//*************************************************************************************************
// Finding the right baud rate
//*************************************************************************************************

#if !defined ARDUINO_SAM_DUE && !defined ARDUINO_ESP32_DEV 
  bool findBaudRate(HardwareSerial &rSerial, const __FlashStringHelper *fstrDeviceDesc, LiquidCrystal_I2C *pLCD);
  bool sendATCommand(HardwareSerial &rSerial, const __FlashStringHelper *fstrCommand, CString &strResponse, const uint16_t nWait);
#endif
bool findBaudRate(HardwareSerial &rSerial, const char *cstrDevName, LiquidCrystal_I2C *pLCD);
bool sendATCommand(HardwareSerial &rSerial, const char *cstrCommand, CString &strResponse, const uint16_t nWait);
bool sendATCommand(HardwareSerial &rSerial, const char *cstrCommand, const uint16_t nWait);
#if !defined ARDUINO_SAM_DUE && !defined ARDUINO_ESP32_DEV
  bool sendATCommand(HardwareSerial &rSerial, const __FlashStringHelper *fstrCommand, const uint16_t nWait);
#endif

//*************************************************************************************************
// Resetting the Arduino - a digital pin must be connected to the reset pin
//*************************************************************************************************

class CReset
{
  public:
    CReset();
    CReset(const uint8_t nPin, const uint16_t nResetPinState);
    virtual ~CReset();
    void begin();

    void reset();

  protected:
    uint8_t m_nPin, m_nResetPinState;
};

extern CReset resetArd;




//*************************************************************************************************
// Conversion functions
//*************************************************************************************************

const char* fromChar(const char cCh);
const char* fromBool(const bool bVal);
const char* fromUint(const uint32_t nNum, const uint8_t nBase);
const char* fromInt(const int32_t nNum, const uint8_t nBase);
const char* fromReal(const double dNum, const uint8_t nDecimalPlaces);
const char* fromIP(IPAddress ip);

uint32_t toUint(const char *strNum, const uint8_t nBase);
int32_t toInt(const char *strNum, const uint8_t nBase);
double toReal(const char *strNum);
IPAddress toIP(const char* strIP);

#if defined ARDUINO_AVR_UNO || defined ARDUINO_AVR_PRO
  extern CBuff<16> buffCommon;
#else
  extern CBuff<32> buffCommon;
#endif
