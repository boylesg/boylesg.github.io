#line 2 "Common.cpp"
#include <Arduino.h>
#include "Common.h"
#include "debug.h"
#include "CString.h"



#if defined ARDUINO_AVR_UNO || defined ARDUINO_AVR_PRO
  CBuff<16> buffCommon;
#else
  CBuff<32> buffCommon;
#endif




//*************************************************************************************************
// Delay with millis()
//*************************************************************************************************
void delayMillis(const uint32_t nMillisDelay)
{
  const uint32_t nMillisEnd = millis() + nMillisDelay;
  while (millis() <= nMillisEnd);
}

//*************************************************************************************************
// Convert HTML hex code to ASCII character
//*************************************************************************************************

char getASCII(CString &strHexCode)
{
  char cCh = ' ';
  
  if (strHexCode == F("20"))
    cCh = ' ';
  else if (strHexCode == F("21"))
    cCh = '!';
  else if (strHexCode == F("22"))
    cCh = '\"';
  else if (strHexCode == F("23"))
    cCh = '#';
  else if (strHexCode == F("24"))
    cCh = '$';
  else if (strHexCode == F("25"))
    cCh = '%';
  else if (strHexCode == F("26"))
    cCh = '&';
  else if (strHexCode == F("27"))
    cCh = '\'';
  else if (strHexCode == F("28"))
    cCh = '(';
  else if (strHexCode == F("29"))
    cCh = '}';
  else if (strHexCode == F("2A"))
    cCh = '*';
  else if (strHexCode == F("2B"))
    cCh = '+';
  else if (strHexCode == F("2C"))
    cCh = ',';
  else if (strHexCode == F("2D"))
    cCh = '-';
  else if (strHexCode == F("2E"))
    cCh = '.';
  else if (strHexCode == F("2F"))
    cCh = '/';
  else if (strHexCode == F("3A"))
    cCh = ':';
  else if (strHexCode == F("3B"))
    cCh = ';';
  else if (strHexCode == F("3C"))
    cCh = '<';
  else if (strHexCode == F("3D"))
    cCh = '=';
  else if (strHexCode == F("3E"))
    cCh = '>';
  else if (strHexCode == F("3F"))
    cCh = '?';
  else if (strHexCode == F("40"))
    cCh = '@';
  else if (strHexCode == F("5B"))
    cCh = '[';
  else if (strHexCode == F("5C"))
    cCh = '\\';
  else if (strHexCode == F("5D"))
    cCh = ']';
  else if (strHexCode == F("5E"))
    cCh = '^';
  else if (strHexCode == F("5F"))
    cCh = '_';
  else if (strHexCode == F("60"))
    cCh = '`';
  else if (strHexCode == F("7B"))
    cCh = '{';
  else if (strHexCode == F("7C"))
    cCh = '|';
  else if (strHexCode == F("7D"))
    cCh = '}';
  else if (strHexCode == F("7E"))
    cCh = '~';

  return cCh;
}

//*************************************************************************************************
// Finding the right baud rate
//*************************************************************************************************

bool sendATCommand(HardwareSerial &rSerial, const char *cstrCommand, CString &strResponse, const uint16_t nWait)
{
  uint32_t nTimeoutMillis = millis() + (nWait * 1000);
  char cCh = 0;
  
  strResponse.empty();
  
  rSerial.write(cstrCommand);
  rSerial.write("\r\n");

  delay(200);
  while (rSerial.available() < 2)
  {
    if (millis() >= nTimeoutMillis)
      break;
  }
  strResponse.empty();

  while (rSerial.available() > 0)
  {
    cCh = rSerial.read();
    strResponse += cCh;
  } 
  while (strResponse.find(F("\r")) || strResponse.find(F("\n")))
  {
    strResponse.remove(F("\r"));
    strResponse.remove(F("\n"));
  }
  return strResponse.find(F("OK"));
}

bool sendATCommand(HardwareSerial &rSerial, const char *cstrCommand, const uint16_t nWait)
{
  CBuff<32> buffResp, buffCommand;
  CString strResp(buffResp), strCommand(buffCommand);
  bool bResult = sendATCommand(rSerial, cstrCommand, strResp, nWait);

  strCommand = cstrCommand;
  strCommand.remove(F("\n"));
  strCommand.remove(F("\r"));
  debug.log(strCommand, false);
  debug.log(F("..."), false);
  debug.log(strResp);

  return bResult;
}

#if !defined ARDUINO_SAM_DUE && !defined ARDUINO_ESP32_DEV

  bool sendATCommand(HardwareSerial &rSerial, const __FlashStringHelper *fstrCommand, CString &strResponse, const uint16_t nWait)
  {
    CBuff<32> buffCmd;
    CString strCmd(buffCmd);
  
    strCmd = fstrCommand; 
    return sendATCommand(rSerial, strCmd, strResponse, nWait);
  }

  bool sendATCommand(HardwareSerial &rSerial, const __FlashStringHelper *fstrCommand, const uint16_t nWait)
  {
    CBuff<32> buffCmd;
    CString strCmd(buffCmd);
  
    strCmd = fstrCommand; 
    return sendATCommand(rSerial, strCmd, nWait);
  }
  
#endif

bool tryBaudRate(HardwareSerial &rSerial, const uint32_t nBaud, LiquidCrystal_I2C *pLCD)
{
  CBuff<16> buffResp;
  CString strResp(buffResp);
  bool bResult = false;
  
  debug.log(F("Trying "), false);
  debug.log(nBaud, false);
  debug.log(F(" bps..."), false);
  #ifdef LCD
    if (pLCD)
    {
      pLCD->setCursor(0, 2);
      pLCD->print(F("Trying "));
      pLCD->print(nBaud);
      pLCD->print(F(" bps... "));
    }
  #endif
  rSerial.end();
  delay(100);
  rSerial.begin(nBaud);
  while (!rSerial);
  bResult = sendATCommand(rSerial, F("AT"), strResp, 1);
  if (strResp.isEmpty())
    strResp = F("no response");
  debug.log(strResp);
  #ifdef LCD
    if (pLCD)
    {
      pLCD->setCursor(0, 3);
      pLCD->print(F("                    "));
      pLCD->setCursor(0, 3);
      pLCD->print(strResp);
    }
  #endif
  return bResult;
}

bool findBaudRate(HardwareSerial &rSerial, const char *cstrDevName, LiquidCrystal_I2C *pLCD) 
{
  CBuff<64> buff;
  CString str(buff);
  bool bResult  = true;

  str = F("Attempting to find the correct baud rate for ");
  str += cstrDevName; 
  debug.logEventOpen('=', str, true);

  #ifdef LCD
    if (pLCD)
    {
      pLCD->clear();
      pLCD->home();
      pLCD->print(F("Finding baud rate"));
      pLCD->setCursor(1, 1);
      pLCD->print(F("for WiFi shield!"));
    }
  #endif
  // 300, 600, 1200, 2400, 4800, *9600*, 14400, *19200*, 28800, *38400*, *57600*, or *115200*
  if (!tryBaudRate(rSerial, 9600, pLCD))
  {
    if (!tryBaudRate(rSerial, 14400, pLCD))
    {
      if (!tryBaudRate(rSerial, 19200, pLCD))
      {
        if (!tryBaudRate(rSerial, 28800, pLCD))
        {
          if (!tryBaudRate(rSerial, 38400, pLCD))
          {
            if (!tryBaudRate(rSerial, 57600, pLCD))
            {
              if (!tryBaudRate(rSerial, 115200, pLCD))
              {
                #ifdef LCD
                  pLCD->setCursor(0, 2);
                  pLCD->print(F("                    "));
                  pLCD->setCursor(0, 3);
                  pLCD->print(F("                    "));
                  pLCD->setCursor(0, 2);
                  pLCD->print(F("failed!"));
                #endif
                debug.log(F("failed!"));
                bResult = false;
              }
            }
          }
        }
      }
    }
  }
  debug.logEventClose('=', F(""));
  return bResult;
}

#if !defined ARDUINO_SAM_DUE && !defined ARDUINO_ESP32_DEV
  bool findBaudRate(HardwareSerial &rSerial, const __FlashStringHelper *fstrDeviceDesc, LiquidCrystal_I2C *pLCD)
  {
    CBuff<16> buffDeviceDesc;
    CString strDeviceDesc(buffDeviceDesc);
  
    strDeviceDesc = fstrDeviceDesc; 
    return findBaudRate(rSerial, strDeviceDesc, pLCD);
  }
#endif

//*************************************************************************************************
// Resetting the Arduino - a digital pin must be connected to the reset pin
//*************************************************************************************************

CReset::CReset()
{
  m_nPin = m_nResetPinState = 0;
}

CReset::CReset(const uint8_t nPin, const uint16_t nResetPinState)
{
  m_nPin = nPin;
  m_nResetPinState = nResetPinState;
}

CReset::~CReset()
{
  
}

void CReset::begin()
{
  pinMode(m_nPin, INPUT_PULLUP);
}

void CReset::reset()
{
  pinMode(m_nPin, OUTPUT);
  digitalWrite(m_nPin, m_nResetPinState);
}

CReset resetArd(22, LOW);




//*************************************************************************************************
// Corrects for millis() roll-over
//*************************************************************************************************
      
uint32_t getElapsedMicros(const uint32_t nStartMicros)
{
  uint32_t nElapsedMicros = 0, nMaxMicros = -1, nMicros = micros();

  if (nMicros < nStartMicros)
    nElapsedMicros = nMaxMicros - nStartMicros + nMicros;
  else
    nElapsedMicros = nMicros - nStartMicros;
    
  return nElapsedMicros;
}

uint32_t getElapsedMillis(const uint32_t nStartMillis)
{
  uint32_t nElapsedMillis = 0, nMaxMillis = -1, nMillis = millis();

  if (nMillis < nStartMillis)
    nElapsedMillis = nMaxMillis - nStartMillis + nMillis;
  else
    nElapsedMillis = nMillis - nStartMillis;
    
  return nElapsedMillis;
}




#ifdef ARDUINO_SAM_DUE

  char *dtostre(const double dVal, const uint8_t nWidth, const uint8_t nPrec, char *strOut) 
  {
     sprintf(strOut, "%*.*e", nWidth, nPrec, dVal);
     return strOut;
  }

  char *dtostrf(const double dVal, const uint8_t nWidth, const uint8_t nPrec, char *strOut) 
  {
     sprintf(strOut, "%*.*f", nWidth, nPrec, dVal);
     return strOut;
  }

#endif





//*************************************************************************************************
// Conversion functions
//*************************************************************************************************

const char* fromChar(const char cCh)
{
  buffCommon.empty();
  buffCommon[0] = cCh;

  return buffCommon;
}

const char* fromBool(const bool bVal)
{
  buffCommon.empty();

  if (bVal)
    strcpy_P(buffCommon, (PGM_P)F("true"));
  else
    strcpy_P(buffCommon, (PGM_P)F("false"));

  return buffCommon;
}

const char* fromUint(const uint32_t nNum, const uint8_t nBase)
{
  buffCommon.empty();
  utoa(nNum, buffCommon, nBase);

  return buffCommon;
}

const char* fromInt(const int32_t nNum, const uint8_t nBase)
{
  buffCommon.empty();
  itoa(nNum, buffCommon, nBase);

  return buffCommon;
}

uint8_t getIntegerValue(const char cDigit)
{
  uint8_t nVal = 0;
  
  if ((cDigit >= '0') && (cDigit <= '9'))
    nVal = cDigit - '0';
  else if ((cDigit >= 'a') && (cDigit <= 'f'))
    nVal = cDigit - 'a' + 10;
  else if ((cDigit >= 'A') && (cDigit <= 'F'))
    nVal = cDigit - 'A' + 10;
    
  return nVal;
}

const char* fromReal(const double dNum, const uint8_t nDecimalPlaces)
{
  #ifdef ARDUINO_SAM_DUE
    dtostrf(dNum, (nDecimalPlaces + 2), nDecimalPlaces, buffCommon);
  #else
    dtostrf(dNum, (nDecimalPlaces + 2), nDecimalPlaces, buffCommon);
  #endif

  return buffCommon;
}

const char* fromIP(IPAddress ip)
{
  CString strIP(buffCommon);

  strIP.format(F("%d.%d.%d.%d"), ip[0], ip[1], ip[2], ip[3]);

  return strIP;
}

uint32_t toUint(const char *strNum, const uint8_t nBase)
{
	int8_t nI = 0;
	uint32_t nVal = 0, nMult = 0;
  CBuff<16> buffNumber;
  CString strNumber(buffNumber);

  strNumber = strNum;
  strNumber.trim();
  
	if ((nBase >= 2) && (nBase <= 16))
	{
		for (nI = strNumber.length() - 1, nMult = 1; nI >= 0; nI--, nMult *= nBase)
		{
      nVal += getIntegerValue(strNumber[nI]) * nMult;
		}
	}
	return nVal;
}

int32_t toInt(const char *strNum, const uint8_t nBase)
{
	int8_t nI = 0;
	int32_t nVal = 0, nMult = 0;

  CBuff<16> buffNumber;
  CString strNumber(buffNumber);

  strNumber = strNum;
  strNumber.trim();
  
	if ((nBase >= 2) && (nBase <= 16))
	{
		for (nI = strNumber.length() - 1, nMult = 1; nI >= 0; nI--, nMult *= nBase)
		{
			if (strNumber[nI] == '-')
				nVal *= -1;
      else
        nVal += getIntegerValue(strNumber[nI]) * nMult;
		}
	}
	return nVal;
}

double toReal(const char *strNum)
{
	int8_t nI = 0, nPosDecimalPoint = 0, nSign = 0;
	uint8_t nLen = 0;
	double dVal = 0.0, dMult = 0;
	CString strNumber(buffCommon);
  strNumber = strNum;

  strNumber.trim();
  
  // 10.1
	nPosDecimalPoint = strNumber.indexOf(F("."));
  
	if (strNumber[0] == '-')
	{
		nSign = -1;
    strNumber.removeCh(1);
	}
	else
		nSign = 1;

  // 1.0000000138484279e+24
  // EXAMPLE: 123.456

	if (strNumber.find('E') || strNumber.find('e'))
	{
    double dExp = 0.0;    

    dMult = pow(10, nPosDecimalPoint - 1);

		for (nI = 0, nLen = strlen(strNum); nI < nLen; nI++, dMult /= 10)
		{
			if (strNumber[nI] == '.')
			{
        dMult /= 10;
			}
			else if ((strNumber[nI] == 'e') || (strNumber[nI] == 'E'))
				break;
      else
        dVal += getIntegerValue(strNumber[nI]) * dMult;
		}
		dVal *= nSign;
    
    nI++;
    if ((strNumber[nI] == ' ') || (strNumber[nI] == '+'))
      nSign = 1;
    else
      nSign = -1;
    
    strNumber.remove(0, nI+ 1);

    for (nI = 0, dMult = pow(10, strNumber.length() - 1); nI < (int)strNumber.length(); nI++)
    {
      dExp += getIntegerValue(strNumber[nI]) * dMult;
    }
    dExp *= nSign;
    dVal *= pow(10, dExp);
	}
	else
	{
    if (nPosDecimalPoint >= 0)
    {
      dMult = pow(10, nPosDecimalPoint - 1);
    }
    else
    {
      dMult = pow(10, strNumber.length() - 1);
    }  
		for (nI = 0, nLen = strlen(strNum); nI <= nLen; nI++, dMult /= 10)
		{
      if (strNumber[nI] == '.')
			{
        dMult /= 10;
			}
			else 
				dVal += getIntegerValue(strNumber[nI]) * dMult;
		}
		dVal *= nSign;
	}
	return dVal;
}

IPAddress toIP(const char* strIP)
{
  IPAddress ip;
  ip.fromString(strIP);
  return ip;
}
