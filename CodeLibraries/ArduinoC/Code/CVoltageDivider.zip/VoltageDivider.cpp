#include "VoltageDivider.h"




CVoltageDivider::CVoltageDivider(const int8_t nPin)
{
  m_nPin = nPin;
}

void CVoltageDivider::CVoltageDivider::begin()
{
  if (m_nPin > -1)
  {
    pinMode(m_nPin, INPUT);
  }
}

CVoltageDivider::~CVoltageDivider()
{
  m_nPin = -1;
}

void CVoltageDivider::setPin(const int8_t nPin)
{
  m_nPin = nPin;
  begin();
}

int8_t CVoltageDivider::getPin()
{
	return m_nPin;
}

float CVoltageDivider::readVoltage()
{
  return analogRead(m_nPin) * (5.0 / 1023.0); 
}
