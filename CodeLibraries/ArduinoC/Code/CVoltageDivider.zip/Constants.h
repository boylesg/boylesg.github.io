#line 2 "Constants.h"
#pragma once

#include <Arduino.h>

#define WIFI      				10
#define LCD       				20


