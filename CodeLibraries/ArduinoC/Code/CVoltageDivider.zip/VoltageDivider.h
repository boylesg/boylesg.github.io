#pragma once
#include <Arduino.h>
#include "Common.h"
#include "Debug.h"




class CVoltageDivider
{
  public:
    // Construction, destruction and initialisation
    CVoltageDivider(const int8_t nPin = -1);
    virtual ~CVoltageDivider();
    void begin();
    float readVoltage();

    // Interface
    void setPin(const int8_t nPin);
	int8_t getPin();
	

  protected:
    // Data members
    int8_t m_nPin;  
};




template <uint8_t nARRAY_SIZE>
class CVoltageDividerArray
{
  public:
    // Construction, destruction and initialisation
    CVoltageDividerArray();
    virtual ~CVoltageDividerArray();
    void begin();

    // Interface
    void setPin(const uint8_t nI, const uint8_t nPin);
    float readVoltageIndex(const uint8_t nI);
    float readVoltagePin(const uint8_t nPin);
    void dump();

  protected:
    // Data members
    CVoltageDivider m_arrayVoltageDividers[nARRAY_SIZE];
};




template<uint8_t nARRAY_SIZE>
CVoltageDividerArray<nARRAY_SIZE>::CVoltageDividerArray()
{
}

template<uint8_t nARRAY_SIZE>
CVoltageDividerArray<nARRAY_SIZE>::~CVoltageDividerArray()
{
}

template<uint8_t nARRAY_SIZE>
void CVoltageDividerArray<nARRAY_SIZE>::begin()
{
  for (uint8_t nI = 0; nI < nARRAY_SIZE; nI++)
    m_arrayVoltageDividers[nI].begin(-1);
}

template<uint8_t nARRAY_SIZE>
void CVoltageDividerArray<nARRAY_SIZE>::dump()
{ 
  for (uint8_t nI = 0; nI < nARRAY_SIZE; nI++)
  {
    debug.log(readVoltageIndex(nI), false);
    debug.log(F("  "), false);
  }
  debug.log(F(""));
}

template<uint8_t nARRAY_SIZE>
void CVoltageDividerArray<nARRAY_SIZE>::setPin(const uint8_t nI, const uint8_t nPin)
{
  if ((nI >= 0) && (nI < nARRAY_SIZE))
  {
    m_arrayVoltageDividers[nI].setPin(nPin);
  }
}

template<uint8_t nARRAY_SIZE>
float CVoltageDividerArray<nARRAY_SIZE>::readVoltageIndex(const uint8_t nI)
{
  float fVoltage = 0.0;
  
  if ((nI >= 0) && (nI < nARRAY_SIZE))
  {
    fVoltage = m_arrayVoltageDividers[nI].readVoltage();
  }
  return fVoltage;
}

template<uint8_t nARRAY_SIZE>
float CVoltageDividerArray<nARRAY_SIZE>::readVoltagePin(const uint8_t nPin)
{
  float fVoltage = 0.0;
  
  for (uint8_t nI = 0; nI < nARRAY_SIZE; nI++)
  {
	  if (m_arrayVoltageDividers[nI].getPin() == nPin)
	  {
		  fVoltage = m_arrayVoltageDividers[nI].readVoltage();
		  break;
	  }
  }
  return fVoltage;
}



template <uint8_t nARRAY_SIZE>
class CLineDetector: public CVoltageDividerArray<nARRAY_SIZE>
{
  public:
    // Construction, destruction and initialisation
    CLineDetector(const float nThresholdVoltage = 0.25, const char *cstrName = "");
    virtual ~CLineDetector();
    int8_t readWeight();
    int8_t getMaxWeight();
    int8_t getMinWeight();
    void dump();
    void setName(const char *cstrName);
    void setName(const __FlashStringHelper *fstrName);

  protected:
    // Data members
    const uint8_t m_nLEFT = 1, m_nRIGHT = 2, m_nSTRAIGHT = 3;
    uint8_t m_nDirection;
    float m_nThresholdVoltage;
    CBuff<24> m_buffName;
    CString m_strName;
};




template<uint8_t nARRAY_SIZE>
CLineDetector<nARRAY_SIZE>::CLineDetector(const float nThresholdVoltage, const char *cstrName): m_strName(m_buffName)
{
  m_nThresholdVoltage = nThresholdVoltage;
  m_nDirection = m_nSTRAIGHT;
  m_strName = cstrName;
}

template<uint8_t nARRAY_SIZE>
CLineDetector<nARRAY_SIZE>::~CLineDetector()
{
}

template<uint8_t nARRAY_SIZE>
void CLineDetector<nARRAY_SIZE>::setName(const __FlashStringHelper *fstrName)
{
  m_strName = fstrName;
}

template<uint8_t nARRAY_SIZE>
void CLineDetector<nARRAY_SIZE>::setName(const char *cstrName)
{
  m_strName = cstrName;
}

template<uint8_t nARRAY_SIZE>
int8_t CLineDetector<nARRAY_SIZE>::getMaxWeight()
{
  return nARRAY_SIZE;
}

template<uint8_t nARRAY_SIZE>
int8_t CLineDetector<nARRAY_SIZE>::getMinWeight()
{
  return -nARRAY_SIZE;
}

template<uint8_t nARRAY_SIZE>
void CLineDetector<nARRAY_SIZE>::dump()
{
  debug.log(m_strName, false);
  debug.log(F(" "));
  CVoltageDividerArray<nARRAY_SIZE>::dump();
  debug.log(F("WEIGHT = "), false);
  debug.log(readWeight());
}

template<uint8_t nARRAY_SIZE>
int8_t CLineDetector<nARRAY_SIZE>::readWeight()
{
  int8_t nWeight = 0;
  const uint8_t nMiddle = nARRAY_SIZE / 2;
  bool bLineDetected = false;
  float fVoltage = 0.0;

  for (int8_t nI = 0; nI < nARRAY_SIZE; nI++)
  {
    fVoltage = readVoltageIndex(nI);
    if (fVoltage >= m_nThresholdVoltage)
    {
      if (nI < nMiddle)
        nWeight -= nMiddle - nI;
      else if (nI > nMiddle)
        nWeight += nMiddle - nI;
      else if (nI == nMiddle)
        nWeight += 0;
      bLineDetected = true;
    }
  } 
  if (bLineDetected)
  {
    if (nWeight < nMiddle)
      m_nDirection = m_nLEFT;
    else if (nWeight > nMiddle)
      m_nDirection = m_nRIGHT;
    else
      m_nDirection = m_nSTRAIGHT;
  }
  else
  {
    if (m_nDirection == m_nLEFT)
      nWeight = -nARRAY_SIZE;
    else if (m_nDirection == m_nRIGHT)
      nWeight = nARRAY_SIZE;
    else
      nWeight = 0;
  }
  return nWeight;
}
