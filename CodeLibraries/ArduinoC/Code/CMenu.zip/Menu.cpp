#line 2 "Menu.cpp"
#include "Menu.h"

CMenuBase::CMenuBase(): m_strName(m_buffName)
{
  m_nID = 0;
  m_bSelected = false;
}

CMenuBase::CMenuBase(const char *cstrName, const uint8_t nID): m_strName(m_buffName)
{
  m_strName = cstrName;
  m_nID = nID;
  m_bSelected = false;
}

CMenuBase::CMenuBase(const __FlashStringHelper *fstrName, const uint8_t nID): m_strName(m_buffName)
{
  m_strName = fstrName;
  m_nID = nID;
  m_bSelected = false;
}

CMenuBase::~CMenuBase()
{
  m_strName = F("");
  m_nID = 0;
  m_bSelected = false;
}

void CMenuBase::select()
{
  m_bSelected = true;
}

void CMenuBase::unselect()
{
  m_bSelected = false;
}

bool CMenuBase::isSelected()
{
  return m_bSelected;
}

void CMenuBase::setName(const char *cstrName)
{
  m_strName = cstrName;
}

void CMenuBase::setName(const __FlashStringHelper *fstrName)
{
  m_strName = fstrName;
}

const char *CMenuBase::getName()
{
  return m_strName;
}

uint8_t CMenuBase::getMenuItemID()
{
  return m_nID;
}

void CMenuBase::setMenuItemID(const uint8_t nID)
{
  m_nID = nID;
}





CMenuItem::CMenuItem(): CMenuBase()
{
    m_pSubMenu = NULL;
    m_bSelected = false;
}

CMenuItem::CMenuItem(const char *cstrName, const uint8_t nID, const CMenuBase *pSubMenu): CMenuBase(cstrName, nID)
{
  m_pSubMenu = (CMenuBase*)pSubMenu;
  m_nID = nID;
  m_bSelected = false;
}

CMenuItem::CMenuItem(const __FlashStringHelper *fstrName, const uint8_t nID, const CMenuBase *pSubMenu): CMenuBase(fstrName, nID)
{
  m_pSubMenu = (CMenuBase*)pSubMenu;
  m_nID = nID;
  m_bSelected = false;
}

CMenuItem::~CMenuItem()
{
  m_pSubMenu = NULL;
  m_bSelected = false;
}

void CMenuItem::setSubMenu(const CMenuBase *pSubMenu)
{
  m_pSubMenu = (CMenuBase*)pSubMenu;
}

CMenuBase *CMenuItem::getSubMenu()
{
  return m_pSubMenu;
}

void CMenuItem::displayMenu(LiquidCrystal_I2C *pLCD, uint8_t nNumLines, const uint8_t nNumColumns)
{
  if (pLCD)
  {
    if (m_pSubMenu && m_bSelected)
      m_pSubMenu->displayMenu(pLCD, nNumLines, nNumColumns);
    else
      pLCD->print(m_strName);
  }
}

uint8_t CMenuItem::EnterPressed()
{
  uint8_t nID = 0;

  if (m_pSubMenu)
  {
    if (!m_bSelected)
    {
      nID = m_nID;
      m_pSubMenu->select();
    }
    else 
    {
      m_pSubMenu->EnterPressed();
    }
  }
  else
  {
    nID = m_nID;
  }
  return nID;
}

void CMenuItem::BackPressed()
{
  if (m_pSubMenu && m_bSelected)
    m_pSubMenu->BackPressed();
}

void CMenuItem::IncPressed()
{
  if (m_pSubMenu && m_bSelected)
    m_pSubMenu->IncPressed();
}

void CMenuItem::DecPressed()
{
  if (m_pSubMenu && m_bSelected)
    m_pSubMenu->DecPressed();
}


