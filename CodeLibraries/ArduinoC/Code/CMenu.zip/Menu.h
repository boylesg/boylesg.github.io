#pragma once
#include <Arduino.h>
#include "debug.h"
#include "CString.h"




class CMenuBase
{

  public:
    // Construction, destruction & initilaisation
    CMenuBase();
    CMenuBase(const char *cstrName, const uint8_t nID);
    CMenuBase(const __FlashStringHelper *fstrName, const uint8_t nID);
    virtual ~CMenuBase();

    void setName(const char *cstrName);
    void setName(const __FlashStringHelper *fstrName);
    const char *getName();
    uint8_t getMenuItemID();
    void setMenuItemID(const uint8_t nID);

    virtual uint8_t EnterPressed() = 0;
    virtual void BackPressed() = 0;
    virtual void IncPressed() = 0;
    virtual void DecPressed() = 0;
    virtual void displayMenu(LiquidCrystal_I2C *pLCD, uint8_t nNumLines, const uint8_t nNumColumns) = 0;
    virtual void select();
    virtual void unselect();
    virtual bool isSelected();

  protected:
    // Data
    CBuff<18> m_buffName;
    CString m_strName;
    uint8_t m_nID;
    bool m_bSelected;
};




class CMenuItem: public CMenuBase
{
  public:
    // Construction, destruction and initialisation
    CMenuItem();
    CMenuItem(const char *cstrName, const uint8_t nID, const CMenuBase *pSubMenu);
    CMenuItem(const __FlashStringHelper *fstrName, const uint8_t nID, const CMenuBase *pSubMenu);
    virtual ~CMenuItem();

    void setSubMenu(const CMenuBase *pSubMenu);
    CMenuBase *getSubMenu();

    virtual uint8_t EnterPressed();
    virtual void BackPressed();
    virtual void IncPressed();
    virtual void DecPressed();
    virtual void displayMenu(LiquidCrystal_I2C *pLCD, uint8_t nNumLines, const uint8_t nNumColumns);

  protected:
    // Data
    CMenuBase *m_pSubMenu;
};




template<int nMenuSize>
class CMenu: public CMenuBase
{
  public:
    // Construction, destruction & initilaisation
    CMenu(): CMenuBase()
    {
      m_nNumMenuItems = 0;
      m_nSelectedMenuItem = 0;
    }

    CMenu(const char *cstrName): CMenuBase(cstrName)
    {
      m_nNumMenuItems = 0;
      m_nSelectedMenuItem = 0;
    }

    CMenu(const __FlashStringHelper *fstrName): CMenuBase(fstrName)
    {
      m_nNumMenuItems = 0;
      m_nSelectedMenuItem = 0;
    }

    virtual ~CMenu()
    {
      m_nNumMenuItems = 0;
      m_nSelectedMenuItem = 0;
    }

    // Interface
    void addMenuItem(const char *cstrName, const uint8_t nID, const CMenuBase *pSubMenu = NULL)
    {
      if (m_nNumMenuItems < m_nMenuSize)
      {
        m_arrayMenuItems[m_nNumMenuItems].m_strName = cstrName;
        m_arrayMenuItems[m_nNumMenuItems].m_pSubMenu = (CMenuBase*)pSubMenu;
        m_arrayMenuItems[m_nNumMenuItems].m_nID = nID;
        m_nNumMenuItems++;
      }
    }

    void addMenuItem(const __FlashStringHelper *fstrName, const uint8_t nID, const CMenuBase *pSubMenu = NULL)
    {
      if (m_nNumMenuItems < m_nMenuSize)
      {
        m_arrayMenuItems[m_nNumMenuItems].setName(fstrName);
        m_arrayMenuItems[m_nNumMenuItems].setSubMenu(pSubMenu);
        m_arrayMenuItems[m_nNumMenuItems].setMenuItemID(nID);
        m_nNumMenuItems++;
      }
    }

    virtual uint8_t EnterPressed()
    {
      uint8_t nID = 0;

      if (m_arrayMenuItems[m_nSelectedMenuItem].getSubMenu())
      {
        if (!m_arrayMenuItems[m_nSelectedMenuItem].isSelected())
        {
          nID = m_arrayMenuItems[m_nSelectedMenuItem].getMenuItemID();
          m_arrayMenuItems[m_nSelectedMenuItem].select();
        }
        else
        {
          nID = m_arrayMenuItems[m_nSelectedMenuItem].getSubMenu()->EnterPressed();
        }
      }
      else
      {
        nID = m_arrayMenuItems[m_nSelectedMenuItem].getMenuItemID();
      }
      return nID;
    }

    virtual void BackPressed()
    {
      if (m_arrayMenuItems[m_nSelectedMenuItem].getSubMenu())
      {
        m_arrayMenuItems[m_nSelectedMenuItem].unselect();
      }
    }

    virtual void IncPressed()
    {
      if (m_arrayMenuItems[m_nSelectedMenuItem].getSubMenu() && m_arrayMenuItems[m_nSelectedMenuItem].isSelected())
        m_arrayMenuItems[m_nSelectedMenuItem].IncPressed();
      else
      {
        m_nSelectedMenuItem++;
        if (m_nSelectedMenuItem == m_nNumMenuItems)
          m_nSelectedMenuItem = 0;
      }
    }

    virtual void DecPressed()
    {
      if (m_arrayMenuItems[m_nSelectedMenuItem].getSubMenu() && m_arrayMenuItems[m_nSelectedMenuItem].isSelected())
        m_arrayMenuItems[m_nSelectedMenuItem].DecPressed();
      else
      {      
        m_nSelectedMenuItem--;
        if (m_nSelectedMenuItem == 255)
          m_nSelectedMenuItem = m_nNumMenuItems - 1;
      }
    }

    virtual const char *getMenuItemText()
    {
      return m_arrayMenuItems[m_nSelectedMenuItem].getName();
    }

    virtual uint8_t getMenuItemNum()
    {
      return m_nSelectedMenuItem;
    }

    virtual uint8_t getMenuItemID()
    {
      return m_arrayMenuItems[m_nSelectedMenuItem].getMenuItemID();
    }

    virtual void displayMenu(LiquidCrystal_I2C *pLCD, uint8_t nNumLines, const uint8_t nNumColumns)
    {
      if (m_arrayMenuItems[m_nSelectedMenuItem].getSubMenu() && m_arrayMenuItems[m_nSelectedMenuItem].isSelected())
      {
        m_arrayMenuItems[m_nSelectedMenuItem].getSubMenu()->displayMenu(pLCD, nNumLines, nNumColumns);
      }
      else if (pLCD)
      {
        pLCD->clear();
        pLCD->setCursor(0, 0);
        pLCD->print(m_strName);
        nNumLines--;

        uint8_t nStartMenuItem = 0, nEndMenuItem = nNumLines;
        while (m_nSelectedMenuItem >= nEndMenuItem)
        {
          nStartMenuItem++;
          nEndMenuItem++;
        }
        for (uint8_t nI = nStartMenuItem, nLineNum = 1; nI < nEndMenuItem; nI++, nLineNum++)
        {
          pLCD->setCursor(0, nLineNum);

          if (nI == m_nSelectedMenuItem)
            pLCD->print(F(">"));
          else 
            pLCD->print(F(" "));

          m_arrayMenuItems[nI].displayMenu(pLCD, nNumLines, nNumColumns);
          
          if (nI == m_nSelectedMenuItem)
          {
            pLCD->setCursor(nNumColumns - 1, nLineNum);
            pLCD->print(F("<"));
          }
        }
      }
    }

  protected:
    CMenuItem m_arrayMenuItems[nMenuSize];
    const uint8_t m_nMenuSize = nMenuSize;
    uint8_t m_nNumMenuItems, m_nSelectedMenuItem;

};
