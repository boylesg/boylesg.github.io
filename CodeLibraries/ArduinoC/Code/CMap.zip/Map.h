#pragma once

#include <Arduino.h>
#include "Encode.h"
  
template <typename KeyType, typename DataType, const uint8_t nMaxSize>
class CMap
{
  public:
    //Construction, destruction & initialisation
    CMap();
    ~CMap();

    bool setAt(KeyType KeyVal, DataType DataVal);
    bool getAt(KeyType KeyVal, DataType &DataVal);
    bool getNext(uint8_t &nI, KeyType &KeyVal, DataType &DataVal);
	uint8_t size();
	uint8_t capacity();

  protected:

    // Data
    KeyType m_arrayKeys[nMaxSize];
    DataType m_arrayData[nMaxSize];
    uint8_t m_nCurrSize;
  
};


template <typename KeyType, typename DataType, uint8_t nMaxSize>
CMap<KeyType, DataType, nMaxSize>::CMap()
{
  for (uint8_t nI = 0; nI < nMaxSize; nI++)
  {
    m_arrayKeys[nI] = 0;
    m_arrayData[nI] = 0;
  }
  m_nCurrSize = 0;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
CMap<KeyType, DataType, nMaxSize>::~CMap()
{
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
bool CMap<KeyType, DataType, nMaxSize>::setAt(KeyType KeyVal, DataType DataVal)
{
  bool bResult = false;
  
  if (m_nCurrSize < nMaxSize)
  {
    bResult = true;
    m_arrayKeys[m_nCurrSize] = KeyVal;
    m_arrayData[m_nCurrSize] = DataVal;
    m_nCurrSize++;
  }
  return bResult;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
bool CMap<KeyType, DataType, nMaxSize>::getAt(KeyType KeyVal, DataType &DataVal)
{ 
  uint8_t nI = 0;
  bool bResult = false;

  DataVal = 0;
  for (nI = 0; nI < m_nCurrSize; nI++)
  {
    if (m_arrayKeys[nI] == KeyVal)
    {
      DataVal = m_arrayData[nI];
      bResult = true;
      break;
    }
  }
  return bResult;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
bool CMap<KeyType, DataType, nMaxSize>::getNext(uint8_t &nI, KeyType &KeyVal, DataType &DataVal)
{
  bool bResult = false;

  if (nI < m_nCurrSize)
  {
    KeyVal = m_arrayKeys[nI];
    DataVal = m_arrayData[nI];
    bResult = true;
  }
  return bResult;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
uint8_t CMap<KeyType, DataType, nMaxSize>::size()
{
	return m_nCurrSize;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
uint8_t CMap<KeyType, DataType, nMaxSize>::capacity()
{
	return nMaxSize;
}




template <typename KeyType, typename DataType, const uint8_t nMaxSize>
class CMapPROGMEM
{
  public:
    //Construction, destruction & initialisation
    CMapPROGMEM();
    CMapPROGMEM(const KeyType *pKeyArray, const DataType *pDataArray);
    ~CMapPROGMEM();

    bool getAt(const KeyType KeyVal, DataType &DataVal);
	bool getNext(uint8_t &nI, KeyType &KeyVal, DataType &DataVal);
	uint8_t size();
	
  protected:

    // Data
    typedef struct {KeyType m_nKey; DataType m_nData;} ElementType;
    KeyType *m_arrayKeys;
    DataType *m_arrayData;
};

template <typename KeyType, typename DataType, uint8_t nMaxSize>
CMapPROGMEM<KeyType, DataType, nMaxSize>::CMapPROGMEM()
{
  m_arrayKeys = NULL;
  m_arrayData = NULL;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
CMapPROGMEM<KeyType, DataType, nMaxSize>::CMapPROGMEM(const KeyType *pKeyArray, const DataType *pDataArray)
{
  m_arrayKeys = (KeyType*)pKeyArray;
  m_arrayData = (DataType*)pDataArray;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
CMapPROGMEM<KeyType, DataType, nMaxSize>::~CMapPROGMEM()
{
  m_arrayKeys = NULL;
  m_arrayData = NULL;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
bool CMapPROGMEM<KeyType, DataType, nMaxSize>::getAt(const KeyType KeyVal, DataType &DataVal)
{ 
  uint8_t nI = 0;
  bool bResult = false;

  if (m_arrayKeys && m_arrayData)
  {
    DataVal = 0;
    for (nI = 0; nI < nMaxSize; nI++)
    {
      if (pgm_read_byte(m_arrayKeys + nI) == KeyVal)
      {
        DataVal = pgm_read_byte(m_arrayData + nI);
        bResult = true;
        break;
      }
    }
  }
  return bResult;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
uint8_t CMapPROGMEM<KeyType, DataType, nMaxSize>::size()
{
	return m_nCurrSize;
}

template <typename KeyType, typename DataType, uint8_t nMaxSize>
bool CMapPROGMEM<KeyType, DataType, nMaxSize>::getNext(uint8_t &nI, KeyType &KeyVal, DataType &DataVal)
{
  bool bResult = false;

  if (nI < nMaxSize)
  {
    KeyVal = pgm_read_byte(m_arrayKeys + nI);
	DataVal =  pgm_read_byte(m_arrayData + nI);
	bResult = true;
  }
  return bResult;
}

