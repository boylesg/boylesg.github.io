#line 2 "Array.h"
#pragma once

#include <Arduino.h>
#include <assert.h>
#define RUNTIME_ERROR Serial.print(F("Runtime error in file '")); Serial.print(__FILE__); Serial.print(F("', on line ")); Serial.print(__LINE__); assert(false);




template <typename DataType, const uint8_t nMaxSize>
class CArray
{
  public:
    //Construction, destruction & initialisation
    CArray();
    ~CArray();

    bool enqueue(DataType DataVal);
    bool dequeue(DataType &DataVal);
    bool push(DataType DataVal);
    bool pop(DataType &DataVal);
    
    bool add(DataType DataVal);
    bool insertAt(const uint8_t nI, DataType DataVal);
    bool removeAt(const uint8_t nI, DataType &DataVal);
    
    bool setAt(const uint8_t nI, DataType DataVal);
    bool getAt(const uint8_t nI, DataType &DataVal);
    
    DataType operator [](const uint8_t nI);
    uint8_t size();
	uint8_t capacity();
    bool isEmpty();
    void empty();
    bool find(DataType DataVal);

  protected:

    // Data
    DataType m_arrayData[nMaxSize];
    uint8_t m_nCurrSize;
  
};


template <typename DataType, uint8_t nMaxSize>
CArray<DataType, nMaxSize>::CArray()
{
  memset(m_arrayData, 0, sizeof m_arrayData);
  m_nCurrSize = 0;
}

template <typename DataType, uint8_t nMaxSize>
CArray<DataType, nMaxSize>::~CArray()
{
}

template <typename DataType, uint8_t nMaxSize>
uint8_t CArray<DataType, nMaxSize>::size()
{
  return m_nCurrSize;
}

uint8_t CArray<DataType, nMaxSize>::capacity()
{
	return nMaxSize;
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::isEmpty()
{
  return m_nCurrSize == 0;
}

template <typename DataType, uint8_t nMaxSize>
void CArray<DataType, nMaxSize>::empty()
{
  m_nCurrSize = 0;
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::find(DataType DataVal)
{
  bool bResult = false;

  for (uint8_t nI = 0; nI < m_nCurrSize; nI++)
  {
    if (m_arrayData[nI] == DataVal)
    {
      bResult = true;
      break;
    }
  }
  return bResult;
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::enqueue(DataType DataVal)
{
  return add(DataVal);
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::dequeue(DataType &DataVal)
{
  return removeAt(m_nCurrSize - 1, DataVal);
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::push(DataType DataVal)
{
  return insertAt(0, DataVal);
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::pop(DataType &DataVal)
{
  return removeAt(0, DataVal);
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::add(DataType DataVal)
{
  bool bResult = false;
  
  if (m_nCurrSize < nMaxSize)
  {
    m_arrayData[m_nCurrSize++] = DataVal;
    bResult = true;
  }
  return bResult;
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::insertAt(const uint8_t nI, DataType DataVal)
{
  bool bResult = false;
  
  if ((nI < m_nCurrSize) && ((m_nCurrSize + 1) == nMaxSize))
  {
    for (uint8_t nJ = m_nCurrSize; nJ > nI; nJ--)
    {
      m_arrayData[nJ] = m_arrayData[nJ - 1];
    }
    m_arrayData[nI] = DataVal;
    m_nCurrSize++;
    bResult = true;
  }
  return bResult;
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::removeAt(const uint8_t nI, DataType &DataVal)
{
  bool bResult = false;
  
  if (nI < m_nCurrSize)
  {
    DataVal = m_arrayData[nI];
    for (uint8_t nJ = nI; nJ < (m_nCurrSize - 1); nJ++)
    {
      m_arrayData[nJ] = m_arrayData[nJ + 1];
    }
    m_nCurrSize--;
    bResult = true;
  }
  return bResult;
  
}


template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::setAt(const uint8_t nI, DataType DataVal)
{
  bool bResult = false;
  
  if (nI < m_nCurrSize)
  {
    bResult = true;
    m_arrayData[nI] = DataVal;
  }
  return bResult;
}

template <typename DataType, uint8_t nMaxSize>
bool CArray<DataType, nMaxSize>::getAt(const uint8_t nI, DataType &DataVal)
{ 
  bool bResult = false;

  if (nI < m_nCurrSize)
  {
    DataVal = m_arrayData[nI];
    bResult = true;
  }
  return bResult;
}

template <typename DataType, uint8_t nMaxSize>
DataType CArray<DataType, nMaxSize>::operator [](const uint8_t nI)
{
  if (nI < m_nCurrSize)
  {
    return m_arrayData[nI];
  }
  else
  {
    RUNTIME_ERROR;
  }
}
